package com.vb.ecm.services.icdoc.view.ws;

public class ViewServicePortProxy implements com.vb.ecm.services.icdoc.view.ws.ViewServicePort {
  private String _endpoint = null;
  private com.vb.ecm.services.icdoc.view.ws.ViewServicePort viewServicePort = null;
  
  public ViewServicePortProxy() {
    _initViewServicePortProxy();
  }
  
  public ViewServicePortProxy(String endpoint) {
    _endpoint = endpoint;
    _initViewServicePortProxy();
  }
  
  private void _initViewServicePortProxy() {
    try {
      viewServicePort = (new com.vb.ecm.services.icdoc.view.ws.ViewServiceLocator()).getViewServicePort();
      if (viewServicePort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)viewServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)viewServicePort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (viewServicePort != null)
      ((javax.xml.rpc.Stub)viewServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.vb.ecm.services.icdoc.view.ws.ViewServicePort getViewServicePort() {
    if (viewServicePort == null)
      _initViewServicePortProxy();
    return viewServicePort;
  }
  
  public java.lang.Object[] getDocumentContent(java.lang.String docId) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException{
    if (viewServicePort == null)
      _initViewServicePortProxy();
    return viewServicePort.getDocumentContent(docId);
  }
  
  
}