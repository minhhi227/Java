/**
 * ViewServicePort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.view.ws;

public interface ViewServicePort extends java.rmi.Remote {

    /**
     * Method Description: This method is used to get the document
     * content (file content) to iCDoc 
     *                      Application when user clicks on View Button in
     * iCDoc Application.                    
     *  
     *  
     * @param String     : Document ID. 
     *  
     *  
     * @return Object[]    : returns Object Array (contains file format and
     * file content).
     */
    public java.lang.Object[] getDocumentContent(java.lang.String docId) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException;
}
