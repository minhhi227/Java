/**
 * ViewServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.view.ws;

public class ViewServiceLocator extends org.apache.axis.client.Service implements com.vb.ecm.services.icdoc.view.ws.ViewService {

/**
 * Last Modify Author       Venkat Banala
 *  
 * @Last Modification Date   Sep 22, 2012
 *  
 * @Last Modification Time   12:03:13 PM
 *  
 * @Last Modification Year   2012
 */

    public ViewServiceLocator() {
    }


    public ViewServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ViewServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ViewServicePort
    private java.lang.String ViewServicePort_address = "http://10.6.129.174:9080/services/icdoc/ViewService";

    public java.lang.String getViewServicePortAddress() {
        return ViewServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ViewServicePortWSDDServiceName = "ViewServicePort";

    public java.lang.String getViewServicePortWSDDServiceName() {
        return ViewServicePortWSDDServiceName;
    }

    public void setViewServicePortWSDDServiceName(java.lang.String name) {
        ViewServicePortWSDDServiceName = name;
    }

    public com.vb.ecm.services.icdoc.view.ws.ViewServicePort getViewServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ViewServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getViewServicePort(endpoint);
    }

    public com.vb.ecm.services.icdoc.view.ws.ViewServicePort getViewServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.vb.ecm.services.icdoc.view.ws.ViewServicePortBindingStub _stub = new com.vb.ecm.services.icdoc.view.ws.ViewServicePortBindingStub(portAddress, this);
            _stub.setPortName(getViewServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setViewServicePortEndpointAddress(java.lang.String address) {
        ViewServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.vb.ecm.services.icdoc.view.ws.ViewServicePort.class.isAssignableFrom(serviceEndpointInterface)) {
                com.vb.ecm.services.icdoc.view.ws.ViewServicePortBindingStub _stub = new com.vb.ecm.services.icdoc.view.ws.ViewServicePortBindingStub(new java.net.URL(ViewServicePort_address), this);
                _stub.setPortName(getViewServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ViewServicePort".equals(inputPortName)) {
            return getViewServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.view.icdoc.services.ecm.vb.com/", "ViewService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.view.icdoc.services.ecm.vb.com/", "ViewServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ViewServicePort".equals(portName)) {
            setViewServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
