/**
* ______________________________________________________________________________
*
* File: ViewService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 22, 2012   12:03:13 PM   2012
* Description: This class will pass the required document content (file content)
* 			   and it's format to iCDoc Application for viewing purpose when the 
* 			   user clicks on View button in iCDoc Application.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/
package com.vb.ecm.services.icdoc.view;

import java.io.ByteArrayInputStream;
import java.util.ResourceBundle;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfLoginInfo;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 22, 2012
 * @Last Modification Time   12:03:13 PM
 * @Last Modification Year   2012
 */

@DfsPojoService(targetNamespace = "http://view.icdoc.services.ecm.vb.com", requiresAuthentication = true)
public class ViewService {

	// Initialising the logger from org.apache.Log4j
	private final Logger LOGGER = DfLogger.getLogger(ViewService.class);       
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;	
	
	 /** 
	 * Method Description: This method is used to get the document content (file content) to iCDoc 
	 *                     Application Server when user clicks on View Button in iCDoc Application.                    
	 * 
	 * @param String     : Document ID.	
	 * 
	 * @return Object[]    : returns Object Array (contains file format and file content).
	 * 
	 */		
	public Object[] getDocumentContent(String docId) throws Exception
	 {		
		LOGGER.debug("ENTER");		
		
		ViewService viewSrvObj = null;
		IDfSysObject sysObj = null;	
		ByteArrayInputStream inputStream = null;
		Object[] docObject = new Object[2];
		byte[] fileContent = null;
		String fileFormat = null;
		ResourceBundle rsb = null;
				 
	     try {
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.icdoc.icDocConfig");
	    	 
	    	 //Create Session
	    	 viewSrvObj = new ViewService();
	    	 session = viewSrvObj.createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));
	    	 
	    	 if(docId!=null && !docId.equalsIgnoreCase("")){
	    		 
	    		 //get sysobject
	    		 sysObj = (IDfSysObject)session.getObject(new DfId(docId));	    		 
	    		 
	    		 if(!(sysObj.getString("doc_upload_status").equalsIgnoreCase("Deleted"))){
	    			 
	    			 //get file content & file format
		    		 inputStream = sysObj.getContent();
		    		 fileContent = IOUtils.toByteArray(inputStream);
		    		 fileFormat = sysObj.getString("a_content_type");
		    		 
		    		 //sending the results
		    		 docObject [0] = fileFormat;
		    		 docObject [1] = fileContent;
		    		 
		    		 //close input stream
		    		 inputStream.close();
		    		
	    		 }else{
	    			 fileFormat = "Document Doesn't Exist!!!";
	    			 docObject [0] = fileFormat;
	    		 }
	    	 }
	    	 else{
	    		 fileFormat = "Document Id shouldn't be null or empty!!!";
	    		 docObject [0] = fileFormat;
	    	 }
	 		
		} catch (Exception e) {
			fileFormat = "Error : " + e.fillInStackTrace();
			docObject [0] = fileFormat;
			LOGGER.error("Error Code (VS01) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 viewSrvObj.releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     LOGGER.debug("LEAVE");
		 return docObject;
	 }	
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.info("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (VS02) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr.release(session);
			LOGGER.info("Session Released.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (VS03) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {
		LOGGER.debug("ENTER");
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (VS04) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return idfsessionmanager;
	}	
	
	
}
