/**
* ______________________________________________________________________________
*
* File: UpdateService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 21, 2012   11:31:25 AM   2012
* Description: This class will update meta data of the documents present in ECM 
* 			   repository based on the data (attribute names and there values) 
* 			   provided by iCDoc Update functionality.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/
package com.vb.ecm.services.icdoc.update;

import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfLoginInfo;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 21, 2012
 * @Last Modification Time   11:31:25 AM
 * @Last Modification Year   2012 
 */

@DfsPojoService(targetNamespace = "http://update.icdoc.services.ecm.vb.com", requiresAuthentication = true)
public class UpdateService {

	// Initialising the logger from org.apache.Log4j
	private final Logger LOGGER = DfLogger.getLogger(UpdateService.class);       
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;
	
	 /** 
	 * Method Description: This method is used to update meta data of the document present in 
	 * 					   ECM based on the data (attribute values) provided by LOS Update Functionality.                    
	 * 
	 * @param String[]   : Contains all the meta data (attribute names and there values) of the 
	 * 					   document to be updated in ECM.	
	 *                     
	 * @return String	 : returns Message - Documents Updated Successfully.
	 */		
	public String updateDocuments(String[][] docProps) throws Exception
	 {		
		LOGGER.debug("ENTER");		
		
		UpdateService updateSrvObj = null;			
		String successMsg = null;
		ArrayList<String> attrs = new ArrayList<String>();
		ArrayList<String> attrValues = new ArrayList<String>();
		String updateQryString = null;
		int count = 0;
		ResourceBundle rsb = null;
		 
	     try {
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.icdoc.icDocConfig");
	    	 
	    	 //Create Session
	    	 updateSrvObj = new UpdateService();
	    	 session = updateSrvObj.createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));
	    	 
	    	 //to get all attributes
	    	 if(docProps[0].length > 2 && docProps[1].length > 2){
	    	 
	    		 for (int i = 0; i < 1; i++) {
	    			
    	            for (int j = 0; j < (docProps[0].length); j++) {
    	            	//to store column names in attrsArray
    	            	attrs.add(docProps[i][j]);    	                
    	            }
    	         }
	    		
	    	  //to get all attribute values        
	          for(int i = 0; i < (docProps.length-1); i++){            
	    	       
	    	     for(int j = 0; j < docProps[i].length; j++){
	    	      	//to store attribute values in attrValues array
	    	      	attrValues.add(docProps[i+1][j]);    	        	
	    	     }
	    	        
	    	     //calling buildQueryString method to get final query string
	    	     updateQryString = updateSrvObj.buildQueryString(attrs, attrValues);	    	     
	             
	             //calling executeQuery method
	             successMsg = executeQuery(updateQryString);	             
	             if(successMsg.equalsIgnoreCase("1")){
			    		count++;
			      }
	                
	             //clearing all the values
	             attrValues.clear();
	            }	          
	          
	           //to check whether it contains any error message
	           if(successMsg.contains("Error :")){
	        	   //
	           }else{
	        	   successMsg = "Documents Updated Successfully : " + count;
	           }
		    	
	    	 }else{
	    		 successMsg = "Input - Doesn't contain any attributes and there values to update.";	    		 
	    	 }
	 		
		} catch (Exception e) {
			successMsg = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (US01) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 updateSrvObj.releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     LOGGER.debug("LEAVE");
		 return successMsg;
	 }
	
	 /** 
	 * Method Description: This method is used to build the query string to update the documents meta data.                    
	 * 
	 * @param ArrayList, ArrayList : contains attribute names and attribute values.	
	 *                     
	 * @return String	 : Final Query String.
	 */	 
	private String buildQueryString(ArrayList<String> arrayAttrs, ArrayList<String> arrayAttrValues ) throws Exception {
    	
    	String queryString = null;
    	String attrNames = null;
    	
    	try{
    		queryString = "UPDATE " + arrayAttrValues.get(0) + " OBJECT";    		
    		
    		for(int i=2; i<arrayAttrs.size(); i++){
    			
    		  if((arrayAttrs.get(i)!=null) && (!arrayAttrs.get(i).equalsIgnoreCase("")) && 
    				  (arrayAttrValues.get(i)!=null) && (!arrayAttrValues.get(i).equalsIgnoreCase(""))){	
    			
    			if(attrNames!=null){
    				
    				if(arrayAttrs.get(i).equalsIgnoreCase("date_upload")){    					
    										    
   					    attrNames = attrNames + " SET " + arrayAttrs.get(i) + " = " + "DATE('" + arrayAttrValues.get(i) + "')";
    				
    				}else{
    			
    				    attrNames = attrNames + " SET " + arrayAttrs.get(i) + " = " + "'" + arrayAttrValues.get(i) + "'";
    				    }
    			
    			}else{
    				
    				if(arrayAttrs.get(i).equalsIgnoreCase("date_upload")){    					
    								    
   					    attrNames = " SET " + arrayAttrs.get(i) + " = " + "DATE('" + arrayAttrValues.get(i) + "')";
    				
    				}else{    					
    			
    				    attrNames = " SET " + arrayAttrs.get(i) + " = " + "'" + arrayAttrValues.get(i) + "'";
    			       }
    			}		
    			
    		  }
    		}
    		
    		//final string
    		queryString = queryString + attrNames + " SET title = 'Updated by iCDoc Update Service'" + " WHERE " + 
    		arrayAttrs.get(1) + " = " + "'" + arrayAttrValues.get(1) + "' AND doc_upload_status != 'Deleted'";
    		
    	}
    	catch(Exception e){
    		LOGGER.error("Error Code (US02) : ", e.fillInStackTrace());
    	}
    	return queryString;
    }
	
	 /** 
	 * Method Description: This method is used to execute the query (update query).                    
	 * 
	 * @param String     : Update Query String.	
	 *                     
	 * @return String	 : returns Message - No of documents Updated.
	 */	
	private String executeQuery(String updateQryString) throws Exception {
		LOGGER.debug("ENTER");	
		
		IDfClientX clientx = null;
		IDfQuery query = null;
		IDfCollection coll = null;
		String successMsg = null;
		
		try { 
			clientx = new DfClientX();
			query =clientx.getQuery();			
			
			query.setDQL(updateQryString);
			coll = query.execute(session, IDfQuery.DF_READ_QUERY);
			
			while(coll.next()){
				
				successMsg = coll.getString("objects_updated");
			}
			
			coll.close();
			
		} catch (Exception e) {	
			successMsg = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (US03) : ", e.fillInStackTrace());			
		}
		
		LOGGER.debug("LEAVE");
		return successMsg;
	}
	
	/** 
	 * Method Description: This method will update a list of documents(multiple records) meta data
     *                     based on the query string provided by icDoc Update functionality.                    
	 * 
	 * @param String     : Query String.	
	 *                     
	 * @return String    : No of documents updated message.
	 */		
	public String updateMultipleDocs(String queryString) throws Exception
	 {		
		LOGGER.debug("ENTER");		
		
		UpdateService updateSrvObj = null;		
		String successMsg = null;
		ResourceBundle rsb = null;
		 
	     try {
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.icdoc.icDocConfig");
	    	 
	    	 //Create Session
	    	 updateSrvObj = new UpdateService();
	    	 session = updateSrvObj.createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));
	    	 
	    	 //calling executeQuery method
	    	 queryString = queryString.replaceFirst("where", "where(") + ") and doc_upload_status != 'Deleted'";	    	
	    	 successMsg = executeQuery(queryString);
	    	 
	    	//to check whether it contains any error message
            if(successMsg.contains("Error :")){
        	   //
            }else{
        	    successMsg = "Documents Updated Successfully : " + successMsg;
            }
	 		
		} catch (Exception e) {	
			successMsg = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (US04) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 updateSrvObj.releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     LOGGER.debug("LEAVE");
		 return successMsg;
	 }
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.info("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (US05) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr.release(session);
			LOGGER.info("Session Released.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (US06) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {
		LOGGER.debug("ENTER");
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (US07) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return idfsessionmanager;
	}	
	

}
