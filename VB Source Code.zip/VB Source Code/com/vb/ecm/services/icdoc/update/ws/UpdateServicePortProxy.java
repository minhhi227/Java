package com.vb.ecm.services.icdoc.update.ws;

public class UpdateServicePortProxy implements com.vb.ecm.services.icdoc.update.ws.UpdateServicePort {
  private String _endpoint = null;
  private com.vb.ecm.services.icdoc.update.ws.UpdateServicePort updateServicePort = null;
  
  public UpdateServicePortProxy() {
    _initUpdateServicePortProxy();
  }
  
  public UpdateServicePortProxy(String endpoint) {
    _endpoint = endpoint;
    _initUpdateServicePortProxy();
  }
  
  private void _initUpdateServicePortProxy() {
    try {
      updateServicePort = (new com.vb.ecm.services.icdoc.update.ws.UpdateServiceLocator()).getUpdateServicePort();
      if (updateServicePort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)updateServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)updateServicePort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (updateServicePort != null)
      ((javax.xml.rpc.Stub)updateServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.vb.ecm.services.icdoc.update.ws.UpdateServicePort getUpdateServicePort() {
    if (updateServicePort == null)
      _initUpdateServicePortProxy();
    return updateServicePort;
  }
  
  public java.lang.String updateDocuments(java.lang.String[][] docProps) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException{
    if (updateServicePort == null)
      _initUpdateServicePortProxy();
    return updateServicePort.updateDocuments(docProps);
  }
  
  
}