/**
 * UpdateServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.update.ws;

public class UpdateServiceLocator extends org.apache.axis.client.Service implements com.vb.ecm.services.icdoc.update.ws.UpdateService {

/**
 * Last Modify Author       Venkat Banala
 *  
 * @Last Modification Date   Sep 21, 2012
 *  
 * @Last Modification Time   11:31:25 AM
 *  
 * @Last Modification Year   2012
 */

    public UpdateServiceLocator() {
    }


    public UpdateServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public UpdateServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for UpdateServicePort
    private java.lang.String UpdateServicePort_address = "http://10.6.129.174:9080/services/icdoc/UpdateService";

    public java.lang.String getUpdateServicePortAddress() {
        return UpdateServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String UpdateServicePortWSDDServiceName = "UpdateServicePort";

    public java.lang.String getUpdateServicePortWSDDServiceName() {
        return UpdateServicePortWSDDServiceName;
    }

    public void setUpdateServicePortWSDDServiceName(java.lang.String name) {
        UpdateServicePortWSDDServiceName = name;
    }

    public com.vb.ecm.services.icdoc.update.ws.UpdateServicePort getUpdateServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(UpdateServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getUpdateServicePort(endpoint);
    }

    public com.vb.ecm.services.icdoc.update.ws.UpdateServicePort getUpdateServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.vb.ecm.services.icdoc.update.ws.UpdateServicePortBindingStub _stub = new com.vb.ecm.services.icdoc.update.ws.UpdateServicePortBindingStub(portAddress, this);
            _stub.setPortName(getUpdateServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setUpdateServicePortEndpointAddress(java.lang.String address) {
        UpdateServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.vb.ecm.services.icdoc.update.ws.UpdateServicePort.class.isAssignableFrom(serviceEndpointInterface)) {
                com.vb.ecm.services.icdoc.update.ws.UpdateServicePortBindingStub _stub = new com.vb.ecm.services.icdoc.update.ws.UpdateServicePortBindingStub(new java.net.URL(UpdateServicePort_address), this);
                _stub.setPortName(getUpdateServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("UpdateServicePort".equals(inputPortName)) {
            return getUpdateServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.update.icdoc.services.ecm.vb.com/", "UpdateService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.update.icdoc.services.ecm.vb.com/", "UpdateServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("UpdateServicePort".equals(portName)) {
            setUpdateServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
