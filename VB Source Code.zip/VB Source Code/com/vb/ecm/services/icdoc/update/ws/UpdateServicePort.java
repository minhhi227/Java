/**
 * UpdateServicePort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.update.ws;

public interface UpdateServicePort extends java.rmi.Remote {

    /**
     * Method Description: This method is used to update meta data
     * of the documents present in 
     *          ECM based on the data (attribute values) provided by LOS
     * Update Functionality.                    
     *  
     *  
     * @param String[]   : Contains all the meta data (attribute names and
     * there values) of the 
     *          documents to be updated in ECM. 
     *                      
     *  
     * @return String  : returns Message - Documents Updated Successfully.
     */
    public java.lang.String updateDocuments(java.lang.String[][] docProps) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException;
}
