/**
* ______________________________________________________________________________
*
* File: DeleteService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 17, 2012   3:17:46 PM   2012
* Description: This class will delete (update the document status as deleted) 
*              the documents from ECM repository based on the Document ID 
*              provided by iCDoc Delete functionality.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/
package com.vb.ecm.services.icdoc.delete;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfLoginInfo;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 17, 2012
 * @Last Modification Time   3:17:46 PM
 * @Last Modification Year   2012
 */

@DfsPojoService(targetNamespace = "http://delete.icdoc.services.ecm.vb.com", requiresAuthentication = true)
public class DeleteService {

    // Initialising the logger from org.apache.Log4j
	private final Logger LOGGER = DfLogger.getLogger(DeleteService.class);       
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;	
		
	 /** 
	 * Method Description: This method is used to delete documents from ECM based on the document id 
	 * 					   (r_object_id of the document) provided by iCDoc Delete Functionality.                    
	 * 
	 * @param String[]   : Contains all the document id's of the documents to be deleted from ECM.	
	 *                     
	 * @return String	 : returns Message - Documents Deleted Successfully.
	 */		
	public String deleteDocuments(String[] docIds) throws Exception
	 {		
		LOGGER.debug("ENTER");		
		
		DeleteService deleteSrvObj = null;			
		String successMsg = null;
		int count = 0;
		ResourceBundle rsb = null;
		 
	     try {
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.icdoc.icDocConfig");
	    	 
	    	 //Create Session
	    	 deleteSrvObj = new DeleteService();
	    	 session = deleteSrvObj.createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));
	    	 
	    	 if(docIds.length > 0){
	    	 
		    	//getting all the object id's from String[]	docIds
		    	 for (int i = 0; i < docIds.length; i++) {
					   
		    		 successMsg = updateDocStatus(docIds[i]);
		    		 
		    		 if(successMsg.equalsIgnoreCase("1")){
				    		count++;
				     }
				}
		    	 
		    	 //to check whether it contains any error message
		    	 if(successMsg.contains("Error :")){		    		 
		    		 //    		 
		    	 }else{
		    	 
		    		 successMsg = "Documents Deleted Successfully : " + count;
		    	 }
		    	
	    	 }else{
	    		 successMsg = "Input - Doesn't contain any Doc Id's. Please pass docId's to delete the documents.";
	    		 LOGGER.debug("Input - Doesn't contain any Doc Id's. Please pass docId's to delete the documents.");
	    	 }
	 		
		} catch (Exception e) {
			successMsg = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (DS01) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 deleteSrvObj.releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     LOGGER.debug("LEAVE");
		 return successMsg;
	 }
	
	 /** 
	 * Method Description: This method is used to update the doc_upload_status attribute based 
	 * 					   on the r_object_id of the document.                    
	 * 
	 * @param String     : r_object_id of the document to be updated.	
	 *                     
	 * @return String	 : returns Message - No of documents Updated.
	 */	
	private String updateDocStatus(String objId) throws Exception {
		LOGGER.debug("ENTER");	
		
		IDfClientX clientx = null;
		IDfQuery queryString = null;
		IDfCollection coll = null;
		String successMsg = null;
		
		try { 
			clientx = new DfClientX();
			queryString =clientx.getQuery();
			
			queryString.setDQL("UPDATE vb_document object SET doc_upload_status = 'Deleted' " +
					"SET title = 'Deleted by iCDoc Delete Service' " +					
					"WHERE r_object_id = '" + objId + "' AND doc_upload_status!='Deleted'");
			coll = queryString.execute(session, IDfQuery.DF_READ_QUERY);
			
			while(coll.next()){
				
				successMsg = coll.getString("objects_updated");
			}
			
			coll.close();
			
		} catch (Exception e) {	
			successMsg = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (DS02) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		return successMsg;
	}
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.info("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (DS03) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr.release(session);
			LOGGER.info("Session Released.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (DS04) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {
		LOGGER.debug("ENTER");
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (DS05) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return idfsessionmanager;
	}	
	

}

