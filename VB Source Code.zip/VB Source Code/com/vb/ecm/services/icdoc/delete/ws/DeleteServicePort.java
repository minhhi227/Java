/**
 * DeleteServicePort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.delete.ws;

public interface DeleteServicePort extends java.rmi.Remote {

    /**
     * Method Description: This method is used to delete documents
     * from ECM based on the document id 
     *          (r_object_id of the document) provided by iCDoc Delete Functionality.
     * 
     *  
     *  
     * @param String[]   : Contains all the document id's of the documents
     * to be deleted from ECM. 
     *                      
     *  
     * @return String  : returns Message - Documents Deleted Successfully.
     */
    public java.lang.String deleteDocuments(java.lang.String[] docIds) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException;
}
