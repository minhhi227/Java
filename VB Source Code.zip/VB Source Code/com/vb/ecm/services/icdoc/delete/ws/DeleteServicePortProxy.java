package com.vb.ecm.services.icdoc.delete.ws;

public class DeleteServicePortProxy implements com.vb.ecm.services.icdoc.delete.ws.DeleteServicePort {
  private String _endpoint = null;
  private com.vb.ecm.services.icdoc.delete.ws.DeleteServicePort deleteServicePort = null;
  
  public DeleteServicePortProxy() {
    _initDeleteServicePortProxy();
  }
  
  public DeleteServicePortProxy(String endpoint) {
    _endpoint = endpoint;
    _initDeleteServicePortProxy();
  }
  
  private void _initDeleteServicePortProxy() {
    try {
      deleteServicePort = (new com.vb.ecm.services.icdoc.delete.ws.DeleteServiceLocator()).getDeleteServicePort();
      if (deleteServicePort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)deleteServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)deleteServicePort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (deleteServicePort != null)
      ((javax.xml.rpc.Stub)deleteServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.vb.ecm.services.icdoc.delete.ws.DeleteServicePort getDeleteServicePort() {
    if (deleteServicePort == null)
      _initDeleteServicePortProxy();
    return deleteServicePort;
  }
  
  public java.lang.String deleteDocuments(java.lang.String[] docIds) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException{
    if (deleteServicePort == null)
      _initDeleteServicePortProxy();
    return deleteServicePort.deleteDocuments(docIds);
  }
  
  
}