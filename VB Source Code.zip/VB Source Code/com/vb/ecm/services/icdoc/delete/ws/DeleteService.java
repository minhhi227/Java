/**
 * DeleteService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.delete.ws;

public interface DeleteService extends javax.xml.rpc.Service {

/**
 * Last Modify Author       Venkat Banala
 *  
 * @Last Modification Date   Sep 17, 2012
 *  
 * @Last Modification Time   3:17:46 PM
 *  
 * @Last Modification Year   2012
 */
    public java.lang.String getDeleteServicePortAddress();

    public com.vb.ecm.services.icdoc.delete.ws.DeleteServicePort getDeleteServicePort() throws javax.xml.rpc.ServiceException;

    public com.vb.ecm.services.icdoc.delete.ws.DeleteServicePort getDeleteServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
