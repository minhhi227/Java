/**
 * DeleteServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.delete.ws;

public class DeleteServiceLocator extends org.apache.axis.client.Service implements com.vb.ecm.services.icdoc.delete.ws.DeleteService {

/**
 * Last Modify Author       Venkat Banala
 *  
 * @Last Modification Date   Sep 17, 2012
 *  
 * @Last Modification Time   3:17:46 PM
 *  
 * @Last Modification Year   2012
 */

    public DeleteServiceLocator() {
    }


    public DeleteServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public DeleteServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for DeleteServicePort
    private java.lang.String DeleteServicePort_address = "http://10.6.129.174:9080/services/icdoc/DeleteService";

    public java.lang.String getDeleteServicePortAddress() {
        return DeleteServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String DeleteServicePortWSDDServiceName = "DeleteServicePort";

    public java.lang.String getDeleteServicePortWSDDServiceName() {
        return DeleteServicePortWSDDServiceName;
    }

    public void setDeleteServicePortWSDDServiceName(java.lang.String name) {
        DeleteServicePortWSDDServiceName = name;
    }

    public com.vb.ecm.services.icdoc.delete.ws.DeleteServicePort getDeleteServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(DeleteServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getDeleteServicePort(endpoint);
    }

    public com.vb.ecm.services.icdoc.delete.ws.DeleteServicePort getDeleteServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.vb.ecm.services.icdoc.delete.ws.DeleteServicePortBindingStub _stub = new com.vb.ecm.services.icdoc.delete.ws.DeleteServicePortBindingStub(portAddress, this);
            _stub.setPortName(getDeleteServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setDeleteServicePortEndpointAddress(java.lang.String address) {
        DeleteServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.vb.ecm.services.icdoc.delete.ws.DeleteServicePort.class.isAssignableFrom(serviceEndpointInterface)) {
                com.vb.ecm.services.icdoc.delete.ws.DeleteServicePortBindingStub _stub = new com.vb.ecm.services.icdoc.delete.ws.DeleteServicePortBindingStub(new java.net.URL(DeleteServicePort_address), this);
                _stub.setPortName(getDeleteServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("DeleteServicePort".equals(inputPortName)) {
            return getDeleteServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.delete.icdoc.services.ecm.vb.com/", "DeleteService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.delete.icdoc.services.ecm.vb.com/", "DeleteServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("DeleteServicePort".equals(portName)) {
            setDeleteServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
