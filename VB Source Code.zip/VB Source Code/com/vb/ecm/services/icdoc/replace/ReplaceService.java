/**
* ______________________________________________________________________________
*
* File: ReplaceService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 20, 2012   9:16:27 AM   2012
* Description: This class will replace the existing document present in ECM 
*              Repository and create a new document and set the existing document
*              properties and also new properties provided by iCDoc Replace 
*              Functionality.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.icdoc.replace;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 20, 2012
 * @Last Modification Time   9:16:27 AM
 * @Last Modification Year   2012 
 */

@DfsPojoService(targetNamespace = "http://replace.icdoc.services.ecm.vb.com", requiresAuthentication = true)

public class ReplaceService {
	
	// Initialising the logger from org.apache.Log4j
	private final Logger LOGGER = DfLogger.getLogger(ReplaceService.class);       
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;		
		
	 /** 
	 * Method Description: This method is used to make a new version of the existing document and sets 
	 *                     content to it and set all the properties provided by iCDoc Replace Functionality. 
	 *                     
	 * @param String     : Document Id (existing document id).
	 * 
	 * @param byte[]     : Contains document content (new document content).
	 * 
	 * @param String     : Document Format (valid doc formats like pdf, msw8, text etc..).
	 * 
	 * @param String[][] : Contains all the Document attributes and values (for ex: {"object_name", "Test Document"}, etc..) 
	 *                     like object_name, branch_number, creator_name, number_sign etc.. to set these properties to new 
	 *                     document.
	 *                     
	 * @return String	 : Document ID (newly created document id)
	 */		
	public String versionDocument(String existingDocId, byte[] newDocContent, String newDocFormat, String[][] docProps) 
			throws Exception
	 {		
		LOGGER.debug("ENTER");		
		
		ReplaceService replaceSrvObj = null;
		IDfSysObject sysObj = null, newSysObj = null;		
		HashMap<String, String> objectProps;
		String newDocId = null;
		IDfId newSysObjId = null;		
		ResourceBundle rsb = null;
		 
	     try {
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.icdoc.icDocConfig");
	    	 
	    	 //to store object properties in hash map
	    	 objectProps = getObjAttrsAndValues(docProps);	    	 
	    		    	 
	    	 if((newDocContent!=null && newDocContent.length!=1) && 
	    			 newDocFormat!=null && !newDocFormat.equalsIgnoreCase("") && 
	    			 existingDocId!=null && !existingDocId.equalsIgnoreCase("")){
	    	 
	    	 //Create Session
	    	 replaceSrvObj = new ReplaceService();
	    	 session = replaceSrvObj.createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));

	 		 sysObj = (IDfSysObject)session.getObject(new DfId(existingDocId)); 		
	 		 
		 		 if(!(sysObj.getString("doc_upload_status").equalsIgnoreCase("Deleted"))){
					
					 //check out
					 if (!sysObj.isCheckedOut())
					  {
					      sysObj.checkout();			     
					  } 
					 
					 //check in						 			 			 
					 newSysObjId = sysObj.checkin(false, "");
					 newDocId = newSysObjId.toString();
					 
					 newSysObj = (IDfSysObject)session.getObject(newSysObjId);
					 newSysObj.setString("title","Document Replaced by iCDoc Replace Service");
					 
					 //set content to new document			
					 newSysObj.setContentType(newDocFormat);
		        	 ByteArrayOutputStream out = new ByteArrayOutputStream();
		        	 out.write(newDocContent, 0, newDocContent.length);	        	 
		        	 newSysObj.setContent(out);
					 
					 Iterator<Entry<String, String>> iterator = objectProps.entrySet().iterator();
			         
			         while(iterator.hasNext()) {
			        	 
				          Map.Entry<String, String> mapEntry = (Map.Entry<String, String>)iterator.next();
				          
				          if((mapEntry.getKey()!=null) && (mapEntry.getValue()!=null) &&
					        	(!mapEntry.getKey().equalsIgnoreCase("")) && (!mapEntry.getValue().equalsIgnoreCase(""))){
				        	  newSysObj.setString(mapEntry.getKey().toString().toLowerCase(), mapEntry.getValue().toString());		
				          }
			         }	
					 
					 newSysObj.save();
					 
		 		 }else{
		 			 newDocId = "Document Doesn't Exist!!!";		 			
		 		 }
	 		 	    	 
	    	 }else{
	    		 newDocId = "Document Id, Document Content & Document Format shouldn't be null or empty.";
	    		 LOGGER.debug("Document Id, Document Content & Document Format shouldn't be null or empty.");
	    	 }	          
			 
		} catch (Exception e) {	
			newDocId = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (RS01) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 replaceSrvObj.releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     LOGGER.debug("LEAVE");
		
		return newDocId;		
	 }
	
	 /** 
	 * Method Description: This method is used to over write the content of the existing document and 
	 * 					   set all the properties provided by iCDoc Replace Functionality. 
	 *                     
	 * @param String     : Document Id (existing document id).
	 * 
	 * @param byte[]     : Contains new document content (existing document content to over write).
	 * 
	 * @param String[][] : Contains all the Document attributes and values (for ex: {"object_name", "Test Document"}, etc..) 
	 *                     like object_name, branch_number, creator_name, number_sign etc.. to set these properties to new 
	 *                     document.
	 *                     
	 * @return String	 : Success Message.
	 */		
	public String replaceDocument(String existingDocId, byte[] docContent, String[][] docProps) throws Exception
	 {		
		LOGGER.debug("ENTER");		
		
		ReplaceService replaceSrvObj = null;
		IDfSysObject sysObj = null;		
		HashMap<String, String> objectProps;
		String successMsg = null;		
		ResourceBundle rsb = null;
		 
	     try {
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.icdoc.icDocConfig");
	    	 
	    	 //to store object properties in hash map
	    	 objectProps = getObjAttrsAndValues(docProps);	    	 
	    		    	 
	    	 if((docContent!=null && docContent.length!=1) &&	    			
	    			 existingDocId!=null && !existingDocId.equalsIgnoreCase("")){
	    	 
	    	 //Create Session
	    	 replaceSrvObj = new ReplaceService();
	    	 session = replaceSrvObj.createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));

	 		 sysObj = (IDfSysObject)session.getObject(new DfId(existingDocId)); 		
	 		 
		 		 if(!(sysObj.getString("doc_upload_status").equalsIgnoreCase("Deleted"))){
					
					 //check out
					 if (!sysObj.isCheckedOut())
					  {
					      sysObj.checkout();			     
					  }							 			 			 
					 
					 sysObj.setString("title","Document Content Overwritten by iCDoc Replace Service");
					 
					 //set content to new document					 
		        	 ByteArrayOutputStream out = new ByteArrayOutputStream();
		        	 out.write(docContent, 0, docContent.length);	        	 
		        	 sysObj.setContent(out);
					 
					 Iterator<Entry<String, String>> iterator = objectProps.entrySet().iterator();
			         
			         while(iterator.hasNext()) {
			        	 
				          Map.Entry<String, String> mapEntry = (Map.Entry<String, String>)iterator.next();
				          
				          if((mapEntry.getKey()!=null) && (mapEntry.getValue()!=null) &&
				        		(!mapEntry.getKey().equalsIgnoreCase("")) && (!mapEntry.getValue().equalsIgnoreCase(""))){
				        	  sysObj.setString(mapEntry.getKey().toString().toLowerCase(), mapEntry.getValue().toString());				        	 
				          }
			         }	
					 
			         sysObj.save();
			         successMsg = "Document Content Overwritten Successfully.";
					 
		 		 }else{
		 			successMsg = "Document Doesn't Exist!!!";		 			
		 		 }
	 		 	    	 
	    	 }else{
	    		 successMsg = "Existing Document Id & New Document Content shouldn't be null or empty.";
	    		 LOGGER.debug("Existing Document Id & New Document Content shouldn't be null or empty.");
	    	 }	          
			 
		} catch (Exception e) {	
			successMsg = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (RS01) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 replaceSrvObj.releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     LOGGER.debug("LEAVE");
		
		return successMsg;		
	 }
	
	/**
	 * Description : This method is used to process input data which is sent from web service client program 
	 *               and returns HashMap Object.
	 * 
	 * @return HashMap : docProps (which contains object attributes and it's values as key and value in HashMap).
	 */	
	private HashMap<String, String> getObjAttrsAndValues(String[][] objAttrs) throws Exception{
		
		HashMap<String, String> docProps = new HashMap<String, String>();
		ArrayList<String> objAttributes = new ArrayList<String>();
        ArrayList<String> objAttrsValues = new ArrayList<String>();
		
		try {
			//processing input (client) data
			//Object Attributes
			for (int i = 0; i < objAttrs.length; i++) {
			    for (int j = 0; j < (objAttrs.length - (objAttrs.length-1)); j++) {
			    	objAttributes.add(objAttrs[i][j]);			        
			    }
			}
			
			//Object Attribute Values			
			for (int i = 0; i < (objAttrs.length); i++) {
			    for (int j = 1; j < (objAttrs.length- (objAttrs.length-2)); j++) {
			    	objAttrsValues.add(objAttrs[i][j]);			        
			    }
			}		
			
			//Insert into HashMap
			for(int i=0;i<objAttributes.size();i++){
				docProps.put(objAttributes.get(i), objAttrsValues.get(i));
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (RS02) : ", e.fillInStackTrace());
		}
		
		return docProps;				
	}	
		
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception{
		LOGGER.debug("ENTER");
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.info("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (RS03) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr.release(session);
			LOGGER.info("Session Released.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (RS04) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {
		LOGGER.debug("ENTER");
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (RS05) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return idfsessionmanager;
	}
	
	
}
