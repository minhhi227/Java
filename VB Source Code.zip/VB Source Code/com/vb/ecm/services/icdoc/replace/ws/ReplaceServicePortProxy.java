package com.vb.ecm.services.icdoc.replace.ws;

public class ReplaceServicePortProxy implements com.vb.ecm.services.icdoc.replace.ws.ReplaceServicePort {
  private String _endpoint = null;
  private com.vb.ecm.services.icdoc.replace.ws.ReplaceServicePort replaceServicePort = null;
  
  public ReplaceServicePortProxy() {
    _initReplaceServicePortProxy();
  }
  
  public ReplaceServicePortProxy(String endpoint) {
    _endpoint = endpoint;
    _initReplaceServicePortProxy();
  }
  
  private void _initReplaceServicePortProxy() {
    try {
      replaceServicePort = (new com.vb.ecm.services.icdoc.replace.ws.ReplaceServiceLocator()).getReplaceServicePort();
      if (replaceServicePort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)replaceServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)replaceServicePort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (replaceServicePort != null)
      ((javax.xml.rpc.Stub)replaceServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.vb.ecm.services.icdoc.replace.ws.ReplaceServicePort getReplaceServicePort() {
    if (replaceServicePort == null)
      _initReplaceServicePortProxy();
    return replaceServicePort;
  }
  
  public java.lang.String replaceDocument(java.lang.String docId, java.lang.String filePath, java.lang.String[][] docProps) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException{
    if (replaceServicePort == null)
      _initReplaceServicePortProxy();
    return replaceServicePort.replaceDocument(docId, filePath, docProps);
  }
  
  
}