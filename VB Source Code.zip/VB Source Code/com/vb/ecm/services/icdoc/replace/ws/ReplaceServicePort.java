/**
 * ReplaceServicePort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.replace.ws;

public interface ReplaceServicePort extends java.rmi.Remote {

    /**
     * Method Description: This method is used to replace the existing
     * document and sets content to it  
     *                      and set all the properties provided by iCDoc
     * Replace Functionality. 
     *                      
     *  
     * @param String     : Document Id (existing document id which needs
     * to be replaced).
     *  
     *  
     * @param String     : File Path (Document Location to get content).
     *  
     *  
     * @param String[][] : Contains all the Document attributes and values
     * (for ex: {"object_name", "Test Document"}, etc..) 
     *                      like object_name, branch_number, creator_name,
     * number_sign etc.. to set these properties to new 
     *                      document.
     *                      
     *  
     * @return String  : Document ID (newly created document id)
     */
    public java.lang.String replaceDocument(java.lang.String docId, java.lang.String filePath, java.lang.String[][] docProps) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException;
}
