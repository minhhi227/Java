/**
 * CreateServicePort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.create.ws;

public interface CreateServicePort extends java.rmi.Remote {

    /**
     * Method Description: This method is used to create document
     * and sets content to it in ECM 
     *                      and set all the properties provided by iCDoc
     * Upload Functionality. 
     *                      
     *  
     * @param byte[]     : Contains document content to store into ECM.
     *  
     *  
     * @param String     : Document Format (valid doc formats like pdf, msw8,
     * text etc..)
     *  
     *  
     * @param String[][] : Contains all the Document attributes and values
     * (for ex: {"object_name", "Test Document"}, etc..) 
     *                      like object_name, file_path, format, creator_name,
     * level_security etc.. to set properties to 
     *                      the document.
     *                      
     *  
     * @param String[][] : Contains all the Customer related info like branch_number,
     * number_sign, customer_type, 
     *          creator_name etc.. to set properties to the Number Sign Folder.
     * 
     *  
     * @return String  : Document ID (newly created document id).
     */
    public java.lang.String createDocument(byte[] docContent, java.lang.String docFormat, java.lang.String[][] docProps, java.lang.String[][] custProps) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException;
}
