/**
 * CreateService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.create.ws;

public interface CreateService extends javax.xml.rpc.Service {

/**
 * Last Modify Author       Venkat Banala
 *  
 * @Last Modification Date   Sep 19, 2012
 *  
 * @Last Modification Time   9:16:27 AM
 *  
 * @Last Modification Year   2012
 */
    public java.lang.String getCreateServicePortAddress();

    public com.vb.ecm.services.icdoc.create.ws.CreateServicePort getCreateServicePort() throws javax.xml.rpc.ServiceException;

    public com.vb.ecm.services.icdoc.create.ws.CreateServicePort getCreateServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
