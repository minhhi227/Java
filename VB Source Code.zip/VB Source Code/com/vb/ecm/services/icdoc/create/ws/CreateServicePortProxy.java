package com.vb.ecm.services.icdoc.create.ws;

public class CreateServicePortProxy implements com.vb.ecm.services.icdoc.create.ws.CreateServicePort {
  private String _endpoint = null;
  private com.vb.ecm.services.icdoc.create.ws.CreateServicePort createServicePort = null;
  
  public CreateServicePortProxy() {
    _initCreateServicePortProxy();
  }
  
  public CreateServicePortProxy(String endpoint) {
    _endpoint = endpoint;
    _initCreateServicePortProxy();
  }
  
  private void _initCreateServicePortProxy() {
    try {
      createServicePort = (new com.vb.ecm.services.icdoc.create.ws.CreateServiceLocator()).getCreateServicePort();
      if (createServicePort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)createServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)createServicePort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (createServicePort != null)
      ((javax.xml.rpc.Stub)createServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.vb.ecm.services.icdoc.create.ws.CreateServicePort getCreateServicePort() {
    if (createServicePort == null)
      _initCreateServicePortProxy();
    return createServicePort;
  }
  
  public java.lang.String createDocument(byte[] docContent, java.lang.String docFormat, java.lang.String[][] docProps, java.lang.String[][] custProps) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException{
    if (createServicePort == null)
      _initCreateServicePortProxy();
    return createServicePort.createDocument(docContent, docFormat, docProps, custProps);
  }
  
  
}