/**
 * CreateServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.create.ws;

public class CreateServiceLocator extends org.apache.axis.client.Service implements com.vb.ecm.services.icdoc.create.ws.CreateService {

/**
 * Last Modify Author       Venkat Banala
 *  
 * @Last Modification Date   Sep 19, 2012
 *  
 * @Last Modification Time   9:16:27 AM
 *  
 * @Last Modification Year   2012
 */

    public CreateServiceLocator() {
    }


    public CreateServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CreateServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CreateServicePort
    private java.lang.String CreateServicePort_address = "http://10.6.129.174:9080/services/icdoc/CreateService";

    public java.lang.String getCreateServicePortAddress() {
        return CreateServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CreateServicePortWSDDServiceName = "CreateServicePort";

    public java.lang.String getCreateServicePortWSDDServiceName() {
        return CreateServicePortWSDDServiceName;
    }

    public void setCreateServicePortWSDDServiceName(java.lang.String name) {
        CreateServicePortWSDDServiceName = name;
    }

    public com.vb.ecm.services.icdoc.create.ws.CreateServicePort getCreateServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CreateServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCreateServicePort(endpoint);
    }

    public com.vb.ecm.services.icdoc.create.ws.CreateServicePort getCreateServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.vb.ecm.services.icdoc.create.ws.CreateServicePortBindingStub _stub = new com.vb.ecm.services.icdoc.create.ws.CreateServicePortBindingStub(portAddress, this);
            _stub.setPortName(getCreateServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCreateServicePortEndpointAddress(java.lang.String address) {
        CreateServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.vb.ecm.services.icdoc.create.ws.CreateServicePort.class.isAssignableFrom(serviceEndpointInterface)) {
                com.vb.ecm.services.icdoc.create.ws.CreateServicePortBindingStub _stub = new com.vb.ecm.services.icdoc.create.ws.CreateServicePortBindingStub(new java.net.URL(CreateServicePort_address), this);
                _stub.setPortName(getCreateServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CreateServicePort".equals(inputPortName)) {
            return getCreateServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.create.icdoc.services.ecm.vb.com/", "CreateService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.create.icdoc.services.ecm.vb.com/", "CreateServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CreateServicePort".equals(portName)) {
            setCreateServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
