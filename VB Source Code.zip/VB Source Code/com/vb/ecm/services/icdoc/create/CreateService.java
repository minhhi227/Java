/**
* ______________________________________________________________________________
*
* File: CreateService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 19, 2012   9:16:27 AM   2012
* Description: This class will create document in ECM repository and set all 
*              the properties provided by iCDoc Upload functionality as 
*              meta-data to that document.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/
package com.vb.ecm.services.icdoc.create;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfLoginInfo;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 19, 2012
 * @Last Modification Time   9:16:27 AM
 * @Last Modification Year   2012 
 */

@DfsPojoService(targetNamespace = "http://create.icdoc.services.ecm.vb.com", requiresAuthentication = true)
public class CreateService {
	
	// Initialising the logger from org.apache.Log4j
	private final Logger LOGGER = DfLogger.getLogger(CreateService.class);       
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;
	
	//Resource Bundle
	private ResourceBundle rsb = null;	
	
	 /** 
	 * Method Description: This method is used to create document and sets content to it in ECM 
	 *                     and set all the properties provided by iCDoc Upload Functionality. 
	 *                     
	 * @param byte[]     : Contains document content to store into ECM.
	 * 
	 * @param String     : Document Format (valid doc formats like pdf, msw8, text etc..)
	 * 
	 * @param String[][] : Contains all the Document attributes and values (for ex: {"object_name", "Test Document"}, etc..) 
	 *                     like object_name, file_path, format, creator_name, level_security etc.. to set properties to 
	 *                     the document.
	 *                     
	 * @param String[][] : Contains all the Customer related info like branch_number, number_sign, customer_type, 
	 * 					   creator_name etc.. to set properties to the Number Sign Folder.
	 *                     
	 * @return String	 : Document ID (newly created document id).
	 */		
	public String createDocument(byte[] docContent, String docFormat, String[][] docProps, String[][] custProps) 
			throws Exception
	 {		
		LOGGER.debug("ENTER");		
		
		CreateService createSrvObj = null;
		IDfSysObject sysObj = null;	
		String docId = null, dctmLocPath = null;
		HashMap<String, String> objectProps;
		HashMap<String, String> folderProps;			
		 
	     try {
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.icdoc.icDocConfig");
	    	 
	    	 //customer info
	    	 folderProps = getObjAttrsAndValues(custProps);
	    	 
	    	 //getting file_path and format from hash map and removing it from hash map
	    	 objectProps = getObjAttrsAndValues(docProps);	
	    	 
	    	 if((docContent!=null && docContent.length!=1) && 
	    			 docFormat!=null && !docFormat.equalsIgnoreCase("")){
	    	 
	    	 //Create Session
	    	 createSrvObj = new CreateService();
	    	 session = createSrvObj.createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));
	    	 
	 		 sysObj = (IDfSysObject)session.newObject(rsb.getString("DOC_TYPE"));	 		 
	 		 LOGGER.debug("Creating document...");	 		 
                         
             sysObj.setTitle("Document Created by icDoc Create Service");
             sysObj.setString("doc_upload_status", "Uploaded"); 
             //Date
             SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a"); 					      
 			 sysObj.setString("date_upload", dateFormat.format(new Date()));
             
             //ECM Destination Path            	 
             dctmLocPath = getDestFolderPath(folderProps);            
            
             Iterator<Entry<String, String>> iterator = objectProps.entrySet().iterator();
	         
	         while(iterator.hasNext()) {
	        	 
		          Map.Entry<String, String> mapEntry = (Map.Entry<String, String>)iterator.next();
		          
		          if((mapEntry.getKey()!=null) && (mapEntry.getValue()!=null) &&
			        		(!mapEntry.getKey().equalsIgnoreCase("")) && (!mapEntry.getValue().equalsIgnoreCase(""))){		          
		          
		        	  sysObj.setString((mapEntry.getKey().toString()).toLowerCase(), mapEntry.getValue().toString());	
		          }
	         }	        
	         
	          if(!dctmLocPath.contains("Error:")){
	        	  
	        	 sysObj.setContentType(docFormat);
	        	 ByteArrayOutputStream out = new ByteArrayOutputStream();
	        	 out.write(docContent, 0, docContent.length);	        	 
	        	 sysObj.setContent(out);
	        	 sysObj.link(dctmLocPath);
	             sysObj.save(); 
	             LOGGER.debug("Document Created Successfully.");
	             
				 docId = sysObj.getObjectId().getId();				  			 
				 
	          }else{
	        	  docId = dctmLocPath;
	        	  LOGGER.debug("Destination Path : " + dctmLocPath + " Create Service Operation Failed!!!");
	          }
	    	 
	    	 }else{
	    		 docId = "Document Content & Format shouldn't be null or empty.";
	    		 LOGGER.debug("Some Mandatory Attribute Values are missing. Please enter valid values.");
	    	 }	          
			 
		} catch (Exception e) {	
			docId = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (CS01) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 createSrvObj.releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     LOGGER.debug("LEAVE");
		
		return docId;		
	 }
	
	/**
	 * Description : This method is used to process input data which is sent from web service client program 
	 *               and returns HashMap Object.
	 * 
	 * @return HashMap : docProps (which contains object attributes and it's values as key and value in HashMap).
	 */	
	private HashMap<String, String> getObjAttrsAndValues(String[][] objAttrs) throws Exception {
		
		HashMap<String, String> docProps = new HashMap<String, String>();
		ArrayList<String> objAttributes = new ArrayList<String>();
        ArrayList<String> objAttrsValues = new ArrayList<String>();
		
		try {
			//processing input (client) data
			//Object Attributes
			for (int i = 0; i < objAttrs.length; i++) {
			    for (int j = 0; j < (objAttrs.length - (objAttrs.length-1)); j++) {
			    	objAttributes.add(objAttrs[i][j]);			        
			    }
			}
			
			//Object Attribute Values			
			for (int i = 0; i < (objAttrs.length); i++) {
			    for (int j = 1; j < (objAttrs.length- (objAttrs.length-2)); j++) {
			    	objAttrsValues.add(objAttrs[i][j]);			        
			    }
			}		
			
			//Insert into HashMap
			for(int i=0;i<objAttributes.size();i++){
				docProps.put(objAttributes.get(i), objAttrsValues.get(i));
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (CS02) : ", e.fillInStackTrace());
		}
		
		return docProps;				
	}	
	
	/**
	 * Description : This method is used to create custom folders if they don't exist and 
	 *               generate the final destination folder path to create document in ECM.
	 * 
	 * @return String : Final Destination Folder Path
	 */	
	private String getDestFolderPath(HashMap<String, String> folderProps) throws Exception {
		
		String destFolderPath = null, branch_number = null;		
		String number_sign = null;		
		
		try {			
			branch_number = folderProps.get("branch_number");			
			number_sign = folderProps.get("number_sign");			
			
			if(branch_number!=null && !branch_number.equalsIgnoreCase("") &&
					(number_sign!=null) && !number_sign.equalsIgnoreCase("")){
				
				String[] year = number_sign.split("-");
				
				//Cabinet - Branch 001
				IDfFolder isBranchExists = session.getFolderByPath("/Branch " + branch_number);
				 if(isBranchExists!=null){
					 destFolderPath = "/Branch " + branch_number;						 
					 					 
				 //Folder - iCDoc Docs
				 destFolderPath = isFolderExists(rsb.getString("SOURCE"), destFolderPath);				 
				    
				 //Folder - get Year from number sign value			 
				 destFolderPath = isFolderExists(year[2], destFolderPath);
				 
				 //Folder - Create Customer Folder and set customer info				 
				 IDfFolder isCustFldrExists = session.getFolderByPath(destFolderPath + "/" + number_sign);
				      if(isCustFldrExists!=null){
				    	  
				    	   destFolderPath = destFolderPath + "/" + number_sign;			    	   				    	   
				    	   
				      }else{				    	  
				    	   createCustFolder(number_sign, destFolderPath, folderProps);				    	   
				    	   destFolderPath = destFolderPath + "/" + number_sign;
				      }	    	     
				   
				 //final destination folder path
				 LOGGER.debug("Final Destination Folder Path in  ECM : " + destFolderPath);
				 
				 }
				 else{					
					 destFolderPath = "Error:Cabinet (Branch " + branch_number + ") Doesn't Exist. Please contact Administrator.";
				 }
			}
			else{				
				destFolderPath = "Error:Create Service Operation Failed bcoz of missing mandatory values from client.";
				LOGGER.debug("Create Service Operation Failed bcoz of missing mandatory values from client.");				
			}
			
		} catch (DfException e) {		
			LOGGER.error("Error Code (CS03) : ", e.fillInStackTrace());
		}		
		
		return destFolderPath;
	}
	
	/**
	 * Description : This method is used to create custom folder (vb_folder) in ECM.
	 * 
	 * @return boolean : true
	 */	
	private boolean createFolder(String folderName, String folderPath) throws Exception {		
		IDfSysObject sysObj = null;
		boolean flag = false;
		
		try {
			sysObj = (IDfSysObject)session.newObject(rsb.getString("FOLDER_TYPE"));
			LOGGER.debug("creating folder...");
			sysObj.setObjectName(folderName); 
			sysObj.setTitle("Folder Created by icDoc Create Service");
			sysObj.link(folderPath);
			sysObj.save(); 
			flag = true;
			LOGGER.debug(folderName + " Folder Created @ " + folderPath);
			
		} catch (DfException e) {			
			LOGGER.error("Error Code (CS04) : ", e.fillInStackTrace());
		}
		return flag;		
	}
	
	/**
	 * Description : This method is used to create customer folder and sets customer info to it in ECM.
	 * 
	 * @return boolean : true
	 */	
	private boolean createCustFolder(String numberSign, String folderPath, HashMap<String, String> folderProps) 
			throws Exception {		
		IDfSysObject sysObj = null;
		boolean flag = false;		
		
		try {
			//folder info			
			sysObj = (IDfSysObject)session.newObject(rsb.getString("CUST_FOLDER_TYPE"));
			LOGGER.debug("creating folder...");
			sysObj.setObjectName(numberSign); 
			sysObj.setTitle("Folder Created by icDoc Create Service");
			
			//setting customer info to folder
			Iterator<Entry<String, String>> iterator = folderProps.entrySet().iterator();
	         
	         while(iterator.hasNext()) {
	        	 
		          Map.Entry<String, String> mapEntry = (Map.Entry<String, String>)iterator.next();
		          
		          if((mapEntry.getKey()!=null) && (mapEntry.getValue()!=null)){		          
		        	  sysObj.setString(mapEntry.getKey().toString().toLowerCase(), mapEntry.getValue().toString());	
		          }
	         }	
			
			sysObj.link(folderPath);
			sysObj.save(); 
			flag = true;
			LOGGER.debug(numberSign + " Folder Created @ " + folderPath);
			
		} catch (DfException e) {			
			LOGGER.error("Error Code (CS05) : ", e.fillInStackTrace());
		}
		return flag;		
	}	
	
	/**
	 * Description : This method is used to check the folder existence in ECM.
	 * 
	 * @return String : Folder Path
	 */	
	private String isFolderExists(String folderName, String folderPath) throws Exception {
		String destFldrPath = null;
		
		try {
			IDfFolder isFolderExists = session.getFolderByPath(folderPath + "/" + folderName);
			 if(isFolderExists!=null){
				 destFldrPath = folderPath + "/" + folderName;
			 }
			 else{
				 createFolder(folderName, folderPath);
				 destFldrPath = folderPath + "/" + folderName;
			 }
		} catch (DfException e) {			
			LOGGER.error("Error Code (CS07) : ", e.fillInStackTrace());
		}
		
		return destFldrPath;
	}
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.info("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (CS08) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr.release(session);
			LOGGER.info("Session Released.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (CS9) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {
		LOGGER.debug("ENTER");
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (CS10) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return idfsessionmanager;
	}	
	

}
