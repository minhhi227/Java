/**
 * SearchService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.search.ws;

public interface SearchService extends javax.xml.rpc.Service {

/**
 * Last Modify Author       Venkat Banala
 *  
 * @Last Modification Date   Sep 20, 2012
 *  
 * @Last Modification Time   3:19:18 PM
 *  
 * @Last Modification Year   2012
 */
    public java.lang.String getSearchServicePortAddress();

    public com.vb.ecm.services.icdoc.search.ws.SearchServicePort getSearchServicePort() throws javax.xml.rpc.ServiceException;

    public com.vb.ecm.services.icdoc.search.ws.SearchServicePort getSearchServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
