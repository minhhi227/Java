/**
* ______________________________________________________________________________
*
* File: SearchService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 20, 2012   3:19:18 PM   2012
* Description: This class will return a list of documents meta data based on the
*              Query String provided by iCDoc Search functionality.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.icdoc.search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfAttr;
import com.documentum.fc.common.IDfLoginInfo;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 20, 2012
 * @Last Modification Time   3:19:18 PM
 * @Last Modification Year   2012 
 */

@DfsPojoService(targetNamespace = "http://search.icdoc.services.ecm.vb.com", requiresAuthentication = true)
public class SearchService {

	// Initialising the logger from org.apache.Log4j
	private final Logger LOGGER = DfLogger.getLogger(SearchService.class);       
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;		
		
	 /** 
	 * Method Description: This method will return a list of documents meta data
     *                     based on the query string provided by iCDoc Search functionality.                    
	 * 
	 * @param String     : Query.	
	 *                     
	 * @return String[][]: returns list of documents meta data.
	 */		
	public String[][] getListOfDocsMetadata(String queryString) throws Exception
	 {		
		LOGGER.debug("ENTER");		
		
		SearchService searchSrvObj = null;		
		String[][] lstOfDocsMetadata = null;
		ResourceBundle rsb = null;
		 
	     try {
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.icdoc.icDocConfig");
	    	 
	    	 //Create Session
	    	 searchSrvObj = new SearchService();
	    	 session = searchSrvObj.createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));
	    	 
	    	 //calling executeQuery method
	    	 lstOfDocsMetadata = executeQuery(queryString);	    	
	 		
		} catch (Exception e) {			
			LOGGER.error("Error Code (SS01) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 searchSrvObj.releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     LOGGER.debug("LEAVE");
		 return lstOfDocsMetadata;
	 }	
	
	 /** 
	 * Method Description: This method is used to execute the query.                    
	 * 
	 * @param String     : Query.	
	 *                     
	 * @return String[][]: return results in 2 dim string array.
	 */	
	private String[][] executeQuery(String queryString) throws Exception {
		LOGGER.debug("ENTER");	
		
		IDfClientX clientx = null;
		IDfQuery query = null;
		IDfCollection coll = null;		
		ArrayList<String> attrNames = new ArrayList<String>();
		HashMap<String, String> attrValues = new HashMap<String, String>();
		String[][] lstOfDocsMetadata = null;
		int noOfCols = 0, resItems = 0;		
		
		try { 
			clientx = new DfClientX();
			query =clientx.getQuery();
			
			if((queryString.toLowerCase()).contains("where")){
				
				queryString = (queryString.toLowerCase()).replaceFirst("where", "where(");
				queryString = queryString + ") and doc_upload_status != 'Deleted'";
				
			}else{
				
				queryString = queryString + " where doc_upload_status != 'Deleted'";
			}			
			
			query.setDQL(queryString);
			coll = query.execute(session, IDfQuery.DF_READ_QUERY);
			
			//No of columns - Attributes count
			noOfCols = coll.getAttrCount();
			
			for(int i = 0; i < noOfCols; i++){
				
	        	IDfAttr attr = coll.getAttr(i);
	        	attrNames.add(attr.getName());	        	
	        }
			
			while(coll.next()){	
				
				resItems++;
				
				for (int i = 0; i < coll.getAttrCount(); i++) 
				{		          
				  attrValues.put(coll.getAttr(i).getName() + (resItems), coll.getString(coll.getAttr(i).getName()));	            
				}
			}
			
			coll.close();
			
			//output conversion
			if(resItems>0){
			
			lstOfDocsMetadata = new String[resItems+1][noOfCols];
			//to store attribute names in 1st row
	        for (int i = 0; i < 1; i++) {
    			
	            for (int j = 0; j < noOfCols; j++) {	            	
	            	lstOfDocsMetadata[i][j] = attrNames.get(j);
	            }
	         }
	        
	        //to store attribute values from 2nd row into hash map
	        for (int i = 1; i < resItems+1; i++) {
	        	
			    for (int j = 0; j < noOfCols; j++) {
			    	lstOfDocsMetadata[i][j] = attrValues.get(attrNames.get(j)+i).toString();		        
			    }
			}
			}else{
				lstOfDocsMetadata = new String[1][1];
				lstOfDocsMetadata[0][0] = "No Records Exist!!!";
			}
			
		} catch (Exception e) {	
			lstOfDocsMetadata = new String[1][1];
			lstOfDocsMetadata[0][0] = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (SS02) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return lstOfDocsMetadata;
	}
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.info("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (SS03) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
		LOGGER.debug("ENTER");
		
		try {
			sMgr.release(session);
			LOGGER.info("Session Released.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (SS04) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {
		LOGGER.debug("ENTER");
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (SS05) : ", e.fillInStackTrace());
		}
		
		LOGGER.debug("LEAVE");
		
		return idfsessionmanager;
	}
	
	
}
