package com.vb.ecm.services.icdoc.search.ws;

public class SearchServicePortProxy implements com.vb.ecm.services.icdoc.search.ws.SearchServicePort {
  private String _endpoint = null;
  private com.vb.ecm.services.icdoc.search.ws.SearchServicePort searchServicePort = null;
  
  public SearchServicePortProxy() {
    _initSearchServicePortProxy();
  }
  
  public SearchServicePortProxy(String endpoint) {
    _endpoint = endpoint;
    _initSearchServicePortProxy();
  }
  
  private void _initSearchServicePortProxy() {
    try {
      searchServicePort = (new com.vb.ecm.services.icdoc.search.ws.SearchServiceLocator()).getSearchServicePort();
      if (searchServicePort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)searchServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)searchServicePort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (searchServicePort != null)
      ((javax.xml.rpc.Stub)searchServicePort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.vb.ecm.services.icdoc.search.ws.SearchServicePort getSearchServicePort() {
    if (searchServicePort == null)
      _initSearchServicePortProxy();
    return searchServicePort;
  }
  
  public java.lang.String[][] getListOfDocsMetadata(java.lang.String queryString) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException{
    if (searchServicePort == null)
      _initSearchServicePortProxy();
    return searchServicePort.getListOfDocsMetadata(queryString);
  }
  
  
}