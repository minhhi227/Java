/**
 * SearchServicePort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.vb.ecm.services.icdoc.search.ws;

public interface SearchServicePort extends java.rmi.Remote {

    /**
     * Method Description: This method will return a list of documents
     * meta data
     *                      based on the query string provided by iCDoc Search
     * functionality.                    
     *  
     *  
     * @param String     : Query. 
     *                      
     *  
     * @return String[][]: returns list of documents meta data.
     */
    public java.lang.String[][] getListOfDocsMetadata(java.lang.String queryString) throws java.rmi.RemoteException, com.emc.documentum.fs.rt.ServiceException;
}
