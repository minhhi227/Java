/**
* ______________________________________________________________________________
*
* File: DeleteDocs.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 13, 2012   3:17:46 PM   2012
* Description: This class will delete (soft delete based on the Document ID - 
* 			   update the document status as "Deleted") and unlink (unlink the
* 		       document based on the folder path) the documents from ECM 
*              repository by using LOS Delete functionality.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.delete;

import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfBatchManager;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfScopeManager;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.ScopeBoundary;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 13, 2012
 * @Last Modification Time   3:17:46 PM
 * @Last Modification Year   2012
 */

public class DeleteDocs {       
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;	
	
	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;	
	
	 /** 
	 * Method Description: This method is used to delete documents from ECM based on the document id 
	 * 					   (r_object_id of the document) provided by LOS Delete Functionality.                    
	 * 
	 * @param String[]   : Contains all the document id's of the documents to be deleted from ECM.	
	 * 
	 * @param String     : Contains document deleted user name.
	 *                     
	 * @return String	 : returns Message.
	 */		
	public String deleteDocuments(Logger logger, ResourceBundle rsb, ReadDSStringXML inputStrXmlObj, 
			String reqReceivedDate, String status, String errorCode, String errorMessage, ArrayList<String> docIds) throws Exception
	 {				
		String successMsg = null;
		int count = 0;		
		IDfScopeManager scopeMgr;
		IDfBatchManager bmgr = null;
		
		IDfClientX clientx = null;
		IDfQuery query = null;
		IDfCollection coll = null;
		
	     try {
	    	 //logger
			 LOGGER = logger;
	    	 
	    	 //Create Session	    	
	    	 session = createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));   	
	    	 
	    	 if(session!=null){   	 
	    	 
	    	 //using transactions in code
	    	 sMgr = session.getSessionManager();
	    	 scopeMgr = sMgr.getScopeManager();	    	 
	    	 scopeMgr.enableServerScope(true);	    	
	    	 scopeMgr.setDefaultScope(ScopeBoundary.BATCH, true);   	 
	    	 
	    	 bmgr = session.getBatchManager();
	    	 bmgr.openBatch(bmgr.getMaxBatchSize(), true, true, true, null);	
	    	 
	    	 clientx = new DfClientX();
			 query = clientx.getQuery();
	    	 
			//getting all the object id's from docIds
	    	 for (int i = 0; i < docIds.size(); i++) {
	    		 
	    		 query.setDQL("UPDATE " + rsb.getString("DOC_TYPE") +" object SET doc_upload_status = 'Deleted' " +
	 					"SET title = 'LOS Delete Service-Document Deleted by : "+ inputStrXmlObj.getUserId() +"'" +
	 					"SET delete_user = '"+ inputStrXmlObj.getUserId() +"'" +
	 					"SET owner_name = '"+ rsb.getString("LOS_ADMINS_GROUP_NAME") +"'" +
	 					"WHERE r_object_id = '" + docIds.get(i) + "' AND doc_upload_status!='Deleted'");			
	 			
	 			coll = query.execute(session, IDfQuery.DF_READ_QUERY); 
	    		
	 			while(coll.next()){					
					
					if(coll.getString("objects_updated").equalsIgnoreCase("1")){
			    		count++;
					}
				}
				
				coll.close();						    
			 }
	    	 
	    	 if(count==docIds.size()){
	    		 
		          //commit
		          bmgr.commitBatch();
		          bmgr.closeBatch(); 
		          successMsg = "success";
		          LOGGER.debug(count + " Document(s) Deleted Successfully.");
		          
	           }else{	        	  
	        	  bmgr.abortBatch();	        	  
				  successMsg = "Document(s) Doesn't Exist in ECM to Delete.";				         	  
	           }
	    	 }
	    	 else{					
					successMsg = "Session Not Created.";								
				}
	 		
		} catch (Exception e) {			
			bmgr.abortBatch();			
			successMsg = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (DS08) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
	    		 if(bmgr!=null){
	    		 if(bmgr.isBatchActive())
	    			 bmgr.abortBatch();
	    		 }
	    		 
				if(session!=null){
					 releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }	     
	     
		 return successMsg;
	 }	
	
	 /** 
	 * Method Description: This method is used to unlink the documents based on the document id and 
	 * 					   document folder path provided.                    
	 * 
	 * @param String[]   : document id's.
	 * 
	 * @param String[]   : document folder paths.	
	 *                     
	 * @return String	 : returns Message.
	 */	
	public String unlinkDocuments(Logger logger, ResourceBundle rsb, ReadDSStringXML inputStrXmlObj, String reqReceivedDate, 
			String status, String errorCode, String errorMessage, ArrayList<String> unlink_docids, 
			ArrayList<String> unlink_folder_path) throws Exception{
		
		int count = 0;
		String successMsg = null;
		IDfScopeManager scopeMgr;
		IDfBatchManager bmgr = null;		
		
		try {
			 //logger
			 LOGGER = logger;
			
			 //Create Session	    	 
	    	 session = createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD")); 
	    	 
	    	 if(session!=null){    		 
			
			 //using transactions in code
	    	 sMgr = session.getSessionManager();
	    	 scopeMgr = sMgr.getScopeManager();	    	 
	    	 scopeMgr.enableServerScope(true);	    	
	    	 scopeMgr.setDefaultScope(ScopeBoundary.BATCH, true);   	 
	    	 
	    	 bmgr = session.getBatchManager();
	    	 bmgr.openBatch(bmgr.getMaxBatchSize(), true, true, true, null);
			
			for (int i=0; i<unlink_docids.size(); i++){	
				
				//current document r_object_id			
				IDfSysObject sysObj = (IDfSysObject)session.getObject(new DfId(unlink_docids.get(i)));
				
				if(sysObj!=null){
					
					if(!sysObj.getString("doc_upload_status").equals("Deleted")){
									
						//unlink code
						IDfId folderId = session.getIdByQualification("dm_folder " +
								"where any r_folder_path = '" + unlink_folder_path.get(i) + "'");				
						sysObj.unlink(folderId.toString());
						sysObj.save();				
						
						count++;
						successMsg = "success";
					}
					else{
						successMsg = "Document(s) Doesn't Exist in ECM to Unlink.";
					}
				}
			}
			
			   if(count==unlink_docids.size()){
		          
		          //commit
		          bmgr.commitBatch();
		          bmgr.closeBatch();
		          LOGGER.debug(count + " Document(s) Unlinked Successfully.");
		          
	           }else{
	        	  
	        	  bmgr.abortBatch();	        	  
				  successMsg = "Document(s) Doesn't Exist in ECM to Unlink.";				     	  
	           }
	    	 }
	    	 else{					
					successMsg = "Session Not Created.";									
				}
			
		} catch (Exception e) {
			bmgr.abortBatch();
			successMsg = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (DS09) : ", e.fillInStackTrace());
		}
		finally{
	    	 try {
	    		 if(bmgr!=null){
	    		 if(bmgr.isBatchActive())
	    			 bmgr.abortBatch();
	    		 }
	    		 
				if(session!=null){
					 releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }	   
				
		return successMsg;
	}
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {		
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				
				LOGGER.debug("Session Created Successfully.");				
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (DS04) : ", e.fillInStackTrace());
		}		
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
				
		try {
			sMgr.release(session);	
			LOGGER.debug("Session Released.");
			LOGGER.debug("LOS Delete Service Request Completed Successfully.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (DS10) : ", e.fillInStackTrace());
		}		
		
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {		
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (DS05) : ", e.fillInStackTrace());
		}		
		
		return idfsessionmanager;
	}	
		

}

