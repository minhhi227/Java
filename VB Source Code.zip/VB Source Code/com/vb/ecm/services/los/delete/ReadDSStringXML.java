/**
* ______________________________________________________________________________
*
* File: ReadDSStringXML.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 13, 2012   5:45:10 PM   2012
* Description: This class is used to get all the input values that are passed 
* 			   from LOS that is reading the String XML and collecting all the
* 			   input values to process the request. 
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.delete;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 13, 2012
 * @Last Modification Time   1:17:46 PM
 * @Last Modification Year   2012
 * 
 */

import java.io.StringReader;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
 
public class ReadDSStringXML {
	
	//User Id
	private String userId = null;
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	//Message Type
	private String messageType = null;
	
	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	//Application Id
	private String appId = null;
	
	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	//Request Time Stamp
	private String reqtimeStamp = null;
		
	/**
	 * @return the reqtimeStamp
	 */
	public String getReqtimeStamp() {
		return reqtimeStamp;
	}

	/**
	 * @param reqtimeStamp the reqtimeStamp to set
	 */
	public void setReqtimeStamp(String reqtimeStamp) {
		this.reqtimeStamp = reqtimeStamp;
	}

	//doc id's to be deleted
	private ArrayList<String> delete_docids = new ArrayList<String>();
	
	/**
	 * @return the delete_docids
	 */
	public ArrayList<String> getDelete_docids() {
		return delete_docids;
	}

	/**
	 * @param delete_docids the delete_docids to set
	 */
	public void setDelete_docids(ArrayList<String> delete_docids) {
		this.delete_docids = delete_docids;
	}

	//doc id's to be unlinked
	private ArrayList<String> unlink_docids = new ArrayList<String>();	
	
	/**
	 * @return the unlink_docids
	 */
	public ArrayList<String> getUnlink_docids() {
		return unlink_docids;
	}

	/**
	 * @param unlink_docids the unlink_docids to set
	 */
	public void setUnlink_docids(ArrayList<String> unlink_docids) {
		this.unlink_docids = unlink_docids;
	}

	//unlink folder paths
	private ArrayList<String> unlink_folder_path = new ArrayList<String>();
		
	/**
	 * @return the unlink_folder_path
	 */
	public ArrayList<String> getUnlink_folder_path() {
		return unlink_folder_path;
	}

	/**
	 * @param unlink_folder_path the unlink_folder_path to set
	 */
	public void setUnlink_folder_path(ArrayList<String> unlink_folder_path) {
		this.unlink_folder_path = unlink_folder_path;
	}
	
	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;

	/** 
	 * Method Description: This method is used to process the input data that is collecting all the
* 			   			   input values to further process the request.                    
	 * 
	 * @param String XML : Contains all the required information from LOS to perform delete operation.	
	 * 	                    
	 * @return void		 : returns no value.
	 */
	public String processInputData(Logger logger, ResourceBundle rsb, String inputStringXml, String reqReceivedDate, 
			String status, String errorCode, String errorMessage){
		
		String outputStrXml = "success";
		
		try {
			//logger
			LOGGER = logger;			
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();			
			
			InputSource is = new InputSource();			
		    is.setCharacterStream(new StringReader(inputStringXml));		    
			Document doc = dBuilder.parse(is);			
			doc.getDocumentElement().normalize(); 			
			
			//header element
			NodeList nList = doc.getElementsByTagName("header");
	 
			   Node nNode = nList.item(0);
			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) nNode;		      
			      
			      if(getTagValue("user_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"user_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("message_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"message_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("source_app_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"source_app_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("request_timestamp", eElement) == null){
			    	
			    	  outputStrXml = "The element type \"request_timestamp\" doesn't exist in request.";
			      }
			      else{			      
				      setUserId(getTagValue("user_id", eElement));			      
				      setMessageType(getTagValue("message_type", eElement));			      
				      setAppId(getTagValue("source_app_id", eElement));			     
				      setReqtimeStamp(getTagValue("request_timestamp", eElement));
			      }	 
			   }			
			
			//Document element
			   
			//to delete documents
			if(messageType.equals(rsb.getString("DELETE_MESSAGE_TYPE"))){
				
				NodeList docList = doc.getElementsByTagName("Document");
				LOGGER.debug("Input Parameters for Delete Service");
				 
				for (int temp = 0; temp < docList.getLength(); temp++) {
		 
				   Node node = docList.item(temp);
				   if (node.getNodeType() == Node.ELEMENT_NODE) {
		 
				      Element eElement = (Element) node;			      
				      
				      if(getTagValue("document_id", eElement) != null){
				    	  
				    	  String document_id = getTagValue("document_id", eElement);				      
				      
					       if(!document_id.equalsIgnoreCase("")){
					    	   
						      //add document id for delete operation
					    	  delete_docids.add(document_id);
					    	  LOGGER.debug("Document " + (temp + 1) + " Id is : " + document_id);
					       }
					       else{
					    	   outputStrXml = "Missing Mandatory Values from client to perform Delete Operation.";
					       }
				      }
				      else{
				    	  outputStrXml = "The element type \"document_id\" doesn't exist in request.";
				          }
				   }
				   
				}
				
				setDelete_docids(delete_docids);
			}
			//to unlink documents
			else if(messageType.equals(rsb.getString("UNLINK_MESSAGE_TYPE"))){
				
				NodeList docList = doc.getElementsByTagName("Document");
				LOGGER.debug("Input Parameters for Unlink Service (Only for Collateral Documents)");
				 
				for (int temp = 0; temp < docList.getLength(); temp++) {
		 
				   Node node = docList.item(temp);
				   if (node.getNodeType() == Node.ELEMENT_NODE) {
		 
				      Element eElement = (Element) node;		      
				      
				      //Document Id
				      if(getTagValue("document_id", eElement) == null){
				    	  
				    	  outputStrXml = "The element type \"document_id\" doesn't exist in request.";
				      }
				      else if(getTagValue("branch_number", eElement) == null){
				    	  
				    	  outputStrXml = "The element type \"branch_number\" doesn't exist in request.";		    	 
				      }
				      else if(getTagValue("cust_type", eElement) == null){
				    	  
				    	  outputStrXml = "The element type \"cust_type\" doesn't exist in request.";
				      }
				      else if(getTagValue("cust_id_number", eElement) == null){
				    	  
				    	  outputStrXml = "The element type \"cust_id_number\" doesn't exist in request.";
				      }
				      else if(getTagValue("cust_id_type", eElement) == null){
				    	  
				    	  outputStrXml = "The element type \"cust_id_type\" doesn't exist in request.";
				      }				      		    	  
				      else if(getTagValue("car_year_created", eElement) == null){
			    		  
			    		  outputStrXml = "The element type \"car_year_created\" doesn't exist in request.";
			    	  }	
				      else if(getTagValue("doc_sub_type", eElement) == null){
				    	  
				    	  outputStrXml = "The element type \"doc_sub_type\" doesn't exist in request.";
				      }
				      else if(getTagValue("collateral_number", eElement) == null){
			    		  
			    		  outputStrXml = "The element type \"collateral_number\" doesn't exist in request.";
			    	  }			      
				      else{		      
				    	  String document_id = getTagValue("document_id", eElement);				      
					      String branch_number = getTagValue("branch_number", eElement);
					      String cust_type = getTagValue("cust_type", eElement);
				          String cust_id_number = getTagValue("cust_id_number", eElement);
				          String cust_id_type = getTagValue("cust_id_type", eElement);		          
					      String car_year_created = getTagValue("car_year_created", eElement);
					      String doc_sub_type = getTagValue("doc_sub_type", eElement);
					      String coll_num = getTagValue("collateral_number", eElement);				     	      
				      
				         if(!branch_number.equalsIgnoreCase("") && !cust_type.equalsIgnoreCase("") && 
				    	 !cust_id_number.equalsIgnoreCase("") && !cust_id_type.equalsIgnoreCase("") && 
				         !car_year_created.equalsIgnoreCase("") && !doc_sub_type.equalsIgnoreCase("") &&
				    	 !coll_num.equalsIgnoreCase("") && !document_id.equalsIgnoreCase("")){				    	 
				      
					      //add document id for unlink operation
				    	  unlink_docids.add(document_id);
				    	  String folder_path = "/" + rsb.getString("CABINET_NAME") + branch_number + "/" + 
				    	  cust_type + "/" + cust_id_number + "-" + cust_id_type + "/" + 
				    	  rsb.getString("LOAN_DOCS_FOLDER_NAME") + "/" + car_year_created + "/" + doc_sub_type + "/" + 
				    	  coll_num;	
				    	  
				    	  //add document folder path
				    	  unlink_folder_path.add(folder_path);
				    	  LOGGER.debug("Unlink Document with Document Id : " + document_id 
				    			  + " From Folder Path in ECM @ " + folder_path);
				    	  
				      }else{
				    	  outputStrXml = "Missing Mandatory Values from client to perform Delete Operation.";
				      }
				   }
				      
				   }
				   
				}
				
				setUnlink_docids(unlink_docids);
				setUnlink_folder_path(unlink_folder_path);
			}
			else{
				LOGGER.debug("Missing Mandatory Values from client to perform Delete Operation.");
			}	 
			 
		} catch (Exception e) {
			
			outputStrXml = e.getMessage();
			LOGGER.error("Error Code (DS02) : ", e.fillInStackTrace());
		}
		
		return outputStrXml;
	}
	
	private String getTagValue(String sTag, Element eElement) {
		  
		String tagValue = null;
		
		try {
			NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
 
			    Node nValue = (Node) nlList.item(0); 
			    
			    if(nValue!=null){
			    	tagValue = nValue.getNodeValue();
			    }
			    else{
			    	tagValue = "";
			    }
			    
		} catch (Exception e) {
			
			LOGGER.error("Error Code (DS03) : ", e.fillInStackTrace());
		}
	 
		return tagValue;
	  }
	
 
}
