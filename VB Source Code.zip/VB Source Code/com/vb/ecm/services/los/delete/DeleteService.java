/**
* ______________________________________________________________________________
*
* File: DeleteService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 13, 2012   3:17:46 PM   2012
* Description: This class is the main class (Service Class) and will perform 
* 			   following things:
* 				1. Retrieves all the required info from the input String XML 
* 				   using ReadDSStringXML Class.
*               2. Performs Delete and Unlink operations using DeleteDocs Class.
*               3. Writes all the collected info into a String XML using 
*                  WriteDSStringXML Class. 
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.delete;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.fc.common.DfLogger;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 13, 2012
 * @Last Modification Time   1:17:46 PM
 * @Last Modification Year   2012
 */

@DfsPojoService(targetNamespace = "http://delete.los.services.ecm.vb.com", requiresAuthentication = true)
public class DeleteService {		
		
	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;
	
	//Resource Bundle
	private ResourceBundle rsb = null;
	
	//Received Date
	private String reqReceivedDate = null;
	
	//Status
	private String status = null;
	
	//Error Code
	private String errorCode = null;
	
	//Error Message
	private String errorMessage = null;
	
	//Output String XML
	private String outputStrXml = null;

	 /** 
	 * Method Description: This method is used to delete the document(s) or unlink the document(s) based on 
	 * 					   the information provided from Client in String XML format.                     
	 * 
	 * @param String     : inputStringXML contains all the required information to perform delete or unlink operation.
	 *                     
	 * @return String	 : outputStrXml which contains all the collected information in String XML format.
	 */		
	public String deleteDocuments(String inputStringXml){		
		
		try {
			//logger
			LOGGER = DfLogger.getLogger(DeleteService.class);
			LOGGER.debug("LOS Delete Service Request Started..");
			
			//resource bundle
			rsb = ResourceBundle.getBundle("com.vb.ecm.services.los.LOSConfig");
			
			//request received date			
		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    reqReceivedDate = sdf.format(new Date());		    
			
			//read input values from string xml
			ReadDSStringXML inputStrXmlObj = new ReadDSStringXML();			
			outputStrXml = inputStrXmlObj.processInputData(LOGGER, rsb, inputStringXml, reqReceivedDate, status, 
					errorCode, errorMessage);
			
			if(outputStrXml.equals("success")){
			
			//delete docs
			if(!inputStrXmlObj.getUserId().equalsIgnoreCase("") && 
				  inputStrXmlObj.getMessageType().equals(rsb.getString("DELETE_MESSAGE_TYPE")) && 
					inputStrXmlObj.getAppId().equals(rsb.getString("SOURCE_APP_ID")) && 
					  (inputStrXmlObj.getDelete_docids().size() > 0) &&
						 !inputStrXmlObj.getReqtimeStamp().equalsIgnoreCase("")){				
				
				//deleting documents from ECM
				DeleteDocs deleteDocsObj = new DeleteDocs();
				String successMsg = deleteDocsObj.deleteDocuments(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
						errorCode, errorMessage, inputStrXmlObj.getDelete_docids());
				
				//clear array list
				inputStrXmlObj.getDelete_docids().clear();
				
				if(successMsg.contains("Session Not Created.")){					
					
					status = "1";
					errorCode = "DS04";
					errorMessage = "Session Not Created.";
					WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage);					
				}
				else if(successMsg.contains("Document(s) Doesn't Exist in ECM to Delete.")){
					
					status = "1";
				    errorCode = "DS06";
				    errorMessage = "Document(s) Doesn't Exist in ECM to Delete.";
				    WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage);					
				}
				else if(!successMsg.contains("Error :")){
					
					status = "0";
		            errorCode = "";
		            errorMessage = "";
					//write output values to string xml					
				    WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage);
				}
				else{
					status = "1";
				    errorCode = "DS08";
				    errorMessage = successMsg;
				    WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage);
				}				
			}
			else if(!inputStrXmlObj.getUserId().equalsIgnoreCase("") && 
					   inputStrXmlObj.getMessageType().equals(rsb.getString("UNLINK_MESSAGE_TYPE")) && 
						 inputStrXmlObj.getAppId().equals(rsb.getString("SOURCE_APP_ID")) && 
						   (inputStrXmlObj.getUnlink_docids().size() > 0) && 
						      !inputStrXmlObj.getReqtimeStamp().equalsIgnoreCase("")){				
				
				//unlink documents from ECM
				DeleteDocs deleteDocsObj = new DeleteDocs();
				String successMsg = deleteDocsObj.unlinkDocuments(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
						errorCode, errorMessage, inputStrXmlObj.getUnlink_docids(), inputStrXmlObj.getUnlink_folder_path());
				
				//clear array list
				inputStrXmlObj.getUnlink_docids().clear();
				inputStrXmlObj.getUnlink_folder_path().clear();				
				
				if(successMsg.contains("Session Not Created.")){
					
					status = "1";
					errorCode = "DS04";
					errorMessage = "Session Not Created.";
					WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage);
				}
				else if(successMsg.contains("Document(s) Doesn't Exist in ECM to Unlink.")){
					
					status = "1";
				    errorCode = "DS06";
				    errorMessage = "Document(s) Doesn't Exist in ECM to Unlink.";
				    WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage); 
				}
				else if(!successMsg.contains("Error :")){
					
					status = "0";
		            errorCode = "";
		            errorMessage = "";
					//write output values to string xml
					WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage);
				}
				else{
					status = "1";
				    errorCode = "DS10";
				    errorMessage = successMsg;
				    WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage);
				}				
			}
			else{
				status = "1";
				errorCode = "DS01";
				errorMessage = "Missing Mandatory Values from Client to perform Delete Operation.";
				WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, 
						status, errorCode, errorMessage);
				LOGGER.debug("Missing Mandatory Values from client to perform Delete Operation.");
				}
			}
			else{
				status = "1";
				errorCode = "DS02";
				errorMessage = outputStrXml;
				WriteDSStringXML outputStrXmlObj = new WriteDSStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
			}
			
		} catch (Exception e) {
			
			LOGGER.error("Error Code (DS01) : ", e.fillInStackTrace());
			LOGGER.error("LOS Delete Service Request Completed with Errors.");
		}		
		
		return outputStrXml;
	}	
	
	
}

