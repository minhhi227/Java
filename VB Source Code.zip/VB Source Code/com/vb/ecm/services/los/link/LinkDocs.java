/**
* ______________________________________________________________________________
*
* File: LinkDocs.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 17, 2012   3:17:46 PM   2012
* Description: This class will link (Associates the object with a folder) the 
* 			   documents in ECM repository by using LOS Link Service functionality.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.link;

import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfBatchManager;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfScopeManager;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.ScopeBoundary;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 14, 2012
 * @Last Modification Time   3:17:46 PM
 * @Last Modification Year   2012
 */

public class LinkDocs {       
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;
	
	//flag
	private boolean isCabinetExists = true;	
	private String cabinetName = null;
	
	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;
	private boolean isDeleted = false;
	
	
	 /** 
	 * Method Description: This method is used to link the documents in ECM based on the folder path 
	 * 					   (where to link) provided by LOS Link Functionality.                    
	 * 
	 * @param String[]   : Contains all the document id's of the documents to be linked in ECM.	
	 * 
	 * @param String     : Contains folder path of all the documents to be linked in ECM.
	 *                     
	 * @return String	 : returns Message.
	 */		
	public String linkDocuments(Logger logger, ResourceBundle rsb, String reqReceivedDate, String status, String errorCode, 
			String errorMessage, ArrayList<String> docIds, ArrayList<String> docFolderPath) 
			throws Exception
	 {				
		String successMsg = null;
		int count = 0;		
		IDfScopeManager scopeMgr;
		IDfBatchManager bmgr = null;
		
	     try {
	    	 //logger
			 LOGGER = logger;
	    	 
	    	 //Create Session	    	
	    	 session = createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));
	    	 
	    	 if(session!=null){   	 
	    	 
	    	 //using transactions in code
	    	 sMgr = session.getSessionManager();
	    	 scopeMgr = sMgr.getScopeManager();	    	 
	    	 scopeMgr.enableServerScope(true);	    	
	    	 scopeMgr.setDefaultScope(ScopeBoundary.BATCH, true);   	 
	    	 
	    	 bmgr = session.getBatchManager();
	    	 bmgr.openBatch(bmgr.getMaxBatchSize(), true, true, true, null);
	    	 
	    	//getting all the object id's from docIds
	    	 for (int i = 0; i < docIds.size(); i++) {
	    		 
	    		 successMsg = linkDocument(rsb, docIds.get(i), docFolderPath.get(i));
	    		 
	    		 if(successMsg.equalsIgnoreCase("success")){
			    		count++;
			     }
			 }
	    	 
			    	 if(isCabinetExists == false){		    		  
			    		  bmgr.abortBatch();		        	  
						  successMsg = "Cabinet ( " + cabinetName + " ) Doesn't Exist in ECM to Link. " +
						  		"Please Contact Administrator.";					  
			    	 }
			    	 else if(isDeleted == true){
			    		 
			    		 successMsg = "Error : Document(s) doesn't Exist in ECM to perform Link Operation.";			    		 
			    	 }
			    	 else if(count == docIds.size()){		          
				          //commit
				          bmgr.commitBatch();
				          bmgr.closeBatch();
				          LOGGER.debug(count + " Document(s) Linked Successfully.");
			           }
			    	 else{
			    		 bmgr.abortBatch();		
			    		 //successMsg = "Error : Document(s) doesn't Exist in ECM to perform Link Operation."; 
			    	 }
	    	 }
	    	 else{				
					successMsg = "Session Not Created.";									
				}
	 		
		} catch (Exception e) {
			bmgr.abortBatch();
			successMsg = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (LS04) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
	    		 if(bmgr!=null){
	    		 if(bmgr.isBatchActive())
	    			 bmgr.abortBatch();
	    		 }
	    		 
				if(session!=null){
					 releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }	     
	     
		 return successMsg;
	 }	
	
	 /** 
	 * Method Description: This method actually implements the logic to link the documents in ECM.                    
	 * 
	 * @param String     : Contains documentId and document folder path (where to link).
	 *                     
	 * @return String	 : returns Message.
	 */	
	private String linkDocument(ResourceBundle rsb, String docId, String docFolderPath) throws Exception {		
				
		String successMsg = null;
		IDfSysObject sysObj = null;
		IDfId folderId = null;
		
		try {			
			//current document r_object_id			
			sysObj = (IDfSysObject)session.getObject(new DfId(docId));
			
			if(sysObj!=null){
				
				if(!sysObj.getString("doc_upload_status").contains("Deleted")){
				
					if(isCollateralFolderExists(rsb, docFolderPath)){
					
						//linking of document to other collateral folders
						folderId = session.getIdByQualification("dm_folder where any r_folder_path = '" + docFolderPath + "'");			
						sysObj.link(folderId.toString());
						sysObj.save();
						//LOGGER.debug("Document(s) Linked Successfully.");
						successMsg = "success";
						
					}else{
						
						successMsg = "Error :";
					}
				}
				else{
					isDeleted = true;
					successMsg = "Error :";					
				}
			}
			
		} catch (Exception e) {	
			successMsg = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (LS07) : ", e.fillInStackTrace());
		}		
		
		return successMsg;
	}
	
	/**
	 * Description : This method is used to create custom folders if they don't exist and 
	 *               generate the final destination folder path to link document in ECM.
	 * 
	 * @return boolean : returns true or false value.
	 */	
	private boolean isCollateralFolderExists(ResourceBundle rsb, String docFolderPath) throws Exception {
				
		String custType = null, custIdComb = null;
		String loanDocs = null, car_year_created = null, doc_sub_type = null;
		String collateral_number = null, destFolderPath = null;
		boolean flag = false;
		
		try {			
			String[] folderNames = docFolderPath.split("/");			
			cabinetName = folderNames[1];			
			custType = folderNames[2];			
			custIdComb = folderNames[3];			
			loanDocs = folderNames[4];			
			car_year_created = folderNames[5];			
			doc_sub_type = folderNames[6];			
			collateral_number = folderNames[7];			
			
			//Cabinet - Branch 100
			IDfFolder isBranchExists = session.getFolderByPath("/" + cabinetName);			
			 if(isBranchExists!=null){
				 
				 destFolderPath = "/" + cabinetName;	 				
			 
			 //Folder - Customer Type like Enterprise, Retail etc..			 
			 destFolderPath = isFolderExists(rsb, custType, destFolderPath);				
			 
			 //Folder - Create Customer Folder				 
			 IDfFolder isCustFldrExists = session.getFolderByPath(destFolderPath + "/" + custIdComb);
			      if(isCustFldrExists!=null){
			    	  
			    	   destFolderPath = destFolderPath + "/" + custIdComb;			    	   
			    	   
			      }else{				    	  
			    	   createCustFolder(rsb, custIdComb, destFolderPath);
			    	   destFolderPath = destFolderPath + "/" + custIdComb;
			      }
			      
			   //Folder - Loan Docs			  
			   destFolderPath = isFolderExists(rsb, loanDocs, destFolderPath);	
			   
			   //Folder - Car Year Created	  
			   destFolderPath = isFolderExists(rsb, car_year_created, destFolderPath);
			   
			   //Folder	- Collateral	  
			   destFolderPath = isFolderExists(rsb, doc_sub_type, destFolderPath);			   
			   
			   //Folder	- Collateral Id Number folder	  
			   destFolderPath = isFolderExists(rsb, collateral_number, destFolderPath);
			   
			   //final destination folder path
			   flag = true;
			   LOGGER.debug("Folder Path to Link : " + destFolderPath);
			 }
			 else{				 
				 flag = false;
				 isCabinetExists = false;				 
				 LOGGER.debug("Cabinet ( " + cabinetName + ") Doesn't Exist. " +
				 		"Please contact Administrator.");
			 }			   			
			
		} catch (Exception e) {			
			
			LOGGER.error("Error Code (LS08) : ", e.fillInStackTrace());
		}		
		
		return flag;
	}
	
	/**
	 * Description : This method is used to check the folder existence in ECM.
	 * 
	 * @return String : Folder Path
	 */	
	private String isFolderExists(ResourceBundle rsb, String folderName, String folderPath) throws Exception {
		String destFldrPath = null;
		
		try {
			IDfFolder isFolderExists = session.getFolderByPath(folderPath + "/" + folderName);
			 if(isFolderExists!=null){
				 destFldrPath = folderPath + "/" + folderName;
			 }
			 else{
				 createFolder(rsb, folderName, folderPath);
				 destFldrPath = folderPath + "/" + folderName;
			 }
		} catch (DfException e) {			
			LOGGER.error("Error Code (LS09) : ", e.fillInStackTrace());
		}
		
		return destFldrPath;
	}
	
	/**
	 * Description : This method is used to create custom folder (vb_folder) in ECM.
	 * 
	 * @return boolean : true
	 */	
	private boolean createFolder(ResourceBundle rsb, String folderName, String folderPath) throws Exception {		
		IDfSysObject sysObj = null;
		boolean flag = false;
		
		try {
			sysObj = (IDfSysObject)session.newObject(rsb.getString("FOLDER_TYPE"));			
			sysObj.setObjectName(folderName); 
			sysObj.setTitle("Folder Created by LOS Link Service");
			sysObj.link(folderPath);
			sysObj.save(); 
			flag = true;			
			
		} catch (DfException e) {			
			LOGGER.error("Error Code (LS10) : ", e.fillInStackTrace());
		}
		
		return flag;		
	}
	
	/**
	 * Description : This method is used to create customer folder and sets customer info to it in ECM.
	 * 
	 * @return boolean : true
	 */	
	private boolean createCustFolder(ResourceBundle rsb, String folderName, String folderPath) 
			throws Exception {		
		IDfSysObject sysObj = null;
		boolean flag = false;	
		
		try {					
			sysObj = (IDfSysObject)session.newObject(rsb.getString("CUST_FOLDER_TYPE"));			
			sysObj.setObjectName(folderName); 
			sysObj.setTitle("Folder Created by LOS Link Service");
			
			//setting customer info to folder		
			sysObj.link(folderPath);
			sysObj.save(); 
			flag = true;			
			
		} catch (DfException e) {			
			LOGGER.error("Error Code (LS11) : ", e.fillInStackTrace());
		}
		return flag;
		
	}	
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {		
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				
				LOGGER.debug("Session Created Successfully.");				
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (LS05) : ", e.fillInStackTrace());
		}		
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
				
		try {
			sMgr.release(session);
			LOGGER.debug("Session Released.");
			LOGGER.debug("LOS Link Service Request Completed Successfully.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (LS12) : ", e.fillInStackTrace());
		}		
		
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {		
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (LS06) : ", e.fillInStackTrace());
		}		
		
		return idfsessionmanager;
	}	
		

}

