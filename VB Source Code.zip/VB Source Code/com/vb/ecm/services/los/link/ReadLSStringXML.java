/**
* ______________________________________________________________________________
*
* File: ReadLSStringXML.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 17, 2012   3:17:46 PM   2012
* Description: This class is used to get all the input values that are passed 
* 			   from LOS that is reading the String XML and collecting all the
* 			   input values to process the request. 
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.link;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 14, 2012
 * @Last Modification Time   3:17:46 PM
 * @Last Modification Year   2012
 * 
 */

import java.io.StringReader;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
 
public class ReadLSStringXML {
	
	//User Id
	private String userId = null;
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	//Message Type
	private String messageType = null;
	
	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	//Application Id
	private String appId = null;	
	
	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	//Request Time Stamp
	private String reqtimeStamp = null;
	
	/**
	 * @return the reqtimeStamp
	 */
	public String getReqtimeStamp() {
		return reqtimeStamp;
	}

	/**
	 * @param reqtimeStamp the reqtimeStamp to set
	 */
	public void setReqtimeStamp(String reqtimeStamp) {
		this.reqtimeStamp = reqtimeStamp;
	}

	//doc id's to link
	private ArrayList<String> linkDocIds = new ArrayList<String>();		
	
	/**
	 * @return the linkDocIds
	 */
	public ArrayList<String> getLinkDocIds() {
		return linkDocIds;
	}

	/**
	 * @param linkDocIds the linkDocIds to set
	 */
	public void setLinkDocIds(ArrayList<String> linkDocIds) {
		this.linkDocIds = linkDocIds;
	}

	//doc's folder path
	private ArrayList<String> linkDocsFolderPath = new ArrayList<String>();
	
	/**
	 * @return the linkDocsFolderPath
	 */
	public ArrayList<String> getLinkDocsFolderPath() {
		return linkDocsFolderPath;
	}

	/**
	 * @param linkDocsFolderPath the linkDocsFolderPath to set
	 */
	public void setLinkDocsFolderPath(ArrayList<String> linkDocsFolderPath) {
		this.linkDocsFolderPath = linkDocsFolderPath;
	}
	
	//Branch Number
	private String branch_number = null;
	
	/**
	 * @return the branch_number
	 */
	public String getBranch_number() {
		return branch_number;
	}

	/**
	 * @param branch_number the branch_number to set
	 */
	public void setBranch_number(String branch_number) {
		this.branch_number = branch_number;
	}

	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER; 

	/** 
	 * Method Description: This method is used to process the input data that is collecting all the
* 			   			   input values to further process the request.                    
	 * 
	 * @param String XML : Contains all the required information from LOS to perform link operation.	
	 * 	                    
	 * @return void		 : returns no value.
	 */
	public String processInputData(Logger logger, ResourceBundle rsb, String inputStringXml, String reqReceivedDate, 
			String status, String errorCode, String errorMessage){
		
		String outputStrXml = "success";
		
		try {
			//logger
			LOGGER = logger;
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(inputStringXml));	    
			Document doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize(); 
			
			//header element
			NodeList nList = doc.getElementsByTagName("header");			
	 
			   Node nNode = nList.item(0);
			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) nNode;		      
			      
			      if(getTagValue("user_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"user_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("message_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"message_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("source_app_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"source_app_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("request_timestamp", eElement) == null){
			    	
			    	  outputStrXml = "The element type \"request_timestamp\" doesn't exist in request.";
			      }
			      else{			      
				      setUserId(getTagValue("user_id", eElement));			      
				      setMessageType(getTagValue("message_type", eElement));			      
				      setAppId(getTagValue("source_app_id", eElement));			     
				      setReqtimeStamp(getTagValue("request_timestamp", eElement));
			      }	 
			   }			
			
			//Document element
			NodeList docList = doc.getElementsByTagName("Document");
			LOGGER.debug("Input Parameters for Link Service");
	 
			for (int temp = 0; temp < docList.getLength(); temp++) {
	 
			   Node node = docList.item(temp);
			   if (node.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) node;
			      
			      //Document Id
			      if(getTagValue("document_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"document_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("branch_number", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"branch_number\" doesn't exist in request.";		    	 
			      }
			      else if(getTagValue("cust_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("cust_id_number", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_id_number\" doesn't exist in request.";
			      }
			      else if(getTagValue("cust_id_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_id_type\" doesn't exist in request.";
			      }				      		    	  
			      else if(getTagValue("car_year_created", eElement) == null){
		    		  
		    		  outputStrXml = "The element type \"car_year_created\" doesn't exist in request.";
		    	  }	
			      else if(getTagValue("doc_sub_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"doc_sub_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("collateral_number", eElement) == null){
		    		  
		    		  outputStrXml = "The element type \"collateral_number\" doesn't exist in request.";
		    	  }			      
			      else{	      
				      String document_id = getTagValue("document_id", eElement);
				      setBranch_number(getTagValue("branch_number", eElement));
				      String cust_type = getTagValue("cust_type", eElement);
			          String cust_id_number = getTagValue("cust_id_number", eElement);
			          String cust_id_type = getTagValue("cust_id_type", eElement);		          
				      String car_year_created = getTagValue("car_year_created", eElement);
				      String doc_sub_type = getTagValue("doc_sub_type", eElement);
				      String coll_num = getTagValue("collateral_number", eElement);			      
				      
				      if(!getBranch_number().equalsIgnoreCase("") && !cust_type.equalsIgnoreCase("") && 
				    	 !cust_id_number.equalsIgnoreCase("") && !cust_id_type.equalsIgnoreCase("") && 
				         !car_year_created.equalsIgnoreCase("") && !doc_sub_type.equalsIgnoreCase("") &&
				    	 !coll_num.equalsIgnoreCase("") && !document_id.equalsIgnoreCase("")){
				    	  
				    	  //add document id for link operation
				    	  linkDocIds.add(document_id);
				    	  
				    	  //add document folder path
				    	  String folder_path = "/" + rsb.getString("CABINET_NAME") + getBranch_number() + "/" + 
				    	  cust_type + "/" + cust_id_number + "-" + cust_id_type + "/" + 
				    	  rsb.getString("LOAN_DOCS_FOLDER_NAME") + "/" + car_year_created + "/" + doc_sub_type + "/" + 
				    	  coll_num;	    	 
				    	  linkDocsFolderPath.add(folder_path);
				    	  LOGGER.debug("Link Document with Document Id : " + document_id 
				    			  + " @ Folder Path in ECM : " + folder_path);
				      }
				      else{
				    	  outputStrXml = "Missing Mandatory Values from client to perform Link Operation.";
				      }			    	  
			      }	      
	 
			   }
			}
			
			setLinkDocIds(linkDocIds);
			setLinkDocsFolderPath(linkDocsFolderPath);
			   
		} catch (Exception e) {
			
			outputStrXml = e.getMessage();
			LOGGER.error("Error Code (LS02) : ", e.fillInStackTrace());
		}
		
		return outputStrXml;
	}
	
	private String getTagValue(String sTag, Element eElement) {
		  
		String tagValue = null;
		
		try {
			NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
 
			    Node nValue = (Node) nlList.item(0); 
			    
			    if(nValue!=null){
			    	tagValue = nValue.getNodeValue();
			    }
			    else{
			    	tagValue = "";
			    }
			    
		} catch (Exception e) {
			
			LOGGER.error("Error Code (LS03) : ", e.fillInStackTrace());
		}
	 
		return tagValue;
	  }
	
 
}
