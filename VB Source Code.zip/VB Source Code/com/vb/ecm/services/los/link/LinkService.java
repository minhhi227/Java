/**
* ______________________________________________________________________________
*
* File: LinkService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 17, 2012   3:17:46 PM   2012
* Description: This class is the main class (Service Class) and will perform 
* 			   following things:
* 				1. Retrieves all the required info from the input String XML 
* 				   using ReadLSStringXML Class.
*               2. Associates the object (documents) with a folder using 
*                  LinkDocs Class.
*               3. Writes all the collected info into a String XML using 
*                  WriteLSStringXML Class. 
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.link;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.fc.common.DfLogger;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 14, 2012
 * @Last Modification Time   3:17:46 PM
 * @Last Modification Year   2012
 */

@DfsPojoService(targetNamespace = "http://link.los.services.ecm.vb.com", requiresAuthentication = true)
public class LinkService {		
		
	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;
	
	//Resource Bundle
	private ResourceBundle rsb = null;
	
	//Received Date
	private String reqReceivedDate = null;
	
	//Status
	private String status = null;
	
	//Error Code
	private String errorCode = null;
	
	//Error Message
	private String errorMessage = null;
	
	//Output String XML
	private String outputStrXml = null;

	 /** 
	 * Method Description: This method is used to link the document(s) based on folder path
	 * 					   (where to link) provided from Client in String XML format.                     
	 * 
	 * @param String     : inputStringXML contains all the required information (folder path) 
	 * 					   to perform link operation.
	 *                     
	 * @return String	 : outputStrXml which contains all the collected information in String XML format.
	 */		
	public String linkDocuments(String inputStringXml){		
		
		try {
			//logger
			LOGGER = DfLogger.getLogger(LinkService.class);
			LOGGER.debug("LOS Link Service Request Started..");
			
			//resource bundle
			rsb = ResourceBundle.getBundle("com.vb.ecm.services.los.LOSConfig");
			
			//request received date			
		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    reqReceivedDate = sdf.format(new Date());		    
			
			//read input values from string xml
			ReadLSStringXML inputStrXmlObj = new ReadLSStringXML();
			outputStrXml = inputStrXmlObj.processInputData(LOGGER, rsb, inputStringXml, reqReceivedDate, status, 
					errorCode, errorMessage);
			
			if(outputStrXml.equals("success")){
			
			//link documents
			if(!inputStrXmlObj.getUserId().equalsIgnoreCase("") && 
				  inputStrXmlObj.getMessageType().equals(rsb.getString("LINK_MESSAGE_TYPE")) && 
					inputStrXmlObj.getAppId().equals(rsb.getString("SOURCE_APP_ID")) && 
					  (inputStrXmlObj.getLinkDocIds().size() > 0) && 
					     !inputStrXmlObj.getReqtimeStamp().equalsIgnoreCase("")){				
				
				//link documents in ECM based on the folder path provided
				LinkDocs linkDocsObj = new LinkDocs();				
				String successMsg = linkDocsObj.linkDocuments(LOGGER, rsb,reqReceivedDate, status, errorCode, 
						errorMessage, inputStrXmlObj.getLinkDocIds(), inputStrXmlObj.getLinkDocsFolderPath());
				
				//clear array list
				inputStrXmlObj.getLinkDocIds().clear();
				inputStrXmlObj.getLinkDocsFolderPath().clear();	
				
				if(successMsg.contains("Session Not Created.")){
					
					status = "1";
					errorCode = "LS05";
					errorMessage = "Session Not Created.";
					WriteLSStringXML outputStrXmlObj = new WriteLSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}
				else if(successMsg.contains("Cabinet ( Branch " + inputStrXmlObj.getBranch_number() + " ) Doesn't Exist in ECM to Link. " +
					  		"Please Contact Administrator.")){
					
					status = "1";
				    errorCode = "LS08";
				    errorMessage = "Cabinet ( Branch " + inputStrXmlObj.getBranch_number() + " ) Doesn't Exist in ECM to Link. " +
				  		"Please Contact Administrator.";
				    WriteLSStringXML outputStrXmlObj = new WriteLSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage); 
				}
				else if(!successMsg.contains("Error :")){
					
					status = "0";
		            errorCode = "";
		            errorMessage = "";
					//write output values to string xml					
				    WriteLSStringXML outputStrXmlObj = new WriteLSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}
				else{
					status = "1";
				    errorCode = "LS07";
				    errorMessage = successMsg;
				    WriteLSStringXML outputStrXmlObj = new WriteLSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}				
			}			
			else{
				status = "1";
				errorCode = "LS01";
				errorMessage = "Missing Mandatory Values from Client to perform Link Operation.";
				WriteLSStringXML outputStrXmlObj = new WriteLSStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
				LOGGER.debug("Missing Mandatory Values from client to perform Link Operation.");
				}
			}
			else{
				status = "1";
				errorCode = "LS02";
				errorMessage = outputStrXml;
				WriteLSStringXML outputStrXmlObj = new WriteLSStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
			}
			
		} catch (Exception e) {
			
			LOGGER.error("Error Code (LS01) : ", e.fillInStackTrace());
			LOGGER.error("LOS Link Service Request Completed with Errors.");
		}		
		
		return outputStrXml;
	}	
	
	
}

