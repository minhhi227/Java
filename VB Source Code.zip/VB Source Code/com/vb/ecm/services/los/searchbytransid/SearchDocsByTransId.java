/**
* ______________________________________________________________________________
*
* File: SearchDocsByTransId.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 15, 2012   3:19:18 PM   2012
* Description: This class will return a list of documents (Document Id, Document Name 
	           URL Link, Creation Date and Upload By) based on the Transaction ID 
	           provided by LOS-Search by Transaction ID Functionality.              
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.searchbytransid;

import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 15, 2012
 * @Last Modification Time   3:19:18 PM
 * @Last Modification Year   2012 
 */

public class SearchDocsByTransId {	   
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;
	
	//array list to store results
	//Document Id
	private ArrayList<String> documentId = new ArrayList<String>();
	
	/**
	 * @return the documentId
	 */
	public ArrayList<String> getDocumentId() {
		return documentId;
	}

	/**
	 * @param documentId the documentId to set
	 */
	public void setDocumentId(ArrayList<String> documentId) {
		this.documentId = documentId;
	}

	//Document Name
	private ArrayList<String> documentName = new ArrayList<String>();
	
	/**
	 * @return the documentName
	 */
	public ArrayList<String> getDocumentName() {
		return documentName;
	}

	/**
	 * @param documentName the documentName to set
	 */
	public void setDocumentName(ArrayList<String> documentName) {
		this.documentName = documentName;
	}

	//Branch Number
	private ArrayList<String> branchNumber = new ArrayList<String>();
	
	/**
	 * @return the branchNumber
	 */
	public ArrayList<String> getBranchNumber() {
		return branchNumber;
	}

	/**
	 * @param branchNumber the branchNumber to set
	 */
	public void setBranchNumber(ArrayList<String> branchNumber) {
		this.branchNumber = branchNumber;
	}

	//Creation Date
	private ArrayList<String> creationDate = new ArrayList<String>();
	
	/**
	 * @return the creationDate
	 */
	public ArrayList<String> getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(ArrayList<String> creationDate) {
		this.creationDate = creationDate;
	}

	//Upload By
	private ArrayList<String> uploadBy = new ArrayList<String>();
	
	/**
	 * @return the uploadBy
	 */
	public ArrayList<String> getUploadBy() {
		return uploadBy;
	}

	/**
	 * @param uploadBy the uploadBy to set
	 */
	public void setUploadBy(ArrayList<String> uploadBy) {
		this.uploadBy = uploadBy;
	}

	// Initialising the logger from org.apache.Log4j  	
	private Logger LOGGER;
	
	//Output String XML
	private String outputStrXml = null;
	
	 /** 
	 * Method Description: This method will return a list of documents (Document Id, Document Name 
	 * 					   URL Link, Creation Date and Upload By) based on the Transaction ID 
	 * 					   provided by LOS Search functionality.                    
	 * 
	 * @param String     : Transaction ID.	
	 *                     
	 * @return void      : returns no value.
	 */		
	public String searchByTransId(Logger logger, ResourceBundle rsb, ReadSTIStringXML inputStrXmlObj, 
			SearchDocsByTransId searchSrvObj, String reqReceivedDate, String status, String errorCode, 
			String errorMessage, String transId) throws Exception 
	 {
		boolean noResultsFound = false;
		
	     try {
	    	 //logger
	    	 LOGGER = logger;
	    	 
	    	 //Create Session	    	
	    	 session = createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));
	    	 
	    	 if(session!=null){
	    	 
	    	 //calling executeQuery method	    	 	    		 
	    	 noResultsFound = executeQuery(rsb, inputStrXmlObj, searchSrvObj, reqReceivedDate, status, 
	    			 errorCode, errorMessage, transId);
	    	 
	    	  if(noResultsFound==true){
	    		  
	    		status = "2";
	  			errorCode = "SBTI04";
	  			errorMessage = "Document(s) not yet Uploaded.";
	  			WriteSTIStringXML outputStrXmlObj = new WriteSTIStringXML();
	  			outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, searchSrvObj, reqReceivedDate, 
	  					status, errorCode, errorMessage);
	    	  }
	    	  else{
	    		  //LOGGER.debug("Document(s) Retrieved Successfully for Transaction Id : " + inputStrXmlObj.getTrans_id());
	    	  }
	    	  
	    	 }
	    	 else{	    		    
	    		 	status = "1";
					errorCode = "SBTI05";
					errorMessage = "Session Not Created.";
					WriteSTIStringXML outputStrXmlObj = new WriteSTIStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, searchSrvObj, reqReceivedDate, 
							status, errorCode, errorMessage);				
				}
	 		
		} catch (Exception e) {	
			
			LOGGER.error("Error Code (SBTI04) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 releaseSession();
				 }
			} catch (Exception e) {			
				e.printStackTrace();
			}
	     }
	     
	     return outputStrXml;
	    
	 }	
	
	 /** 
	 * Method Description: This method is used to execute the search by transaction id query.                    
	 * 
	 * @param String     : Transaction ID.	
	 *                     
	 * @return boolean   : returns true or false value.
	 */	
	private boolean executeQuery(ResourceBundle rsb, ReadSTIStringXML inputStrXmlObj, SearchDocsByTransId searchSrvObj, 
			String reqReceivedDate, String status, String errorCode, String errorMessage, String transId) 
					throws Exception {			
		
		IDfClientX clientx = null;
		IDfQuery query = null;
		IDfCollection coll = null;
		boolean noResultsFound = true;
		int count = 0;
		
		try { 
			clientx = new DfClientX();
			query =clientx.getQuery();
			
			query.setDQL("SELECT r_object_id, object_name, branch_number, r_creation_date, upload_by FROM vb_los_docs " +
					"WHERE trans_id = '" + transId + "' AND doc_upload_status!='Deleted'");
			LOGGER.debug("Query : " + "SELECT r_object_id, object_name, branch_number, r_creation_date, upload_by FROM vb_los_docs " +
					"WHERE trans_id = '" + transId + "' AND doc_upload_status!='Deleted'");
			
			coll = query.execute(session, IDfQuery.DF_READ_QUERY);
			
			while(coll.next()){
				
				noResultsFound = false;
				count++;
				
				//adding results to list
				documentId.add(coll.getString("r_object_id"));
				documentName.add(coll.getString("object_name"));
				branchNumber.add(coll.getString("branch_number"));
				creationDate.add(coll.getString("r_creation_date"));
				uploadBy.add(coll.getString("upload_by"));
			}
			
			//setters
			setDocumentId(documentId);
			setDocumentName(documentName);
			setBranchNumber(branchNumber);
			setCreationDate(creationDate);
			setUploadBy(uploadBy);
			
			coll.close();
			
			if(noResultsFound == false){
				status = "0";
				errorCode = "";
				errorMessage = "";
				LOGGER.debug("Query Executed & " + count + " Document(s) Retrieved Successfully for Transaction Id : " + transId);
				//write results to outputStrXml
				WriteSTIStringXML outputStrXmlObj = new WriteSTIStringXML();
				outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, searchSrvObj, reqReceivedDate, 
						status, errorCode, errorMessage);
			}
			
		} catch (Exception e) {
			noResultsFound = false;
			status = "1";
			errorCode = "SBTI07";
			errorMessage = e.getMessage();
			WriteSTIStringXML outputStrXmlObj = new WriteSTIStringXML();
			outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, searchSrvObj, reqReceivedDate, 
					status, errorCode, errorMessage);			
			LOGGER.error("Error Code (SBTI07) : ", e.fillInStackTrace());
		}
		
		return noResultsFound;
		
	}	
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.debug("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (SBTI05) : ", e.fillInStackTrace());
		}	
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {		
		
		try {
			sMgr.release(session);
			LOGGER.debug("Session Released.");
			LOGGER.debug("LOS Search By Transaction Id Servie Request Completed Successfully.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (SBTI08) : ", e.fillInStackTrace());
		}		
		
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {		
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (SBTI06) : ", e.fillInStackTrace());
		}
		
		return idfsessionmanager;
	}
	
	
}
