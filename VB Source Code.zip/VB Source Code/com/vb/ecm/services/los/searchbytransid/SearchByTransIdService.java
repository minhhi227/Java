/**
* ______________________________________________________________________________
*
* File: SearchByTransIdService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 15, 2012   9:16:27 AM   2012
* Description: This class is the main class (Service Class) and will perform 
* 			   following things:
* 				1. Retrieves all the required info from the input String XML 
* 				   using ReadSTIStringXML Class.
*               2. Searches the ECM for documents using SearchDocsByTransId
*                  Class.
*               3. Writes all the collected info into a String XML using 
*                  WriteSTIStringXML Class.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.searchbytransid;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.fc.common.DfLogger;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 15, 2012
 * @Last Modification Time   9:16:27 AM
 * @Last Modification Year   2012 
 */

@DfsPojoService(targetNamespace = "http://searchbytransid.los.services.ecm.vb.com", requiresAuthentication = true)
public class SearchByTransIdService {
	
	// Initialising the logger from org.apache.Log4j  	
	private Logger LOGGER;  
	
	//Resource Bundle
	private ResourceBundle rsb = null;
	
	//Received Date
	private String reqReceivedDate = null;
	
	//Status
	private String status = null;
	
	//Error Code
	private String errorCode = null;
	
	//Error Message
	private String errorMessage = null;
	
	//Output String XML
	private String outputStrXml = null;
	
	 /** 
	 * Method Description: This method is used to search documents in ECM based on the transaction id 
	 *                     provided by Client.                     
	 * 
	 * @param String     : inputStringXML contains all the required information (trans_id) to search document(s).
	 *                     
	 * @return String	 : outputStrXml which contains document_id, document_name, url_link, creation_date
	 * 					   and upload_by values in String XML format.
	 */		
	public String searchByTransId(String inputStringXml) throws Exception 
	 {		
		
	     try {
	    	 //logger
	    	 LOGGER = DfLogger.getLogger(SearchByTransIdService.class);
	    	 LOGGER.debug("LOS Search By Transaction Id Service Request Started..");
	    	 
	    	 //resource bundle
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.los.LOSConfig");
	    	 
	    	//request received date			
		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    reqReceivedDate = sdf.format(new Date());		    
			
			//read input values from string xml
			ReadSTIStringXML inputStrXmlObj = new ReadSTIStringXML();
			outputStrXml = inputStrXmlObj.processInputData(LOGGER, rsb, inputStringXml, reqReceivedDate, 
					status, errorCode, errorMessage);
			
			if(outputStrXml.equals("success")){
			
			//create document
			if(!inputStrXmlObj.getUserId().equalsIgnoreCase("") && 
				  inputStrXmlObj.getMessageType().equals(rsb.getString("SEARCH_BY_TRANS_ID_MESSAGE_TYPE")) && 
				    inputStrXmlObj.getAppId().equals(rsb.getString("SOURCE_APP_ID")) &&
				      inputStrXmlObj.getTrans_id()!=null && !inputStrXmlObj.getTrans_id().equalsIgnoreCase("") && 
				        !inputStrXmlObj.getReqtimeStamp().equalsIgnoreCase("")){		
				
					//execute query
					SearchDocsByTransId searchSrvObj = new SearchDocsByTransId();
					outputStrXml = searchSrvObj.searchByTransId(LOGGER, rsb, inputStrXmlObj, searchSrvObj, reqReceivedDate, 
							status, errorCode, errorMessage, inputStrXmlObj.getTrans_id());					
			}
			else{
				status = "1";
				errorCode = "SBTI01";
				errorMessage = "Missing Mandatory Values from Client to Search Document(s).";
				WriteSTIStringXML outputStrXmlObj = new WriteSTIStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
				LOGGER.debug("Missing Mandatory Values from Client to Search Document(s).");
				}
			}
			else{
				status = "1";
				errorCode = "SBTI02";
				errorMessage = outputStrXml;
				WriteSTIStringXML outputStrXmlObj = new WriteSTIStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
			}
			 
		} catch (Exception e) {	
			
			LOGGER.error("Error Code (SBTI01) : ", e.fillInStackTrace());
			LOGGER.error("LOS Search By Transaction Id Service Request Completed with Errors.");
		}	    
		
		return outputStrXml;		
	 }	
	

}
