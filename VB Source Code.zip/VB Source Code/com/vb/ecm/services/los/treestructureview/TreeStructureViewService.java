/**
* ______________________________________________________________________________
*
* File: TreeStructureViewService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 20, 2012   11:31:25 AM   2012 
* Description: This class is the main class (Service Class) and will perform 
* 			   following things:
* 				1. Retrieves all the required info from the input String XML 
* 				   using ReadTSVStringXML Class.
*               2. Retrieves all the folders and documents present in ECM repository
*                  based on the data (Customer Id Combination) using TreeStructureView
*                  Class.
*               3. Writes all the collected info into a String XML using 
*                  WriteTSVStringXML Class.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.treestructureview;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.fc.common.DfLogger;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 15, 2012
 * @Last Modification Time   11:31:25 AM
 * @Last Modification Year   2012 
 */

@DfsPojoService(targetNamespace = "http://treestructureview.los.services.ecm.vb.com", requiresAuthentication = true)
public class TreeStructureViewService {

	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;     
    
	//Resource Bundle
	private ResourceBundle rsb = null;
	
	//Received Date
	private String reqReceivedDate = null;
	
	//Status
	private String status = null;
	
	//Error Code
	private String errorCode = null;
	
	//Error Message
	private String errorMessage = null;
	
	//Output String XML
	private String outputStrXml = null;	
	
	 /** 
	 * Method Description: This method is used to retrieve all the folders and documents present in 
	 * 					   ECM based on the data (Customer Id Combination Value) provided by LOS.                    
	 * 
	 * @param String     : inputStringXML contains all the required information (Customer Id Combination Value) 
	 *                     to retrieve folders and documents.
	 *                     
	 * @return String	 : outputStrXml which contains all the collected information in String XML format.
	 */		
	public String getTreeStructureView(String inputStringXml) throws Exception 
	 {			
		String custIdCombVlu = null; 
		
	    try {
	    	//logger
	    	LOGGER = DfLogger.getLogger(TreeStructureViewService.class);
	    	LOGGER.debug("LOS Tree Strucute View Service Request Started..");
	    	
	    	//resource bundle
	    	rsb = ResourceBundle.getBundle("com.vb.ecm.services.los.LOSConfig");
	    	 
	    	//request received date			
		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    reqReceivedDate = sdf.format(new Date());		    
			
			//read input values from string xml
			ReadTSVStringXML inputStrXmlObj = new ReadTSVStringXML();
			outputStrXml = inputStrXmlObj.processInputData(LOGGER, rsb, inputStringXml, reqReceivedDate, 
					status, errorCode, errorMessage);
			
			if(outputStrXml.equals("success")){
			
			//retrieving all the folders and documents based on Customer Id Combination			
			if(!inputStrXmlObj.getUserId().equalsIgnoreCase("") && 
				  inputStrXmlObj.getMessageType().equals(rsb.getString("TREE_VIEW_MESSAGE_TYPE")) && 
					inputStrXmlObj.getAppId().equals(rsb.getString("SOURCE_APP_ID")) && 
					  !inputStrXmlObj.getCust_id_number().equalsIgnoreCase("") && 
					     !inputStrXmlObj.getCust_id_type().equalsIgnoreCase("") && 
					        !inputStrXmlObj.getReqtimeStamp().equalsIgnoreCase("")){				
				
				TreeStructureView tsvObj = new TreeStructureView();
				//customer id combination - customer id number + "-" + customer id type values
				custIdCombVlu = inputStrXmlObj.getCust_id_number() + "-" + inputStrXmlObj.getCust_id_type();
				outputStrXml = tsvObj.getTreeView(LOGGER, rsb, inputStrXmlObj, tsvObj, reqReceivedDate, status, 
						errorCode, errorMessage, custIdCombVlu);
				
			}
			else{
				status = "1";
				errorCode = "TSVS01";
				errorMessage = "Missing Mandatory Values from Client to Retrieve Folders and Documents.";
				WriteTSVStringXML outputStrXmlObj = new WriteTSVStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, 
						status, errorCode, errorMessage);
				LOGGER.debug("Missing Mandatory Values from client to Retrieve Folders and Documents.");
				}
			}
			else{
				status = "1";
				errorCode = "TSVS02";
				errorMessage = outputStrXml;
				WriteTSVStringXML outputStrXmlObj = new WriteTSVStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, 
						status, errorCode, errorMessage);
			}
	 		
		} catch (Exception e) {
			
			LOGGER.error("Error Code (TSVS01) : ", e.fillInStackTrace());
			LOGGER.debug("LOS Tree Structure View Service Request Completed with Errors.");
		}	          
	     
		 return outputStrXml;
	 }	
	

}
