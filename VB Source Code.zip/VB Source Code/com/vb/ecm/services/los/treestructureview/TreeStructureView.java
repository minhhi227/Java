/**
* ______________________________________________________________________________
*
* File: TreeStructureView.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 20, 2012   11:31:25 AM   2012
* Description: This class will retrieve all the folders and documents present in
* 			   ECM repository based on the data (Customer Id Combination) provided by LOS.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.treestructureview;

import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 15, 2012
 * @Last Modification Time   11:31:25 AM
 * @Last Modification Year   2012 
 */

public class TreeStructureView {
    
    private IDfSession session = null;
	private IDfSessionManager sMgr; 
	
	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;
	
	//Output String XML
	private String outputStrXml = null;
	
	//Document
	private Document document;
	
	//Root Element
	private Element rootElement;
	
	 /**
	 * @return the rootElement
	 */
	public Element getRootElement() {
		return rootElement;
	}

	/**
	 * @param rootElement the rootElement to set
	 */
	public void setRootElement(Element rootElement) {
		this.rootElement = rootElement;
	}

	/** 
	 * Method Description: This method is used to retrieve all the folders and documents present in 
	 * 					   ECM based on the data (Customer Id Combination) provided by LOS.
	 *                     
	 * @return void  	 : returns no value.
	 */		
	public String getTreeView(Logger logger, ResourceBundle rsb, ReadTSVStringXML inputStrXmlObj, TreeStructureView tsvObj, 
			String reqReceivedDate, String status, String errorCode, String errorMessage, String custIdCombVlu) 
					throws Exception 
	 {					
		boolean noResultsFound = false;			
		 
	     try {
	    	 //logger
	    	 LOGGER = logger;
	    	 
	    	 //Create Session	    	 
	    	 session = createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));    	    	
	    	 
	    	 if(session!=null){
	    		 
              //calling executeQuery method
	    	  noResultsFound = executeQuery(rsb, inputStrXmlObj, tsvObj, reqReceivedDate, status, errorCode, 
	    			  errorMessage, custIdCombVlu);                                
		          
	           if(noResultsFound==true){        	  
	        	  
	        	   status = "1";
	        	   errorCode = "TSVS09";
	        	   errorMessage = "Customer : " + custIdCombVlu + " Doesn't Exist in ECM.";
				   WriteTSVStringXML outputStrXmlObj = new WriteTSVStringXML();
				   outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, tsvObj, reqReceivedDate, status, 
							errorCode, errorMessage);	        	  
	           }
	           else{ 
	        	   LOGGER.debug(custIdCombVlu + " : Folder Structure Retrieved from ECM.");
	           }
		    	
	    	 }else{
	    		    status = "1";
	    		    errorCode = "TSVS05";
	    		    errorMessage = "Session Not Created.";
					WriteTSVStringXML outputStrXmlObj = new WriteTSVStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, tsvObj, reqReceivedDate, status, 
							errorCode, errorMessage);					
	    	 }
	 		
		} catch (Exception e) {		
						
		    LOGGER.error("Error Code (TSVS04) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {	    		 
				if(session!=null){
					 releaseSession();
				 }
				
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
	     
	     return outputStrXml;
		 
	 }	 
	
	 /** 
	 * Method Description: This method is used to execute the query (tree structure view query).                    
	 * 
	 * @param String     : Customer Id Combination Value.	
	 *                     
	 * @return boolean	 : returns true or false value.
	 */	
	private boolean executeQuery(ResourceBundle rsb, ReadTSVStringXML inputStrXmlObj, TreeStructureView tsvObj, 
			String reqReceivedDate, String status, String errorCode, String errorMessage, String custIdCombVlu) 
					throws Exception {		
		
		IDfClientX clientx = null;
		IDfQuery query = null;
		IDfCollection coll = null;
		boolean noResultsFound = true;
		String cust_type_folder_id = null, cabinetFolderId = null;
		IDfSysObject custTypeObj = null, cabinetObj = null;
		
		try {
			//creating message_response element
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			document = docBuilder.newDocument();
			rootElement = document.createElement("message_response");
			document.appendChild(rootElement);
			
			clientx = new DfClientX();
			query =clientx.getQuery();				
			
			query.setDQL("SELECT r_object_id, object_name, r_object_type, i_folder_id from dm_sysobject " +
					"where object_name='"+ custIdCombVlu +"'");
			LOGGER.debug("Query : " + "SELECT r_object_id, object_name, r_object_type, i_folder_id from dm_sysobject " +
					"where object_name='"+ custIdCombVlu +"'");
			
			coll = query.execute(session, IDfQuery.DF_READ_QUERY);
			
			while(coll.next()){
				
				noResultsFound = false;				
				
				//adding branch and customer type elements to message_response element
				cust_type_folder_id = coll.getString("i_folder_id");		
				custTypeObj = (IDfSysObject)session.getObject(new DfId(cust_type_folder_id));								
				
				cabinetFolderId = custTypeObj.getString("i_folder_id");				
				cabinetObj = (IDfSysObject)session.getObject(new DfId(cabinetFolderId));				
				
				Element cabinetElement = document.createElement("Folder_Name");
				cabinetElement.appendChild(document.createTextNode(cabinetObj.getObjectName()));
				rootElement.appendChild(cabinetElement);
				
				Element custTypeElement = document.createElement("Folder_Name");
				custTypeElement.appendChild(document.createTextNode(custTypeObj.getObjectName()));
				cabinetElement.appendChild(custTypeElement);
				
				createChildElement(rsb, coll.getString("r_object_id"), coll.getString("object_name"), 
						coll.getString("r_object_type"), custTypeElement);
			}
			
			//setter method
			setRootElement(rootElement);
			
			coll.close();
			
			if(noResultsFound == false){
				status = "0";
				errorCode = "";
				errorMessage = "";
				LOGGER.debug("Query Executed & Record(s) Retrieved Successfully.");
				//write results to outputStrXml
				WriteTSVStringXML outputStrXmlObj = new WriteTSVStringXML();
				outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, tsvObj, reqReceivedDate, status, 
						errorCode, errorMessage);
			}
			
		} catch (Exception e) {	
			noResultsFound = false;
			status = "1";
			errorCode = "TSVS07";
			errorMessage = e.getMessage();
		    WriteTSVStringXML outputStrXmlObj = new WriteTSVStringXML();
		    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, tsvObj, reqReceivedDate, status, 
					errorCode, errorMessage);
			LOGGER.error("Error Code (TSVS07) : ", e.fillInStackTrace());
		}		
		
		return noResultsFound;
	}
	
	/** 
	 * 
	 * Method Description: This method is used for recursive generation of XML nodes based upon 
	 * 					   Documentum Object Id, Object Name and Type of Object with ParentElement.
	 * 	 
	 * @param String     : objectId
	 * @param String     : Object Name
	 * @param String     : objectType
	 * 
	 * @return Void  	 : returns no value.
	 */ 	 
	private void createChildElement(ResourceBundle rsb, String objectId, String objectName, String objectType,
			Element rootElement) throws Exception {
		
		String elementName = "";		
		
		try {
			if(objectId.startsWith("09")){
				
				if(objectType.equals(rsb.getString("DOC_TYPE"))){
					elementName="Document_Name";
				}
			}
			else if(objectId.startsWith("0b")){
				
				elementName="Folder_Name";
			}
			else if(objectId.startsWith("0c")){
				
				elementName="Cabinet_Name";
			}
			
			if(elementName!=""){
				
				Element currentElement = document.createElement(elementName);
				currentElement.appendChild(document.createTextNode(objectName));
				rootElement.appendChild(currentElement);
				
				if(objectId.startsWith("0b") || objectId.startsWith("0c")){
					
					IDfFolder folderObject = (IDfFolder)session.getObject(new DfId(objectId));
					IDfCollection folderContentCollection = folderObject.getContents("r_object_id,object_name,r_object_type");
					
					while(folderContentCollection.next()){
						
						String currObjId = folderContentCollection.getString("r_object_id");
						String currObjName = folderContentCollection.getString("object_name");
						String currObjType = folderContentCollection.getString("r_object_type");
						
						createChildElement(rsb, currObjId, currObjName, currObjType, currentElement);
					}
					
					folderContentCollection.close();
					
				}
			}
			
		} catch (Exception e) {			
			
			LOGGER.error("Error Code (TSVS08) : ", e.fillInStackTrace());
		}
		
	}

	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
				
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);			
			session = sMgr.getSession(docbase);			
			
			if (session != null) {
				LOGGER.debug("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (TSVS05) : ", e.fillInStackTrace());
		}		
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {		
		
		try {
			sMgr.release(session);
			LOGGER.debug("Session Released.");
			LOGGER.debug("LOS Tree Structure View Service Request Completed Successfully.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (TSVS10) : ", e.fillInStackTrace());
		}
		
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {		
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (TSVS06) : ", e.fillInStackTrace());
		}
		
		return idfsessionmanager;
	}	


}
