/**
* ______________________________________________________________________________
*
* File: CreateService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 14, 2012   9:16:27 AM   2012
* Description: This class is the main class (Service Class) and will perform 
* 			   following things:
* 				1. Retrieves all the required info from the input String XML 
* 				   using ReadCSStringXML Class.
*               2. Creates Content-less document using CreateDocs Class.
*               3. Writes all the collected info into a String XML using 
*                  WriteCSStringXML Class.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.create;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.fc.common.DfLogger;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   July 3, 2013
 * @Last Modification Time   9:16:27 AM
 * @Last Modification Year   2013 
 */

@DfsPojoService(targetNamespace = "http://create.los.services.ecm.vb.com", requiresAuthentication = true)
public class CreateService {	
	
	// Initialising the logger from org.apache.Log4j  	
	private Logger LOGGER; 
	
	//Resource Bundle
	private ResourceBundle rsb = null;
	
	//Received Date
	private String reqReceivedDate = null;
    
	//Status
	private String status = null;

	//Error Code
	private String errorCode = null;

	//Error Message
	private String errorMessage = null;
    
	//Output String in XML Format
	private String outputStrXml = null;	

	/** 
	 * Method Description: This method is used to create content less document in ECM 
	 *                     and set all the properties provided by LOS Create Functionality.                     
	 * 
	 * @param String     : inputStringXML contains all the required information to create document.
	 *                     
	 * @return String	 : outputStrXml which contains Transaction ID (newly created document id) in String XML format.
	 */		
	public String createContentlessDocument(String inputStringXml) throws Exception 
	 {		
		
	     try {
	    	 //logger
	    	 LOGGER = DfLogger.getLogger(CreateService.class);	
	    	 LOGGER.debug("LOS Create Service Request Started..");
	    	 
	    	 //resource bundle
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.los.LOSConfig");
	    	 
	    	//request received date			
		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    reqReceivedDate = sdf.format(new Date());		    
			
			//read input values from string xml
			ReadCSStringXML inputStrXmlObj = new ReadCSStringXML();
			outputStrXml = inputStrXmlObj.processInputData(LOGGER, inputStringXml);			
			
			if(outputStrXml.equals("success")){			
			
			//create document
			if(!inputStrXmlObj.getUserId().equalsIgnoreCase("") &&
				  inputStrXmlObj.getMessageType().equals(rsb.getString("CREATE_MESSAGE_TYPE")) &&					
				    (inputStrXmlObj.getAppId().equals(rsb.getString("SOURCE_APP_ID")) &&
					   !inputStrXmlObj.getReqtimeStamp().equalsIgnoreCase(""))){				
				
				CreateDocs createDocsObj = new CreateDocs();				
				String trans_id = createDocsObj.createContentlessDocument(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
						status, errorCode, errorMessage);				
				
				if(trans_id.contains("Session Not Created.")){
					
					status = "1";
					errorCode = "CS05";
					errorMessage = "Session Not Created.";
					WriteCSStringXML outputStrXmlObj = new WriteCSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, "", inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
					
				}
				else if(trans_id.equalsIgnoreCase("Create Service Operation Failed bcoz of Missing " +
						"Mandatory values from Client.")){
					
					status = "1";
					errorCode = "CS01";
					errorMessage = "Missing Mandatory Values from Client to Create Document.";
					WriteCSStringXML outputStrXmlObj = new WriteCSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, "", inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}
				else if(trans_id.contains("Error : Cabinet")){
					
					status = "1";
					errorCode = "CS04";
					errorMessage = "Cabinet (Branch " + inputStrXmlObj.getBranch_number() + ") Doesn't Exist. " +
			 		"Please contact Administrator.";
					WriteCSStringXML outputStrXmlObj = new WriteCSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, "", inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}
				else if(!trans_id.contains("Error :")){
					
					status = "0";
					errorCode = "";
					errorMessage = "";					
					//write output values to string xml					
				    WriteCSStringXML outputStrXmlObj = new WriteCSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, trans_id, inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}	
				else{					
					status = "1";
					errorCode = "CS20";
					errorMessage = trans_id;
					WriteCSStringXML outputStrXmlObj = new WriteCSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, "", inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);					
				}
			}
			else{
				status = "1";
				errorCode = "CS01";
				errorMessage = "Missing Mandatory Values from Client to Create Document.";
				WriteCSStringXML outputStrXmlObj = new WriteCSStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
				LOGGER.debug("Missing Mandatory Values from client to Create Document.");
				}
			}
			else{				
				status = "1";
				errorCode = "CS02";
				errorMessage = outputStrXml;
				WriteCSStringXML outputStrXmlObj = new WriteCSStringXML();			
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
			}
			 
		} catch (Exception e) {			
			LOGGER.error("Error Code (CS01) : ", e.fillInStackTrace());
			LOGGER.error("LOS Create Service Request Completed with Errors.");
		}	    
		
		return outputStrXml;		
	 }	
	

}
