/**
* ______________________________________________________________________________
*
* File: CreateDocs.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 14, 2012   9:16:27 AM   2012
* Description: This class will create content less document in ECM repository
 *             and set all the properties provided by LOS Create functionality
 *             as meta-data to that document.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.create;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 13, 2013
 * @Last Modification Time   9:16:27 AM
 * @Last Modification Year   2012 
 */

public class CreateDocs {	     
    
	//session
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;	
	
	private ReadCSStringXML inputStrXmlObj;
	private String outputStrXml = null;
	
	// Initialising the logger from org.apache.Log4j  	
	private Logger LOGGER;
	
	//Resource Bundle
	private ResourceBundle rsb = null;
	
	 /** 
	 * Method Description: This method is used to create content less document in ECM 
	 *                     and set all the properties provided by LOS Create Functionality.
	 *                     
	 * @return String	 : Transaction ID (newly created document id).
	 */		
	public String createContentlessDocument(Logger logger, ResourceBundle resourcebundle, ReadCSStringXML inStrXmlObj, 
			String reqReceivedDate, String status, String errorCode, String errorMessage) throws Exception 
	 {			
		String dctmLocPath = null;		
		 
	     try {
	    	 //logger
	    	 LOGGER = logger;
	    	 
	    	 //resource bundle
	    	 rsb = resourcebundle;
	    	 
			 //Create Session	    	 
	    	 session = createSession(rsb.getString("REPO_NAME"), 
	    			 rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));	    	 
	    	 
	    	 //object reference
	    	 inputStrXmlObj = inStrXmlObj;	    	 
	    	 
	    	 if(session!=null){
			 
			 if(inputStrXmlObj.getDoc_sub_type().equals(rsb.getString("APPLICATION_NOTES_FOLDER_NAME")) || 
				inputStrXmlObj.getDoc_sub_type().equals(rsb.getString("AA_FOLDER_NAME")) || 
				inputStrXmlObj.getDoc_sub_type().equals(rsb.getString("LETTER_OF_OFFER_FOLDER_NAME"))){			
		    	 
				 //checking mandatory values
		    	 if(!inputStrXmlObj.getBranch_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_type().equalsIgnoreCase("") &&
		    		!inputStrXmlObj.getCust_id_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_id_type().equalsIgnoreCase("") &&
				    !inputStrXmlObj.getCar_year_created().equalsIgnoreCase("") && !inputStrXmlObj.getUpload_by().equalsIgnoreCase("")){    		 
			    		 
		    		 //ECM Destination Path
		             dctmLocPath = getApplNotesFolderPath(reqReceivedDate, status, errorCode, errorMessage); 		    	 
		
		             if(!dctmLocPath.contains("Error :")){
		            		
		            	 outputStrXml = createDocument(dctmLocPath, reqReceivedDate, status, 
		            			 errorCode, errorMessage);
		             }
		             else{
		            	 outputStrXml = dctmLocPath;
		             }
			    	 
			    	 }else{	    		
			    		 outputStrXml = "Create Service Operation Failed bcoz of Missing Mandatory values from Client.";
			    		 LOGGER.debug("Create Service Operation Failed bcoz of Missing Mandatory " +
			    		 		"values from Client.");
			    	 }	
				 }
			 else if(inputStrXmlObj.getDoc_sub_type().equals(rsb.getString("FACILITY_FOLDER_NAME"))){			
		    	 
				 //checking mandatory values
		    	 if(!inputStrXmlObj.getBranch_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_type().equalsIgnoreCase("") &&
					!inputStrXmlObj.getCust_id_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_id_type().equalsIgnoreCase("") &&
				    !inputStrXmlObj.getCar_year_created().equalsIgnoreCase("") && !inputStrXmlObj.getFacility_number().equalsIgnoreCase("") &&
				    !inputStrXmlObj.getUpload_by().equalsIgnoreCase("")){    		 
			    		 
		    		 //ECM Destination Path
		             dctmLocPath = getFacilityFolderPath(reqReceivedDate, status, errorCode, errorMessage); 		    	 
		
		             if(!dctmLocPath.contains("Error :")){
		            		
		            	 outputStrXml = createDocument(dctmLocPath, reqReceivedDate, status, 
		            			 errorCode, errorMessage);
		             }
		             else{
		            	 outputStrXml = dctmLocPath;
		             }
			    	 
			    	 }else{	    		
			    		 outputStrXml = "Create Service Operation Failed bcoz of Missing Mandatory values from Client.";
			    		 LOGGER.debug("Create Service Operation Failed bcoz of Missing Mandatory " +
			    		 		"values from Client.");
			    	 }	
				 }
			 else if(inputStrXmlObj.getDoc_sub_type().equals(rsb.getString("COLLATERAL_FOLDER_NAME"))){			
		    	 
			 //checking mandatory values
	    	 if(!inputStrXmlObj.getBranch_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_type().equalsIgnoreCase("") &&
			    !inputStrXmlObj.getCust_id_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_id_type().equalsIgnoreCase("") &&
			    !inputStrXmlObj.getCar_year_created().equalsIgnoreCase("") && !inputStrXmlObj.getCollateral_number().equalsIgnoreCase("") &&						  	                  
			    !inputStrXmlObj.getUpload_by().equalsIgnoreCase("")){
		    			    		     		 
	    		     //Document Creation
	    		     dctmLocPath = getCollateralFolderPath(reqReceivedDate, status, errorCode, errorMessage);	    		     
		    		 
		    		 if(!dctmLocPath.contains("Error :")){		            	 	
		    			 outputStrXml = createDocument(dctmLocPath, reqReceivedDate, status, 
		            			 errorCode, errorMessage);		            	 
		             }
		             else{
		            	 outputStrXml = dctmLocPath;
		             }
		    	 
		    	 }else{	    		
		    		 outputStrXml = "Create Service Operation Failed bcoz of Missing Mandatory values from Client.";
		    		 LOGGER.debug("Create Service Operation Failed bcoz of Missing Mandatory " +
		    		 		"values from Client.");
		    	 }	
			 }
			 else if(inputStrXmlObj.getDoc_sub_type().equals(rsb.getString("CUSTOMER_NOTES_FOLDER_NAME")) || 
					 inputStrXmlObj.getDoc_sub_type().equals(rsb.getString("CALL_REPORT_FOLDER_NAME"))){
				 
				 //checking mandatory values
		    	 if(!inputStrXmlObj.getBranch_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_type().equalsIgnoreCase("") &&
					!inputStrXmlObj.getCust_id_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_id_type().equalsIgnoreCase("") &&
					!inputStrXmlObj.getUpload_by().equalsIgnoreCase("")){    		 
			    		 
		    		 //ECM Destination Path
		             dctmLocPath = getCustNotesFolderPath(reqReceivedDate, status, errorCode, errorMessage); 
		             
		             if(!dctmLocPath.contains("Error :")){
		
		            	 outputStrXml = createDocument(dctmLocPath, reqReceivedDate, status, 
		            			 errorCode, errorMessage);
		             }
		             else{
		            	 outputStrXml = dctmLocPath;
		             }	             
			    	 
			    	 }else{			    		 
			    		 outputStrXml = "Create Service Operation Failed bcoz of Missing Mandatory values from Client.";
			    		 LOGGER.debug("Create Service Operation Failed bcoz of Missing Mandatory " +
			    		 		"values from Client.");
			    	 }			    	 
				 }
			 else{
				 //checking mandatory values
		    	 if(!inputStrXmlObj.getBranch_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_type().equalsIgnoreCase("") &&
					!inputStrXmlObj.getCust_id_number().equalsIgnoreCase("") && !inputStrXmlObj.getCust_id_type().equalsIgnoreCase("") &&
					!inputStrXmlObj.getDoc_sub_type().equalsIgnoreCase("") && !inputStrXmlObj.getUpload_by().equalsIgnoreCase("")){    		 
			    		 
		    		 //ECM Destination Path
		             dctmLocPath = getDestFolderPath(reqReceivedDate, status, errorCode, errorMessage); 
		             
		             if(!dctmLocPath.contains("Error :")){
		
		            	 outputStrXml = createDocument(dctmLocPath, reqReceivedDate, status, 
		            			 errorCode, errorMessage);
		             }
		             else{
		            	 outputStrXml = dctmLocPath;
		             }	             
			    	 
			    	 }else{	    		
			    		 outputStrXml = "Create Service Operation Failed bcoz of Missing Mandatory values from Client.";
			    		 LOGGER.debug("Create Service Operation Failed bcoz of Missing Mandatory " +
			    		 		"values from Client.");
			    	 }
			 	}
	    	 }else{	    		 	
					outputStrXml = "Session Not Created.";					
				 }
			 
		} catch (Exception e) {	
			outputStrXml = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (CS07) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					releaseSession();
				 }
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }
		
		return outputStrXml;		
	 }
	
	/** 
	 * Method Description: This method contains actual logic to create content less document in ECM 
	 *                     and set all the properties provided by LOS Create Functionality.
	 *                     
	 * @return String	 : Transaction ID (newly created document id).
	 */	
	private String createDocument(String dctmLocPath, String reqReceivedDate, String status, 
			String errorCode, String errorMessage){		
		
		IDfSysObject sysObj = null;	
		String docId = null;		
		 
	     try {	 		 
	    	 //creating document	
	 		 sysObj = (IDfSysObject)session.newObject(rsb.getString("DOC_TYPE"));	 		 
	 		 LOGGER.debug("Creating content less document..");	 		 
	 		 
             sysObj.setObjectName("ECM Document - " + System.currentTimeMillis());             
             sysObj.setTitle("LOS Create Service-Document Created by : " + inputStrXmlObj.getUpload_by());
             sysObj.setString("doc_upload_status", "Uploading");
             sysObj.setString("upload_by", inputStrXmlObj.getUpload_by());
             sysObj.setString("owner_name", inputStrXmlObj.getUpload_by());
            
             //setting document properties
             sysObj.setString("branch_number", inputStrXmlObj.getBranch_number());
             sysObj.setString("cust_type", inputStrXmlObj.getCust_type());
             sysObj.setString("cust_id_number", inputStrXmlObj.getCust_id_number());
             sysObj.setString("cust_id_type", inputStrXmlObj.getCust_id_type());
             sysObj.setString("doc_sub_type", inputStrXmlObj.getDoc_sub_type());
             sysObj.setString("car_year_created", inputStrXmlObj.getCar_year_created());
             sysObj.setString("facility_number", inputStrXmlObj.getFacility_number());
             sysObj.setString("collateral_number", inputStrXmlObj.getCollateral_number());
             sysObj.setString("cust_name", inputStrXmlObj.getCust_name());
             sysObj.setString("cust_cif_number", inputStrXmlObj.getCust_cif_number());        
	         
	          if(dctmLocPath!=null){
	        	  
	             sysObj.link(dctmLocPath);
	             sysObj.save();	             
	             
				 docId = sysObj.getObjectId().getId();
				 LOGGER.debug("Document Created Successfully with Transaction Id : " + docId);
				 
	          }else{
	        	  docId = "Error : Destination Path : " + dctmLocPath + " Create Service Operation Failed!!!";
	        	  LOGGER.debug("Destination Path : " + dctmLocPath + " Create Service Operation Failed!!!");
	          }		    	 
			 
		} catch (Exception e) {	
			docId = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (CS16) : ", e.fillInStackTrace());
		}	     
		
		return docId;
		
	}	
	
	/**
	 * Description : This method is used to create custom folders if they don't exist and 
	 *               generate the final destination folder path to create content less document in ECM.
	 * 
	 * @return String : Final Destination Folder Path
	 */	
	private String getApplNotesFolderPath(String reqReceivedDate, String status, 
			String errorCode, String errorMessage) throws Exception {
		
		String destFolderPath = null;
		
		try {			
			//Cabinet - Branch 001
			IDfFolder isBranchExists = session.getFolderByPath("/" + rsb.getString("CABINET_NAME") + 
					inputStrXmlObj.getBranch_number());			
			 if(isBranchExists!=null){					 
				 destFolderPath = "/" + rsb.getString("CABINET_NAME") + inputStrXmlObj.getBranch_number();		 				
			 
			 //Folder - Customer Type like Enterprise, Retail etc..			 
			 destFolderPath = isFolderExists(inputStrXmlObj.getCust_type(), destFolderPath);				
			 
			 //Folder - Create Customer Folder and set customer info				 
			 IDfFolder isCustFldrExists = session.getFolderByPath(destFolderPath + "/" + 
					 inputStrXmlObj.getCust_id_number() + "-" + inputStrXmlObj.getCust_id_type());
			      if(isCustFldrExists!=null){
			    	  
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();			    	   
			    	   
			      }else{				    	  
			    	   createCustFolder(destFolderPath);
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();
			      }
			      
			   //Folder - Loan Docs			  
			   destFolderPath = isFolderExists(rsb.getString("LOAN_DOCS_FOLDER_NAME"), destFolderPath);	
			   
			   //Folder - Car Year Created	  
			   destFolderPath = isFolderExists(inputStrXmlObj.getCar_year_created(), destFolderPath);			   			   
			   
			   //Folder	- Application Notes, AA or Letter of Offer		  
			   destFolderPath = isFolderExists(inputStrXmlObj.getDoc_sub_type(), destFolderPath);
			   
			   //final destination folder path
			   LOGGER.debug("Final Destination Folder Path in  ECM : " + destFolderPath);	
			 }
			 else{					
				 destFolderPath = "Error : Cabinet (Branch " + inputStrXmlObj.getBranch_number() + ") Doesn't Exist. " +
				 		"Please contact Administrator.";
			 }
			
		} catch (Exception e) {
			destFolderPath = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (CS08) : ", e.fillInStackTrace());
		}		
		
		return destFolderPath;
	}
	
	/**
	 * Description : This method is used to create custom folders if they don't exist and 
	 *               generate the final destination folder path to create content less document in ECM.
	 * 
	 * @return String : Final Destination Folder Path
	 */	
	private String getFacilityFolderPath(String reqReceivedDate, String status, 
			String errorCode, String errorMessage) throws Exception {
		
		String destFolderPath = null;
		
		try {			
			//Cabinet - Branch 001
			IDfFolder isBranchExists = session.getFolderByPath("/" + rsb.getString("CABINET_NAME") + 
					inputStrXmlObj.getBranch_number());			
			 if(isBranchExists!=null){					 
				 destFolderPath = "/" + rsb.getString("CABINET_NAME") + inputStrXmlObj.getBranch_number();		 				
			 
			 //Folder - Customer Type like Enterprise, Retail etc..			 
			 destFolderPath = isFolderExists(inputStrXmlObj.getCust_type(), destFolderPath);				
			 
			 //Folder - Create Customer Folder and set customer info				 
			 IDfFolder isCustFldrExists = session.getFolderByPath(destFolderPath + "/" + 
					 inputStrXmlObj.getCust_id_number() + "-" + inputStrXmlObj.getCust_id_type());
			      if(isCustFldrExists!=null){
			    	  
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();			    	   
			    	   
			      }else{				    	  
			    	   createCustFolder(destFolderPath);
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();
			      }
			      
			   //Folder - Loan Docs			  
			   destFolderPath = isFolderExists(rsb.getString("LOAN_DOCS_FOLDER_NAME"), destFolderPath);	
			   
			   //Folder - Car Year Created	  
			   destFolderPath = isFolderExists(inputStrXmlObj.getCar_year_created(), destFolderPath);			   			   			   
			   
			   //Folder	- Facility		  
			   destFolderPath = isFolderExists(inputStrXmlObj.getDoc_sub_type(), destFolderPath);
			   
			   //Folder - Facility Number	  
			   destFolderPath = isFolderExists(inputStrXmlObj.getFacility_number(), destFolderPath);			  
			   
			   //final destination folder path
			   LOGGER.debug("Final Destination Folder Path in  ECM : " + destFolderPath);
			 }
			 else{					
				 destFolderPath = "Error : Cabinet (Branch " + inputStrXmlObj.getBranch_number() + ") Doesn't Exist. " +
				 		"Please contact Administrator.";
			 }
			
		} catch (Exception e) {
			destFolderPath = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (CS09) : ", e.fillInStackTrace());
		}		
		
		return destFolderPath;
	}
	
	/**
	 * Description : This method is used to create custom folders if they don't exist and 
	 *               generate the final destination folder path to create content less document in ECM.
	 * 
	 * @return String : Final Destination Folder Path
	 */	
	private String getCollateralFolderPath(String reqReceivedDate, String status, 
			String errorCode, String errorMessage) throws Exception {
		
		String destFolderPath = null;		
		
		try {			
			//Cabinet - Branch 001
			IDfFolder isBranchExists = session.getFolderByPath("/" + rsb.getString("CABINET_NAME") + 
					inputStrXmlObj.getBranch_number());			
			 if(isBranchExists!=null){					 
				 destFolderPath = "/" + rsb.getString("CABINET_NAME") + inputStrXmlObj.getBranch_number();	 				
			 
			 //Folder - Customer Type like Enterprise, Retail etc..			 
			 destFolderPath = isFolderExists(inputStrXmlObj.getCust_type(), destFolderPath);				
			 
			 //Folder - Create Customer Folder and set customer info				 
			 IDfFolder isCustFldrExists = session.getFolderByPath(destFolderPath + "/" + 
					 inputStrXmlObj.getCust_id_number() + "-" + inputStrXmlObj.getCust_id_type());
			      if(isCustFldrExists!=null){
			    	  
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();			    	   
			    	   
			      }else{				    	  
			    	   createCustFolder(destFolderPath);
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();
			      }
			      
			   //Folder - Loan Docs			  
			   destFolderPath = isFolderExists(rsb.getString("LOAN_DOCS_FOLDER_NAME"), destFolderPath);	
			   
			   //Folder - Car Year Created	  
			   destFolderPath = isFolderExists(inputStrXmlObj.getCar_year_created(), destFolderPath);
			   
			   //Folder	- Collateral	  
			   destFolderPath = isFolderExists(rsb.getString("COLLATERAL_FOLDER_NAME"), destFolderPath);			   
			   
			   //Folder	- Collateral Id Number folder	  
			   destFolderPath = isFolderExists(inputStrXmlObj.getCollateral_number(), destFolderPath);
			   
			   //final destination folder path
			   LOGGER.debug("Final Destination Folder Path in  ECM : " + destFolderPath);
			 }
			 else{					
				 destFolderPath = "Error : Cabinet (Branch " + inputStrXmlObj.getBranch_number() + ") Doesn't Exist. " +
				 		"Please contact Administrator.";
			 }			   			
			
		} catch (Exception e) {
			destFolderPath = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (CS10) : ", e.fillInStackTrace());
		}		
		
		return destFolderPath;
	}	
	
	/**
	 * Description : This method is used to create custom folders if they don't exist and 
	 *               generate the final destination folder path to create content less document in ECM.
	 * 
	 * @return String : Final Destination Folder Path
	 */	
	private String getCustNotesFolderPath(String reqReceivedDate, String status, 
			String errorCode, String errorMessage) throws Exception {
		
		String destFolderPath = null;
		String folder_name = null;
		
		try {			
			//Cabinet - Branch 001
			IDfFolder isBranchExists = session.getFolderByPath("/" + rsb.getString("CABINET_NAME") + 
					inputStrXmlObj.getBranch_number());			
				 if(isBranchExists!=null){					 
					 destFolderPath = "/" + rsb.getString("CABINET_NAME") + inputStrXmlObj.getBranch_number(); 				
			 
			 //Folder - Customer Type like Enterprise, Retail etc..			 
			 destFolderPath = isFolderExists(inputStrXmlObj.getCust_type(), destFolderPath);				
			 
			 //Folder - Create Customer ID Combination folder				 
			 IDfFolder isCustFldrExists = session.getFolderByPath(destFolderPath + "/" + 
					 inputStrXmlObj.getCust_id_number() + "-" + inputStrXmlObj.getCust_id_type());
			      if(isCustFldrExists!=null){
			    	  
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();		    	   
			    	   
			      }else{				    	  
			    	   createCustFolder(destFolderPath);
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();
			      }
			      
			   //Folder - Legal Docs or Customer Other Docs folder
			   if(inputStrXmlObj.getDoc_sub_type().equalsIgnoreCase(rsb.getString("CUSTOMER_NOTES_FOLDER_NAME"))){
				   folder_name = rsb.getString("LEGAL_DOCS_FOLDER_NAME");
				   
			   }else{
				   folder_name = rsb.getString("CUSTOMER_OTHER_DOCS_FOLDER_NAME");
			   }
			   destFolderPath = isFolderExists(folder_name, destFolderPath);	
			   
			   //Folder	- Customer Notes or Call Report folder	  
			   destFolderPath = isFolderExists(inputStrXmlObj.getDoc_sub_type(), destFolderPath);			   
			   
			   //final destination folder path
			   LOGGER.debug("Final Destination Folder Path in  ECM : " + destFolderPath);			
		 }
		 else{					
			 destFolderPath = "Error : Cabinet (Branch " + inputStrXmlObj.getBranch_number() + ") Doesn't Exist. " +
			 		"Please contact Administrator.";
		 }	
			
		} catch (Exception e) {
			destFolderPath = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (CS11) : ", e.fillInStackTrace());
		}		
		
		return destFolderPath;
	}
	
	/**
	 * Description : This method is used to create custom folders if they don't exist and 
	 *               generate the final destination folder path to create content less document in ECM.
	 * 
	 * @return String : Final Destination Folder Path
	 */	
	private String getDestFolderPath(String reqReceivedDate, String status, 
			String errorCode, String errorMessage) throws Exception {
		
		String destFolderPath = null;		
		
		try {			
			//Cabinet - Branch 001
			IDfFolder isBranchExists = session.getFolderByPath("/" + rsb.getString("CABINET_NAME") + 
					inputStrXmlObj.getBranch_number());			
				 if(isBranchExists!=null){					 
					 destFolderPath = "/" + rsb.getString("CABINET_NAME") + inputStrXmlObj.getBranch_number(); 				
			 
			 //Folder - Customer Type like Enterprise, Retail etc..			 
			 destFolderPath = isFolderExists(inputStrXmlObj.getCust_type(), destFolderPath);				
			 
			 //Folder - Create Customer ID Combination folder				 
			 IDfFolder isCustFldrExists = session.getFolderByPath(destFolderPath + "/" + 
					 inputStrXmlObj.getCust_id_number() + "-" + inputStrXmlObj.getCust_id_type());
			      if(isCustFldrExists!=null){
			    	  
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();		    	   
			    	   
			      }else{				    	  
			    	   createCustFolder(destFolderPath);
			    	   destFolderPath = destFolderPath + "/" + inputStrXmlObj.getCust_id_number() + "-" + 
			    			   inputStrXmlObj.getCust_id_type();
			      }			   	
			   
			   //Folder	- Customer Notes or Call Report folder	  
			   destFolderPath = isFolderExists(inputStrXmlObj.getDoc_sub_type(), destFolderPath);			   
			   
			   //final destination folder path
			   LOGGER.debug("Final Destination Folder Path in  ECM : " + destFolderPath);			
		 }
		 else{					
			 destFolderPath = "Error : Cabinet (Branch " + inputStrXmlObj.getBranch_number() + ") Doesn't Exist. " +
			 		"Please contact Administrator.";
		 }	
			
		} catch (Exception e) {
			destFolderPath = "Error : " + e.getMessage();			
			LOGGER.error("Error Code (CS12) : ", e.fillInStackTrace());
		}		
		
		return destFolderPath;
	}
	
	/**
	 * Description : This method is used to create custom folder (vb_folder) in ECM.
	 * 
	 * @return boolean : true
	 */	
	private boolean createFolder(String folderName, String folderPath) throws Exception {		
		IDfSysObject sysObj = null;
		boolean flag = false;
		
		try {
			sysObj = (IDfSysObject)session.newObject(rsb.getString("FOLDER_TYPE"));			
			sysObj.setObjectName(folderName); 
			sysObj.setTitle("Folder Created by LOS Create Service");
			sysObj.link(folderPath);
			sysObj.save(); 
			flag = true;			
			
		} catch (DfException e) {			
			LOGGER.error("Error Code (CS13) : ", e.fillInStackTrace());
		}
		
		return flag;		
	}
	
	/**
	 * Description : This method is used to create customer folder and sets customer info to it in ECM.
	 * 
	 * @return boolean : true
	 */	
	private boolean createCustFolder(String folderPath) 
			throws Exception {		
		IDfSysObject sysObj = null;
		boolean flag = false;	
		
		try {					
			sysObj = (IDfSysObject)session.newObject(rsb.getString("CUST_FOLDER_TYPE"));			
			sysObj.setObjectName(inputStrXmlObj.getCust_id_number() + "-" + inputStrXmlObj.getCust_id_type()); 
			sysObj.setTitle("Folder Created by LOS Create Service");
			
			//setting customer info to folder		
			sysObj.setString("cust_name", inputStrXmlObj.getCust_name());
			sysObj.setString("cust_id", inputStrXmlObj.getCust_id_number());
			sysObj.link(folderPath);
			sysObj.save(); 
			flag = true;			
			
		} catch (DfException e) {			
			LOGGER.error("Error Code (CS14) : ", e.fillInStackTrace());
		}
		return flag;
		
	}	
	
	/**
	 * Description : This method is used to check the folder existence in ECM.
	 * 
	 * @return String : Folder Path
	 */	
	private String isFolderExists(String folderName, String folderPath) throws Exception {
		String destFldrPath = null;
		
		try {
			IDfFolder isFolderExists = session.getFolderByPath(folderPath + "/" + folderName);
			 if(isFolderExists!=null){
				 destFldrPath = folderPath + "/" + folderName;
			 }
			 else{
				 createFolder(folderName, folderPath);
				 destFldrPath = folderPath + "/" + folderName;
			 }
		} catch (DfException e) {			
			LOGGER.error("Error Code (CS15) : ", e.fillInStackTrace());
		}
		
		return destFldrPath;
	}
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
		
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.debug("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (CS05) : ", e.fillInStackTrace());
		}
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {
		
		try {
			sMgr.release(session);
			LOGGER.debug("Session Released.");
			LOGGER.debug("LOS Create Service Request Completed Successfully.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (CS17) : ", e.fillInStackTrace());
		}		
		
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {		
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (CS06) : ", e.fillInStackTrace());
		}
		
		return idfsessionmanager;
	}
	

}
