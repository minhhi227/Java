/**
* ______________________________________________________________________________
*
* File: SearchDocsByMetadata.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 16, 2012   3:19:18 PM   2012
* Description: This class will return a list of documents (Document Id, Document
* 			   Name, URL Link, Creation Date, Upload By and doc_sub_type) based 
* 			   on the Metadata provided by LOS-Search by Metadata Functionality.              
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.searchbymetadata;

import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 14, 2012
 * @Last Modification Time   3:19:18 PM
 * @Last Modification Year   2012 
 */

public class SearchDocsByMetadata {	   
    
    private IDfSession session = null;
	private IDfSessionManager sMgr = null;
	
	//array lists to store results
	//Document Id
	private ArrayList<String> documentId = new ArrayList<String>();
	
	/**
	 * @return the documentId
	 */
	public ArrayList<String> getDocumentId() {
		return documentId;
	}

	/**
	 * @param documentId the documentId to set
	 */
	public void setDocumentId(ArrayList<String> documentId) {
		this.documentId = documentId;
	}

	//Document Name
	private ArrayList<String> documentName = new ArrayList<String>();
	
	/**
	 * @return the documentName
	 */
	public ArrayList<String> getDocumentName() {
		return documentName;
	}

	/**
	 * @param documentName the documentName to set
	 */
	public void setDocumentName(ArrayList<String> documentName) {
		this.documentName = documentName;
	}

	//Branch Number
	private ArrayList<String> branchNumber = new ArrayList<String>();
	
	/**
	 * @return the branchNumber
	 */
	public ArrayList<String> getBranchNumber() {
		return branchNumber;
	}

	/**
	 * @param branchNumber the branchNumber to set
	 */
	public void setBranchNumber(ArrayList<String> branchNumber) {
		this.branchNumber = branchNumber;
	}

	//Creation Date
	private ArrayList<String> creationDate = new ArrayList<String>();
	
	/**
	 * @return the creationDate
	 */
	public ArrayList<String> getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(ArrayList<String> creationDate) {
		this.creationDate = creationDate;
	}

	//Upload By
	private ArrayList<String> uploadBy = new ArrayList<String>();
	
	/**
	 * @return the uploadBy
	 */
	public ArrayList<String> getUploadBy() {
		return uploadBy;
	}

	/**
	 * @param uploadBy the uploadBy to set
	 */
	public void setUploadBy(ArrayList<String> uploadBy) {
		this.uploadBy = uploadBy;
	}

	//Doc Sub Type
	private ArrayList<String> docSubType = new ArrayList<String>();
	
	/**
	 * @return the docSubType
	 */
	public ArrayList<String> getDocSubType() {
		return docSubType;
	}

	/**
	 * @param docSubType the docSubType to set
	 */
	public void setDocSubType(ArrayList<String> docSubType) {
		this.docSubType = docSubType;
	}

	// Initialising the logger from org.apache.Log4j  	
	private Logger LOGGER;
	private String outputStrXml = null;
	
	 /** 
	 * Method Description: This method will return a list of documents (Document Id, Document Name 
	 * 					   URL Link, Creation Date, Upload By and doc_sub_type) based on the Metadata 
	 * 					   provided by LOS Search By Metadata functionality.
	 *                     
	 * @return void   : returns no value.
	 */		
	public String searchByMetadata(SearchDocsByMetadata searchSrvObj, Logger logger, ResourceBundle rsb, 
			ReadSMStringXML inputStrXmlObj, String reqReceivedDate, String status, String errorCode, 
			String errorMessage) throws Exception 
	 {		
		boolean noResultsFound = false;		
		
	     try { 
	    	 //logger
	    	 LOGGER = logger;
	    	 
	    	 //Create Session	    	
	    	 session = createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));
	    	 
	    	 if(session!=null){    	 
	    		 
	    	 //calling executeQuery method	    	 	    		 
	    	 noResultsFound = executeQuery(searchSrvObj, rsb, inputStrXmlObj, reqReceivedDate, status, errorCode, errorMessage);
	    	 
	    	  if(noResultsFound==true){
	    		  
	    		status = "2";
	  			errorCode = "SBM11";
	  			errorMessage = "No Records Found based on the Search Criteria.";
	  			WriteSMStringXML outputStrXmlObj = new WriteSMStringXML();
	  			outputStrXml = outputStrXmlObj.createXML(searchSrvObj, LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
	  					status, errorCode, errorMessage);
	    	  }
	    	  else{
	    		  //LOGGER.debug("Record(s) Retrieved Successfully.");
	    	  }
	    	  
	    	 }
	    	 else{	    		 
	    		 status = "1";
	  			 errorCode = "SBM05";
	  			 errorMessage = "Session Not Created.";
	  			 WriteSMStringXML outputStrXmlObj = new WriteSMStringXML();
	  			 outputStrXml = outputStrXmlObj.createXML(searchSrvObj, LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
	  					 status, errorCode, errorMessage);
	    	 }
	 		
		} catch (Exception e) {			
			LOGGER.error("Error Code (SBM04) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
				if(session!=null){
					 releaseSession();
				 }
			} catch (Exception e) {			
				e.printStackTrace();
			}
	     }	
	     
	     return outputStrXml;
	     
	 }	
	
	 /** 
	 * Method Description: This method is used to execute the search by metadata query.
	 *	 
	 * 	 
	 * @return boolean   : returns true or false value.
	 */		
	private boolean executeQuery(SearchDocsByMetadata searchSrvObj, ResourceBundle rsb, ReadSMStringXML inputStrXmlObj, 
			String reqReceivedDate, String status, String errorCode, String errorMessage) throws Exception {			
		
		IDfClientX clientx = null;
		IDfQuery query = null;
		IDfCollection coll = null;
		boolean noResultsFound = true;
		String queryString = null, condtString = null;
		
		try {	         
	         //calling getSearchFilterValues method
	         condtString = getSearchFilterValues(inputStrXmlObj);
	         
	         if(condtString!=null){
	        	 
	        	//Query String Construction
		        queryString = "SELECT r_object_id, object_name, branch_number, r_creation_date, upload_by, doc_sub_type " +
		        		"FROM " + rsb.getString("DOC_TYPE") + " WHERE " + condtString + 
		        		 "doc_upload_status!='Deleted'";
		        LOGGER.debug("Input Parameter for Search By Metadata Service");
		        LOGGER.debug("Query : " + queryString);
	         
				clientx = new DfClientX();
				query =clientx.getQuery();			
				query.setDQL(queryString);			
				coll = query.execute(session, IDfQuery.DF_READ_QUERY);
				
				while(coll.next()){					
					
					noResultsFound = false;
					
					//adding results to list
					documentId.add(coll.getString("r_object_id"));
					documentName.add(coll.getString("object_name"));
					branchNumber.add(coll.getString("branch_number"));
					creationDate.add(coll.getString("r_creation_date"));
					uploadBy.add(coll.getString("upload_by"));
					docSubType.add(coll.getString("doc_sub_type"));
				}
				
				//setting values
				setDocumentId(documentId);
				setDocumentName(documentName);
				setBranchNumber(branchNumber);
				setCreationDate(creationDate);
				setUploadBy(uploadBy);
				setDocSubType(docSubType);				
				
				coll.close();
				
				if(noResultsFound == false){
					status = "0";
					errorCode = "";
					errorMessage = "";	
					LOGGER.debug("Query Executed & " + documentId.size() +" Record(s) Retrieved Successfully.");
					//write results to outputStrXml
					WriteSMStringXML outputStrXmlObj = new WriteSMStringXML();
					outputStrXml = outputStrXmlObj.createXML(searchSrvObj, LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
							status, errorCode, errorMessage);
				}
				
	         }else{
	        	 noResultsFound = false;
	 			 status = "1";
	 			 errorCode = "SBM10";
	 			 errorMessage = "Atleast one Search Filter is Mandatory.";
	 			 WriteSMStringXML outputStrXmlObj = new WriteSMStringXML();
	 			 outputStrXml = outputStrXmlObj.createXML(searchSrvObj, LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
	 					 status, errorCode, errorMessage);
	         }
			
		} catch (Exception e) {
			noResultsFound = false;
			status = "1";
			errorCode = "SBM07";
			errorMessage = e.getMessage();
			WriteSMStringXML outputStrXmlObj = new WriteSMStringXML();
			outputStrXml = outputStrXmlObj.createXML(searchSrvObj, LOGGER, rsb, inputStrXmlObj, reqReceivedDate, 
					status, errorCode, errorMessage);			
			LOGGER.error("Error Code (SBM07) : ", e.fillInStackTrace());
		}
		
		return noResultsFound;
		
	}
	
	/** 
	 * Method Description: This method is used to construct the condition string based on 
	 * 					   the search filter values from client. 
	 * 	 
	 * @return String    : Constructed Condition String based on search filter values.
	 */	
	@SuppressWarnings("unused")
	private String getSearchFilterValues(ReadSMStringXML inputStrXmlObj){
		
		String condtString = null;
		
		try {
			//search filters condition string
			if(!inputStrXmlObj.getBranch_number().equalsIgnoreCase("")){
			 
			 if(condtString!=null){    						 
				 
					condtString = condtString + "branch_number" + " = '" + inputStrXmlObj.getBranch_number() + "' AND ";    						
				    
				}else{   		    				
					condtString = "branch_number" + " = '" + inputStrXmlObj.getBranch_number() + "' AND ";        						    				
				}
			}
			
			if(!inputStrXmlObj.getCust_type().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "cust_type" + " = '" + inputStrXmlObj.getCust_type() + "' AND ";    						
					    
					}else{   		    				
						condtString = "cust_type" + " = '" + inputStrXmlObj.getCust_type() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getCust_id_number().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "cust_id_number" + " = '" + inputStrXmlObj.getCust_id_number() + "' AND ";    						
					    
					}else{   		    				
						condtString = "cust_id_number" + " = '" + inputStrXmlObj.getCust_id_number() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getCust_id_type().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "cust_id_type" + " = '" + inputStrXmlObj.getCust_id_type() + "' AND ";    						
					    
					}else{   		    				
						condtString = "cust_id_type" + " = '" + inputStrXmlObj.getCust_id_type() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getCar_year_created().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "car_year_created" + " = '" + inputStrXmlObj.getCar_year_created() + "' AND ";    						
					    
					}else{   		    				
						condtString = "car_year_created" + " = '" + inputStrXmlObj.getCar_year_created() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getFacility_number().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "facility_number" + " = '" + inputStrXmlObj.getFacility_number() + "' AND ";    						
					    
					}else{   		    				
						condtString = "facility_number" + " = '" + inputStrXmlObj.getFacility_number() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getCollateral_number().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "collateral_number" + " = '" + inputStrXmlObj.getCollateral_number() + "' AND ";    						
					    
					}else{   		    				
						condtString = "collateral_number" + " = '" + inputStrXmlObj.getCollateral_number() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getDoc_sub_type().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "doc_sub_type" + " = '" + inputStrXmlObj.getDoc_sub_type() + "' AND ";    						
					    
					}else{   		    				
						condtString = "doc_sub_type" + " = '" + inputStrXmlObj.getDoc_sub_type() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getCust_cif_number().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "cust_cif_number" + " = '" + inputStrXmlObj.getCust_cif_number() + "' AND ";    						
					    
					}else{   		    				
						condtString = "cust_cif_number" + " = '" + inputStrXmlObj.getCust_cif_number() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getCust_name().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "cust_name" + " = '" + inputStrXmlObj.getCust_name() + "' AND ";    						
					    
					}else{   		    				
						condtString = "cust_name" + " = '" + inputStrXmlObj.getCust_name() + "' AND ";        						    				
					}
			}
			
			if(!inputStrXmlObj.getUpload_by().equalsIgnoreCase("")){
				 
				 if(condtString!=null){    						 
					 
						condtString = condtString + "upload_by" + " = '" + inputStrXmlObj.getUpload_by() + "' AND ";    						
					    
					}else{   		    				
						condtString = "upload_by" + " = '" + inputStrXmlObj.getUpload_by() + "' AND ";        						    				
					}
			}
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (SBM08) : ", e.fillInStackTrace());
		}
		
		return condtString;
	}
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
		
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);
			session = sMgr.getSession(docbase);
			
			if (session != null) {
				LOGGER.debug("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (SBM05) : ", e.fillInStackTrace());
		}	
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {		
		
		try {
			sMgr.release(session);
			LOGGER.debug("Session Released.");
			LOGGER.debug("LOS Search By Metadata Service Request Completed Successfully.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (SBM09) : ", e.fillInStackTrace());
		}		
		
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {		
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (SBM06) : ", e.fillInStackTrace());
		}
		
		return idfsessionmanager;
	}
	
	
}
