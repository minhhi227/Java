/**
* ______________________________________________________________________________
*
* File: SearchByMetadataService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 16, 2012   9:16:27 AM   2012
* Description: This class is the main class (Service Class) and will perform 
* 			   following things:
* 				1. Retrieves all the required info from the input String XML 
* 				   using ReadSMStringXML Class.
*               2. Searches the ECM for documents using SearchDocsByMetadata
*                  Class.
*               3. Writes all the collected info into a String XML using 
*                  WriteSMStringXML Class.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.searchbymetadata;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.fc.common.DfLogger;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 14, 2012
 * @Last Modification Time   9:16:27 AM
 * @Last Modification Year   2012 
 */

@DfsPojoService(targetNamespace = "http://searchbymetadata.los.services.ecm.vb.com", requiresAuthentication = true)
public class SearchByMetadataService {
	
	// Initialising the logger from org.apache.Log4j  	
	private Logger LOGGER;  
	
	//Resource Bundle
	private ResourceBundle rsb = null;
	
	//Received Date
	private String reqReceivedDate = null;
	
	//Status
	private String status = null;
	
	//Error Code
	private String errorCode = null;
	
	//Error Message
	private String errorMessage = null;
	
	//Output String XML
	private String outputStrXml = null;
	
	 /** 
	 * Method Description: This method is used to search documents in ECM based on the document properties 
	 *                     provided by Client.                     
	 * 
	 * @param String     : inputStringXML contains all the required information (Search Filters) to search document(s).
	 *                     
	 * @return String	 : outputStrXml which contains document_id, document_name, url_link, creation_date,
	 * 					   upload_by and doc_sub_type values in String XML format.
	 */		
	public String searchByMetadata(String inputStringXml) throws Exception 
	 {
		
	     try {
	    	 //logger
	    	 LOGGER = DfLogger.getLogger(SearchByMetadataService.class);
	    	 LOGGER.debug("LOS Serach By Metadata Service Request Started..");
	    	 
	    	 //resource bundle
	    	 rsb = ResourceBundle.getBundle("com.vb.ecm.services.los.LOSConfig");
	    	 
	    	//request received date			
		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    reqReceivedDate = sdf.format(new Date());		    
			
			//read input values from string xml
			ReadSMStringXML inputStrXmlObj = new ReadSMStringXML();
			outputStrXml = inputStrXmlObj.processInputData(LOGGER, rsb, inputStringXml, reqReceivedDate, status, 
					errorCode, errorMessage); 
			
			if(outputStrXml.equals("success")){
			
			//create document
			if(!inputStrXmlObj.getUserId().equalsIgnoreCase("") && 
				  inputStrXmlObj.getMessageType().equals(rsb.getString("SEARCH_BY_METADATA_MESSAGE_TYPE")) && 
				  	inputStrXmlObj.getAppId().equals(rsb.getString("SOURCE_APP_ID")) &&
				  	  !inputStrXmlObj.getReqtimeStamp().equalsIgnoreCase("")){		
				
					//execute query
					SearchDocsByMetadata searchSrvObj = new SearchDocsByMetadata();
					outputStrXml = searchSrvObj.searchByMetadata(searchSrvObj, LOGGER, rsb, inputStrXmlObj, 
							reqReceivedDate, status, errorCode, errorMessage);					
			}
			else{
				status = "1";
				errorCode = "SBM01";
				errorMessage = "Missing Mandatory Values from Client to Search Document(s).";
				WriteSMStringXML outputStrXmlObj = new WriteSMStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
				LOGGER.debug("Missing Mandatory Values from client to to Search Document(s).");
				}
			}
			else{
				status = "1";
				errorCode = "SBM02";
				errorMessage = outputStrXml;
				WriteSMStringXML outputStrXmlObj = new WriteSMStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
			}
			 
		} catch (Exception e) {	
			
			LOGGER.error("Error Code (SBM01) : ", e.fillInStackTrace());
			LOGGER.error("LOS Search By Metadata Service Request Completed with Errors.");
		}	    
		
		return outputStrXml;		
	 }
	

}
