/**
* ______________________________________________________________________________
*
* File: ReadSMStringXML.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 16, 2012   9:16:27 AM   2012
* Description: This class is used to get all the input values that are passed 
* 			   from LOS that is reading the String XML and collecting all the
* 			   input values to process the request. 
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.searchbymetadata;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 14, 2012
 * @Last Modification Time   9:16:27 AM
 * @Last Modification Year   2012
 * 
 */

import java.io.StringReader;
import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
 
public class ReadSMStringXML {
	
	//User Id
	private String userId = null;
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	//Message Type
	private String messageType = null;
	
	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	//Application Id
	private String appId = null;
	
	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	//Request Time Stamp
	private String reqtimeStamp = null;
	
	/**
	 * @return the reqtimeStamp
	 */
	public String getReqtimeStamp() {
		return reqtimeStamp;
	}

	/**
	 * @param reqtimeStamp the reqtimeStamp to set
	 */
	public void setReqtimeStamp(String reqtimeStamp) {
		this.reqtimeStamp = reqtimeStamp;
	}

	//Branch Number
	private String branch_number = null;
	
	/**
	 * @return the branch_number
	 */
	public String getBranch_number() {
		return branch_number;
	}

	/**
	 * @param branch_number the branch_number to set
	 */
	public void setBranch_number(String branch_number) {
		this.branch_number = branch_number;
	}

	//Customer Type
	private String cust_type = null;
	
	/**
	 * @return the cust_type
	 */
	public String getCust_type() {
		return cust_type;
	}

	/**
	 * @param cust_type the cust_type to set
	 */
	public void setCust_type(String cust_type) {
		this.cust_type = cust_type;
	}

	//Customer Id Number
	private String cust_id_number = null;
	
	/**
	 * @return the cust_id_number
	 */
	public String getCust_id_number() {
		return cust_id_number;
	}

	/**
	 * @param cust_id_number the cust_id_number to set
	 */
	public void setCust_id_number(String cust_id_number) {
		this.cust_id_number = cust_id_number;
	}

	//Customer Id Type
	private String cust_id_type = null;
	
	/**
	 * @return the cust_id_type
	 */
	public String getCust_id_type() {
		return cust_id_type;
	}

	/**
	 * @param cust_id_type the cust_id_type to set
	 */
	public void setCust_id_type(String cust_id_type) {
		this.cust_id_type = cust_id_type;
	}

	//Car Year Created
	private String car_year_created = null;
	
	/**
	 * @return the car_year_created
	 */
	public String getCar_year_created() {
		return car_year_created;
	}

	/**
	 * @param car_year_created the car_year_created to set
	 */
	public void setCar_year_created(String car_year_created) {
		this.car_year_created = car_year_created;
	}

	//Facility Number
	private String facility_number = null;
	
	/**
	 * @return the facility_number
	 */
	public String getFacility_number() {
		return facility_number;
	}

	/**
	 * @param facility_number the facility_number to set
	 */
	public void setFacility_number(String facility_number) {
		this.facility_number = facility_number;
	}

	//Collateral Number
	private String collateral_number = null;
	
	/**
	 * @return the collateral_number
	 */
	public String getCollateral_number() {
		return collateral_number;
	}

	/**
	 * @param collateral_number the collateral_number to set
	 */
	public void setCollateral_number(String collateral_number) {
		this.collateral_number = collateral_number;
	}

	//Doc Sub Type
	private String doc_sub_type = null;
	
	/**
	 * @return the doc_sub_type
	 */
	public String getDoc_sub_type() {
		return doc_sub_type;
	}

	/**
	 * @param doc_sub_type the doc_sub_type to set
	 */
	public void setDoc_sub_type(String doc_sub_type) {
		this.doc_sub_type = doc_sub_type;
	}

	//Customer CIF Number
	private String cust_cif_number = null;
	
	/**
	 * @return the cust_cif_number
	 */
	public String getCust_cif_number() {
		return cust_cif_number;
	}

	/**
	 * @param cust_cif_number the cust_cif_number to set
	 */
	public void setCust_cif_number(String cust_cif_number) {
		this.cust_cif_number = cust_cif_number;
	}

	//Customer Name
	private String cust_name = null;
	
	/**
	 * @return the cust_name
	 */
	public String getCust_name() {
		return cust_name;
	}

	/**
	 * @param cust_name the cust_name to set
	 */
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	//Upload By
	private String upload_by = null;
	
	/**
	 * @return the upload_by
	 */
	public String getUpload_by() {
		return upload_by;
	}

	/**
	 * @param upload_by the upload_by to set
	 */
	public void setUpload_by(String upload_by) {
		this.upload_by = upload_by;
	}
	
	// Initialising the logger from org.apache.Log4j  	
	private Logger LOGGER; 

	/** 
	 * Method Description: This method is used to process the input data that is collecting all the
* 			   			   input values to further process the request.                    
	 * 
	 * @param String XML : Contains all the required information from LOS to search document(s).	
	 * 	                    
	 * @return void		 : returns no value.
	 */
	public String processInputData(Logger logger, ResourceBundle rsb, String inputStringXml, String reqReceivedDate, 
			String status, String errorCode, String errorMessage){
		
		String outputStrXml = "success";
		
		try {
			//logger
			LOGGER = logger;
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(inputStringXml));	    
			Document doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize(); 
			
			//header element
			NodeList nList = doc.getElementsByTagName("header");
	 
			   Node nNode = nList.item(0);
			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) nNode;		      
			      
			      if(getTagValue("user_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"user_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("message_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"message_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("source_app_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"source_app_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("request_timestamp", eElement) == null){
			    	
			    	  outputStrXml = "The element type \"request_timestamp\" doesn't exist in request.";
			      }
			      else{			      
				      setUserId(getTagValue("user_id", eElement));			      
				      setMessageType(getTagValue("message_type", eElement));			      
				      setAppId(getTagValue("source_app_id", eElement));			     
				      setReqtimeStamp(getTagValue("request_timestamp", eElement));
			      }       
			   }			
			
			//Search Filters element
			NodeList docList = doc.getElementsByTagName("SearchFilters");
	 
			   Node node = docList.item(0);
			   if (node.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) node;
			      
			      //Branch Number			      
			      if(getTagValue("branch_number", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"branch_number\" doesn't exist in request.";		    	 
			      }
			      else if(getTagValue("cust_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("cust_id_number", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_id_number\" doesn't exist in request.";
			      }
			      else if(getTagValue("cust_id_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_id_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("doc_sub_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"doc_sub_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("upload_by", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"upload_by\" doesn't exist in request.";		    	  
			      }			    	  
			      else if(getTagValue("car_year_created", eElement) == null){
		    		  
		    		  outputStrXml = "The element type \"car_year_created\" doesn't exist in request.";
		    	  }  	  
			      else if(getTagValue("facility_number", eElement) == null){
		    		  
		    		  outputStrXml = "The element type \"facility_number\" doesn't exist in request.";
		    	  }			      
			      else if(getTagValue("collateral_number", eElement) == null){
		    		  
		    		  outputStrXml = "The element type \"collateral_number\" doesn't exist in request.";
		    	  }			     
			      else if(getTagValue("cust_name", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_name\" doesn't exist in request.";
			      }
			      else if(getTagValue("cust_cif_number", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_cif_number\" doesn't exist in request.";
			      }
			      else{		      
				      setBranch_number(getTagValue("branch_number", eElement));			      
				      setCust_type(getTagValue("cust_type", eElement));		          
			          setCust_id_number(getTagValue("cust_id_number", eElement));		          
			          setCust_id_type(getTagValue("cust_id_type", eElement));			      
				      setCar_year_created(getTagValue("car_year_created", eElement));			      
				      setFacility_number(getTagValue("facility_number", eElement));			      
				      setCollateral_number(getTagValue("collateral_number", eElement));			      
				      setDoc_sub_type(getTagValue("doc_sub_type", eElement));			      
				      setCust_name(getTagValue("cust_name", eElement));			      
				      setCust_cif_number(getTagValue("cust_cif_number", eElement));			      
				      setUpload_by(getTagValue("upload_by", eElement));
			      }			     			      
			   }			
			   
		} catch (Exception e) {
			
			outputStrXml = e.getMessage();
			LOGGER.error("Error Code (SBM02) : ", e.fillInStackTrace());
		} 
		
		return outputStrXml;
	}
	
	private String getTagValue(String sTag, Element eElement) {
		  
		String tagValue = null;
		
		try {
			NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
 
			    Node nValue = (Node) nlList.item(0); 
			    
			    if(nValue!=null){
			    	tagValue = nValue.getNodeValue();
			    }
			    else{
			    	tagValue = "";
			    }
			    
		} catch (Exception e) {
			
			LOGGER.error("Error Code (SBM03) : ", e.fillInStackTrace());
		}
	 
		return tagValue;
	  }
	
 
}
