/**
* ______________________________________________________________________________
*
* File: WriteSMStringXML.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 16, 2012   9:16:27 AM   2012
* Description: This class is used to write all the output data to a String XML
* 			   in a specific format as requested by the client.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.searchbymetadata;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 14, 2012
 * @Last Modification Time   9:16:27 AM
 * @Last Modification Year   2012
 */

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class WriteSMStringXML {
	
	/** 
	 * Method Description: This method is used to write the output data to a String XML
	 * 			   		   in a specific format as requested by the client.
	 * 	                    
	 * @return String	 : returns output as String XML.
	 */
	public String createXML(SearchDocsByMetadata searchSrvObj, Logger LOGGER, ResourceBundle rsb, 
			ReadSMStringXML inputStrXmlObj, String reqReceivedDate, String status, String errorCode, String errorMessage) {			
		 
		String returnXMLString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n";			
       
        DocumentBuilderFactory documentBuilderFactory;
        DocumentBuilder documentBuilder;
        Document document;        
        
        try { 
            documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.newDocument();
           
            Element messageElement = document.createElement("message");
            document.appendChild(messageElement);            
  
            Element headerElement = document.createElement("header");
            messageElement.appendChild(headerElement);
 
                Element headerItems;
                 
                headerItems = document.createElement("user_id");
                headerItems.appendChild(document.createTextNode(inputStrXmlObj.getUserId())); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("message_type");
                headerItems.appendChild(document.createTextNode(inputStrXmlObj.getMessageType())); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("source_app_id");
                headerItems.appendChild(document.createTextNode(inputStrXmlObj.getAppId()));
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("request_timestamp");
                headerItems.appendChild(document.createTextNode(inputStrXmlObj.getReqtimeStamp()));
                headerElement.appendChild(headerItems); 
                
                headerItems = document.createElement("receive_timestamp");
                headerItems.appendChild(document.createTextNode(reqReceivedDate));
                headerElement.appendChild(headerItems);                 
                
    		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
    		    String strDate = sdf.format(new Date());
                
    		    headerItems = document.createElement("response_timestamp");
    		    headerItems.appendChild(document.createTextNode(strDate));
                headerElement.appendChild(headerItems);
                
                Element responseStatus = document.createElement("response_status");
                headerElement.appendChild(responseStatus);
                
                Element resStatusItems;
                
                resStatusItems = document.createElement("status");                
                resStatusItems.appendChild(document.createTextNode(status));               
                responseStatus.appendChild(resStatusItems);
                
                Element exception = document.createElement("Exception");
                responseStatus.appendChild(exception);
                
                Element exceptionItems;
                
                exceptionItems = document.createElement("ErrorCode");               
                exceptionItems.appendChild(document.createTextNode(errorCode));               
                exception.appendChild(exceptionItems);
                
                exceptionItems = document.createElement("ErrorMessage");
                exceptionItems.appendChild(document.createTextNode(errorMessage));
                exception.appendChild(exceptionItems);
                
                Element body = document.createElement("body");
                messageElement.appendChild(body);
                
                Element message_response = document.createElement("message_response");
                body.appendChild(message_response);
                
                Element documents = document.createElement("Documents");
                message_response.appendChild(documents);               
                
                for (int i=0; i<searchSrvObj.getDocumentId().size(); i++) {
                
	                Element doc = document.createElement("Document");
	                documents.appendChild(doc);
	                
	                Element docItems;
	                
	                docItems = document.createElement("document_id");	                
	                docItems.appendChild(document.createTextNode(searchSrvObj.getDocumentId().get(i)));               
	                doc.appendChild(docItems);
	                
	                docItems = document.createElement("document_name");               
	                docItems.appendChild(document.createTextNode(searchSrvObj.getDocumentName().get(i)));               
	                doc.appendChild(docItems);
	                
	                docItems = document.createElement("url_link");
	                	
                	String url_link = rsb.getString("URL_LINK") + 
                			searchSrvObj.getDocumentId().get(i) + "/parameter0/" + 
	                		rsb.getString("BOCS_SERVER_NAME") +
	                		searchSrvObj.getBranchNumber().get(i) + "/";	               	                
	                
	                docItems.appendChild(document.createTextNode(url_link));               
	                doc.appendChild(docItems);
	                
	                docItems = document.createElement("creation_date");               
	                docItems.appendChild(document.createTextNode(searchSrvObj.getCreationDate().get(i)));               
	                doc.appendChild(docItems);
	
	                docItems = document.createElement("upload_by");               
	                docItems.appendChild(document.createTextNode(searchSrvObj.getUploadBy().get(i)));               
	                doc.appendChild(docItems);
	                
	                docItems = document.createElement("doc_sub_type");               
	                docItems.appendChild(document.createTextNode(searchSrvObj.getDocSubType().get(i)));            
	                doc.appendChild(docItems);                
                }
                
                //clear all array list
                searchSrvObj.getDocumentId().clear();
                searchSrvObj.getDocumentName().clear();
                searchSrvObj.getBranchNumber().clear();
                searchSrvObj.getCreationDate().clear();
                searchSrvObj.getUploadBy().clear();
                searchSrvObj.getDocSubType().clear();
           
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            
            StringWriter sw = new StringWriter();
        	StreamResult result = new StreamResult(sw);           
            
            DOMSource source = new DOMSource(document);
            
            transformer.transform(source, result);
            returnXMLString = returnXMLString + sw.toString();
 
        } catch (Exception e) {
        	LOGGER.error("Error Code (SBM12) : ", e.fillInStackTrace());
        } 
        return returnXMLString;
    }
	
	public String createExceptionXML(Logger LOGGER, ResourceBundle rsb, String reqReceivedDate, 
			String status, String errorCode, String errorMessage) {
		 
		String returnXMLString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n";			
       
        DocumentBuilderFactory documentBuilderFactory;
        DocumentBuilder documentBuilder;
        Document document;
        try { 
            documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.newDocument();	            
           
            Element messageElement = document.createElement("message");
            document.appendChild(messageElement);            
  
            Element headerElement = document.createElement("header");
            messageElement.appendChild(headerElement);
 
                Element headerItems;
                 
                headerItems = document.createElement("user_id");
                headerItems.appendChild(document.createTextNode("")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("message_type");
                headerItems.appendChild(document.createTextNode("")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("source_app_id");
                headerItems.appendChild(document.createTextNode(""));
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("request_timestamp");
                headerItems.appendChild(document.createTextNode(""));
                headerElement.appendChild(headerItems); 
                
                headerItems = document.createElement("receive_timestamp");
                headerItems.appendChild(document.createTextNode(reqReceivedDate));
                headerElement.appendChild(headerItems);                
                
    		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
    		    String strDate = sdf.format(new Date());
                
    		    headerItems = document.createElement("response_timestamp");
    		    headerItems.appendChild(document.createTextNode(strDate));
                headerElement.appendChild(headerItems);
                
                Element responseStatus = document.createElement("response_status");
                headerElement.appendChild(responseStatus);
                
                Element resStatusItems;
                
                resStatusItems = document.createElement("status");                
                resStatusItems.appendChild(document.createTextNode(status));               
                responseStatus.appendChild(resStatusItems);
                
                Element exception = document.createElement("Exception");
                responseStatus.appendChild(exception);
                
                Element exceptionItems;
                
                exceptionItems = document.createElement("ErrorCode");
                exceptionItems.appendChild(document.createTextNode(errorCode));
                exception.appendChild(exceptionItems);
                
                exceptionItems = document.createElement("ErrorMessage");
                exceptionItems.appendChild(document.createTextNode(errorMessage));
                exception.appendChild(exceptionItems);
                
                Element body = document.createElement("body");
                messageElement.appendChild(body);
                
                Element message_response = document.createElement("message_response");
                body.appendChild(message_response);              
           
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            
            StringWriter sw = new StringWriter();
        	StreamResult result = new StreamResult(sw);           
            
            DOMSource source = new DOMSource(document);
            
            transformer.transform(source, result);
            returnXMLString = returnXMLString + sw.toString();
 
        } catch (Exception e) {
        	LOGGER.error("Error Code (SBM13) : ", e.fillInStackTrace());
        } 
        return returnXMLString;
    }

}
