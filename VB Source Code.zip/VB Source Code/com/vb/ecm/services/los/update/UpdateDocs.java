/**
* ______________________________________________________________________________
*
* File: UpdateDocs.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 16, 2012   11:31:25 AM   2012
* Description: This class will update meta data of the documents present in ECM 
* 			   repository based on the data (attribute names and there values) 
* 			   provided by LOS Update Functionality.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.update;

import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfBatchManager;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfScopeManager;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.ScopeBoundary;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 18, 2012
 * @Last Modification Time   11:31:25 AM
 * @Last Modification Year   2012 
 */

public class UpdateDocs {
    
    private IDfSession session = null;
	private IDfSessionManager sMgr; 
	
	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;
	
	 /** 
	 * Method Description: This method is used to update meta data of the documents present in 
	 * 					   ECM based on the data (document properties) provided by LOS Update Functionality.
	 *                     
	 * @return String  	 : returns Message.
	 */		
	public String updateDocuments(Logger logger, ResourceBundle rsb, ReadUSStringXML inputStrXmlObj, 
			String reqReceivedDate, String status, String errorCode, String errorMessage, 
			ArrayList<String> deleteDocIds, ArrayList<String> docPropsString) throws Exception 
	 {					
		String successMsg = null;
		int count = 0;
		IDfScopeManager scopeMgr;
		IDfBatchManager bmgr = null;
		 
	     try {
	    	 //logger
	    	 LOGGER = logger;
	    	 
	    	 //Create Session	    	 
	    	 session = createSession(rsb.getString("REPO_NAME"), rsb.getString("USER_NAME"), 
	    			 rsb.getString("USER_PASSWORD"));   	
	    	 
	    	 if(session!=null){    		
	    		 
	    	 //using transactions in code
	    	 sMgr = session.getSessionManager();
	    	 scopeMgr = sMgr.getScopeManager();	    	 
	    	 scopeMgr.enableServerScope(true);	    	
	    	 scopeMgr.setDefaultScope(ScopeBoundary.BATCH, true);   	 
	    	 
	    	 bmgr = session.getBatchManager();
	    	 bmgr.openBatch(bmgr.getMaxBatchSize(), true, true, true, null);
	         
	    	 //getting all the object id's from documentIds
	    	 for (int i = 0; i < deleteDocIds.size(); i++) {
	    		 
	             //calling executeQuery method
	             successMsg = executeQuery(rsb, deleteDocIds.get(i), docPropsString.get(i), inputStrXmlObj.getUserId());
	             if(successMsg.equalsIgnoreCase("1")){
			    		count++;
			      }         
            
              }		          
		          
	           if(count == inputStrXmlObj.getDeleteDocIds().size()){
	          
		          //commit
		          bmgr.commitBatch();
		          bmgr.closeBatch();
		          LOGGER.debug("Query Executed & " + count + " Record(s) Updated Successfully in ECM.");
		          
	           }else{
	        	  
	        	  bmgr.abortBatch();	        	  
	        	  successMsg = "Document(s) Doesn't Exist in ECM to Update.";				  	        	  
	           }
		    	
	    	 }else{	    		    
	    		   successMsg = "Session Not Created.";										
	    	 }
	 		
		} catch (Exception e) {
			bmgr.abortBatch();
			successMsg = "Error : " + e.getMessage();			
		    LOGGER.error("Error Code (US05) : ", e.fillInStackTrace());
		}
	     finally{
	    	 try {
	    		 if(bmgr!=null){
		    		 if(bmgr.isBatchActive())
		    			 bmgr.abortBatch();
	    		 }
	    		 
				if(session!=null){
					 releaseSession();
				 }
				
			} catch (Exception e) {				
				e.printStackTrace();
			}
	     }     
	     
		 return successMsg;
	 }	 
	
	 /** 
	 * Method Description: This method is used to execute the query (update query).                    
	 * 
	 * @param String     : Update Query String.	
	 *                     
	 * @return String	 : returns Message.
	 */	
	private String executeQuery(ResourceBundle rsb, String deleteDocId, String docPropsString, String userId) 
			throws Exception {		
		
		IDfClientX clientx = null;
		IDfQuery query = null;
		IDfCollection coll = null;
		String successMsg = null;		
		
		try { 
			clientx = new DfClientX();
			query =clientx.getQuery();				
			
			query.setDQL("UPDATE " + rsb.getString("DOC_TYPE") + " object" + docPropsString +
					" SET title = 'LOS Update Service-Document Updated by : "+ userId +"'" +
					" SET update_user = '"+ userId +"'" +
					" WHERE r_object_id = '" + deleteDocId + "' AND doc_upload_status!='Deleted'");
			
			/*LOGGER.debug("Update Query : " + "UPDATE " + rsb.getString("DOC_TYPE") + " object" + docPropsString +
					" SET title = 'LOS Update Service-Document Updated by : "+ userId +"'" +
					" SET update_user = '"+ userId +"'" +
					" WHERE r_object_id = '" + deleteDocId + "' AND doc_upload_status!='Deleted'");*/
			
			coll = query.execute(session, IDfQuery.DF_READ_QUERY);
			
			while(coll.next()){
				
				successMsg = coll.getString("objects_updated");				
			}
			
			coll.close();	
			
		} catch (Exception e) {	
			successMsg = "Error : " + e.fillInStackTrace();
			LOGGER.error("Error Code (US08) : ", e.fillInStackTrace());
		}		
		
		return successMsg;
	}
	
	/**
	 * Description : This method is used to create Session from Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSession
	 * @throws DfException
	 */	
	private IDfSession createSession(String docbase, String username, String password) throws Exception {
				
		try {
			sMgr = getInitializedSessionManager(docbase, username, password);			
			session = sMgr.getSession(docbase);			
			
			if (session != null) {
				LOGGER.debug("Session Created Successfully.");
			}
		} catch (Exception e) {			
			LOGGER.error("Error Code (US06) : ", e.fillInStackTrace());
		}		
		
		return session;
	}

	/**
	 * Description : This method is used to release Session.
	 * 
	 * @return void : null
	 */	
	private void releaseSession() throws Exception {		
		
		try {
			sMgr.release(session);
			LOGGER.debug("Session Released.");
			LOGGER.debug("LOS Update Service Request Completed Successfully.");
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (US09) : ", e.fillInStackTrace());
		}
		
	}

	/**
	 * Description : This method is used to create Session Manager.
	 * 
	 * @param docbase
	 * @param user
	 * @param password
	 * @return IDfSessionManager
	 * @throws DfException
	 */
	private IDfSessionManager getInitializedSessionManager(String docbase, String username, 
			String password) throws DfException {		
		
		IDfSessionManager idfsessionmanager = null;
		try {
			idfsessionmanager = DfClient.getLocalClient().newSessionManager();
			IDfLoginInfo idflogininfo = (new DfClientX()).getLoginInfo();
			idflogininfo.setUser(username);
			idflogininfo.setPassword(password);
			idfsessionmanager.setIdentity(docbase, idflogininfo);
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (US07) : ", e.fillInStackTrace());
		}
		
		return idfsessionmanager;
	}	


}
