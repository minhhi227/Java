/**
* ______________________________________________________________________________
*
* File: ReadUSStringXML.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 16, 2012   11:31:25 AM   2012
* Description: This class is used to get all the input values that are passed 
* 			   from LOS that is reading the String XML and collecting all the
* 			   input values to process the request. 
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.update;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 18, 2012
 * @Last Modification Time   11:31:25 AM
 * @Last Modification Year   2012
 * 
 */

import java.io.StringReader;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
 
public class ReadUSStringXML {
	
	//User Id
	private String userId = null;
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	//Message Type
	private String messageType = null;
	
	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	//Application Id
	private String appId = null;
	
	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	//Request Time Stamp
	private String reqtimeStamp = null;
	
	/**
	 * @return the reqtimeStamp
	 */
	public String getReqtimeStamp() {
		return reqtimeStamp;
	}

	/**
	 * @param reqtimeStamp the reqtimeStamp to set
	 */
	public void setReqtimeStamp(String reqtimeStamp) {
		this.reqtimeStamp = reqtimeStamp;
	}

	//deleteDocIds
	private ArrayList<String> deleteDocIds = new ArrayList<String>();
	
	/**
	 * @return the deleteDocIds
	 */
	public ArrayList<String> getDeleteDocIds() {
		return deleteDocIds;
	}

	/**
	 * @param deleteDocIds the deleteDocIds to set
	 */
	public void setDeleteDocIds(ArrayList<String> deleteDocIds) {
		this.deleteDocIds = deleteDocIds;
	}

	//docPropsString
	private ArrayList<String> docPropsString = new ArrayList<String>();
	
	/**
	 * @return the docPropsString
	 */
	public ArrayList<String> getDocPropsString() {
		return docPropsString;
	}

	/**
	 * @param docPropsString the docPropsString to set
	 */
	public void setDocPropsString(ArrayList<String> docPropsString) {
		this.docPropsString = docPropsString;
	}

	private String document_id = null;
	private String branch_number = null;
	private String cust_type = null;
	private String cust_id_number = null;
	private String cust_id_type = null;
	private String car_year_created = null;
	private String facility_number = null;
	private String collateral_number = null;
	private String doc_sub_type = null;
	private String cust_cif_number = null;
	private String cust_name = null;
	
	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;
	
	/** 
	 * Method Description: This method is used to process the input data that is collecting all the
* 			   			   input values to further process the request.                    
	 * 
	 * @param String XML : Contains all the required information from LOS to update document(s).	
	 * 	                    
	 * @return void		 : returns no value.
	 */
	public String processInputData(Logger logger, ResourceBundle rsb, String inputStringXml, String reqReceivedDate, 
			String status, String errorCode, String errorMessage){
		
		String outputStrXml = "success";
		
		try {
			//logger
			LOGGER = logger;
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(inputStringXml));	    
			Document doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize(); 
			
			//header element
			NodeList nList = doc.getElementsByTagName("header");			
	 
			   Node nNode = nList.item(0);
			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) nNode;	
			      
			      if(getTagValue("user_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"user_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("message_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"message_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("source_app_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"source_app_id\" doesn't exist in request.";
			      }
			      else if(getTagValue("request_timestamp", eElement) == null){
			    	
			    	  outputStrXml = "The element type \"request_timestamp\" doesn't exist in request.";
			      }
			      else{			      
				      setUserId(getTagValue("user_id", eElement));			      
				      setMessageType(getTagValue("message_type", eElement));			      
				      setAppId(getTagValue("source_app_id", eElement));			     
				      setReqtimeStamp(getTagValue("request_timestamp", eElement));
			      }
			   }			
			
			//Document element
			NodeList docList = doc.getElementsByTagName("Document");
			LOGGER.debug("Input Parameter for Update Service");
			
			for (int temp = 0; temp < docList.getLength(); temp++) {
	 
			   Node node = docList.item(temp);
			   if (node.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) node;
			      
			      //Document Id	
			      if(getTagValue("document_id", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"document_id\" doesn't exist in request.";		    	 
			      }
			      else if(getTagValue("branch_number", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"branch_number\" doesn't exist in request.";		    	 
			      }
			      else if(getTagValue("cust_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("cust_id_number", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_id_number\" doesn't exist in request.";
			      }
			      else if(getTagValue("cust_id_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_id_type\" doesn't exist in request.";
			      }
			      else if(getTagValue("doc_sub_type", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"doc_sub_type\" doesn't exist in request.";
			      }			      		    	  
			      else if(getTagValue("car_year_created", eElement) == null){
		    		  
		    		  outputStrXml = "The element type \"car_year_created\" doesn't exist in request.";
		    	  }  	  
			      else if(getTagValue("facility_number", eElement) == null){
		    		  
		    		  outputStrXml = "The element type \"facility_number\" doesn't exist in request.";
		    	  }			      
			      else if(getTagValue("collateral_number", eElement) == null){
		    		  
		    		  outputStrXml = "The element type \"collateral_number\" doesn't exist in request.";
		    	  }			     
			      else if(getTagValue("cust_name", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_name\" doesn't exist in request.";
			      }
			      else if(getTagValue("cust_cif_number", eElement) == null){
			    	  
			    	  outputStrXml = "The element type \"cust_cif_number\" doesn't exist in request.";
			      }
			      else{	      
				      document_id = getTagValue("document_id", eElement);
				      
				      if(!document_id.equalsIgnoreCase("")){
				      
					      //adding document_id to array list
					      deleteDocIds.add(document_id);
					      
					      branch_number = getTagValue("branch_number", eElement);
					      cust_type = getTagValue("cust_type", eElement);
					      cust_id_number = getTagValue("cust_id_number", eElement);
					      cust_id_type = getTagValue("cust_id_type", eElement);			      
					      car_year_created = getTagValue("car_year_created", eElement);
					      facility_number = getTagValue("facility_number", eElement);
					      collateral_number = getTagValue("collateral_number", eElement);
					      doc_sub_type = getTagValue("doc_sub_type", eElement);
					      cust_cif_number = getTagValue("cust_cif_number", eElement);
					      cust_name = getTagValue("cust_name", eElement);
					      
					      //calling getDocProps method
					      String docProps = getDocProps();
					      docPropsString.add(docProps);
				      }
				      else{
				    	  outputStrXml = "Missing Mandatory Values from client to Update Document(s).";
				      }
			      }
			   }
			   
			}
			
			//setters
			setDeleteDocIds(deleteDocIds);
			setDocPropsString(docPropsString);
			   
		} catch (Exception e) {
			
			outputStrXml = e.getMessage();
			LOGGER.error("Error Code (US02) : ", e.fillInStackTrace());
		}
		
		return outputStrXml;
	}
	
	private String getTagValue(String sTag, Element eElement) {
		  
		String tagValue = null;
		
		try {
			NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
 
			    Node nValue = (Node) nlList.item(0); 
			    
			    if(nValue!=null){
			    	tagValue = nValue.getNodeValue();
			    }
			    else{
			    	tagValue = "";
			    }
			    
		} catch (Exception e) {
			
			LOGGER.error("Error Code (US03) : ", e.fillInStackTrace());
		}
	 
		return tagValue;
	  }
	
	/** 
	 * Method Description: This method is used to construct the condition string based on 
	 * 					   the search filter values from client. 
	 * 	 
	 * @return String    : Constructed Condition String based on search filter values.
	 */	
	@SuppressWarnings("unused")
	private String getDocProps(){
		
		String docProps = null;
		
		try {
			//search filters condition string
			if(!branch_number.equalsIgnoreCase("")){
			 
			 if(docProps!=null){    						 
				 
					docProps = docProps + " SET branch_number " + " = '" + branch_number + "'";    						
				    
				}else{   		    				
					docProps = " SET branch_number" + " = '" + branch_number + "'";        						    				
				}
			}
			
			if(!cust_type.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET cust_type" + " = '" + cust_type + "'";    						
					    
					}else{   		    				
						docProps = " SET cust_type" + " = '" + cust_type + "'";        						    				
					}
			}
			
			if(!cust_id_number.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET cust_id_number" + " = '" + cust_id_number + "'";    						
					    
					}else{   		    				
						docProps = " SET cust_id_number" + " = '" + cust_id_number + "'";        						    				
					}
			}
			
			if(!cust_id_type.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET cust_id_type" + " = '" + cust_id_type + "'";    						
					    
					}else{   		    				
						docProps = " SET cust_id_type" + " = '" + cust_id_type + "'";        						    				
					}
			}
			
			if(!car_year_created.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET car_year_created" + " = '" + car_year_created + "'";    						
					    
					}else{   		    				
						docProps = " SET car_year_created" + " = '" + car_year_created + "'";        						    				
					}
			}
			
			if(!facility_number.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET facility_number" + " = '" + facility_number + "'";    						
					    
					}else{   		    				
						docProps = " SET facility_number" + " = '" + facility_number + "'";        						    				
					}
			}
			
			if(!collateral_number.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET collateral_number" + " = '" + collateral_number + "'";    						
					    
					}else{   		    				
						docProps = " SET collateral_number" + " = '" + collateral_number + "'";        						    				
					}
			}
			
			if(!doc_sub_type.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET doc_sub_type" + " = '" + doc_sub_type + "'";    						
					    
					}else{   		    				
						docProps = " SET doc_sub_type" + " = '" + doc_sub_type + "'";        						    				
					}
			}
			
			if(!cust_cif_number.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET cust_cif_number" + " = '" + cust_cif_number + "'";    						
					    
					}else{   		    				
						docProps = " SET cust_cif_number" + " = '" + cust_cif_number + "'";        						    				
					}
			}
			
			if(!cust_name.equalsIgnoreCase("")){
				 
				 if(docProps!=null){    						 
					 
						docProps = docProps + " SET cust_name" + " = '" + cust_name + "'";    						
					    
					}else{   		    				
						docProps = " SET cust_name" + " = '" + cust_name + "'";        						    				
					}
			}			
			
		} catch (Exception e) {			
			LOGGER.error("Error Code (US04) : ", e.fillInStackTrace());
		}
		
		return docProps;
	}
	
 
}
