/**
* ______________________________________________________________________________
*
* File: UpdateService.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Nov 16, 2012   11:31:25 AM   2012 
* Description: This class is the main class (Service Class) and will perform 
* 			   following things:
* 				1. Retrieves all the required info from the input String XML 
* 				   using ReadUSStringXML Class.
*               2. Updates meta data of the documents present in ECM repository
*                  based on the data (document properties) using UpdateDocs
*                  Class.
*               3. Writes all the collected info into a String XML using 
*                  WriteUSStringXML Class.
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.los.update;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.fc.common.DfLogger;
import com.emc.documentum.fs.rt.annotations.DfsPojoService;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Mar 18, 2012
 * @Last Modification Time   11:31:25 AM
 * @Last Modification Year   2012 
 */

@DfsPojoService(targetNamespace = "http://update.los.services.ecm.vb.com", requiresAuthentication = true)
public class UpdateService {

	// Initialising the logger from org.apache.Log4j
	private Logger LOGGER;     
    
	//Resource Bundle
	private ResourceBundle rsb = null;
	
	//Received Date
	private String reqReceivedDate = null;
	
	//Status
	private String status = null;
	
	//Error Code
	private String errorCode = null;
	
	//Error Message
	private String errorMessage = null;
	
	//Output String XML
	private String outputStrXml = null;	
	
	 /** 
	 * Method Description: This method is used to update meta data (properties) of the documents present in 
	 * 					   ECM based on the data provided by LOS Update Functionality.                    
	 * 
	 * @param String     : inputStringXML contains all the required information (data) to update document(s).
	 *                     
	 * @return String	 : outputStrXml which contains all the collected information in String XML format.
	 */		
	public String updateDocuments(String inputStringXml) throws Exception 
	 {			
		 
	    try {
	    	//logger
	    	LOGGER = DfLogger.getLogger(UpdateService.class);
	    	LOGGER.debug("LOS Update Service Request Started..");
	    	
	    	//resource bundle
	    	rsb = ResourceBundle.getBundle("com.vb.ecm.services.los.LOSConfig");
	    	 
	    	//request received date			
		    SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    reqReceivedDate = sdf.format(new Date());		    
			
			//read input values from string xml
			ReadUSStringXML inputStrXmlObj = new ReadUSStringXML();
			outputStrXml = inputStrXmlObj.processInputData(LOGGER, rsb, inputStringXml, reqReceivedDate, 
					status, errorCode, errorMessage);
			
			if(outputStrXml.equals("success")){
			
			//updating documents properties			
			if(!inputStrXmlObj.getUserId().equalsIgnoreCase("") && 
				  inputStrXmlObj.getMessageType().equals(rsb.getString("UPDATE_MESSAGE_TYPE")) && 
					inputStrXmlObj.getAppId().equals(rsb.getString("SOURCE_APP_ID")) && 
					  (inputStrXmlObj.getDeleteDocIds().size() > 0) && 
					     !inputStrXmlObj.getReqtimeStamp().equalsIgnoreCase("")){				
				
				UpdateDocs updateDocsObj = new UpdateDocs();
				String successMsg = updateDocsObj.updateDocuments(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
						errorCode, errorMessage, inputStrXmlObj.getDeleteDocIds(), inputStrXmlObj.getDocPropsString());
				
				//clear the array lists
				inputStrXmlObj.getDeleteDocIds().clear();	
				inputStrXmlObj.getDocPropsString().clear();
				
				if(successMsg.contains("Session Not Created.")){
					
					status = "1";
	    		    errorCode = "US06";
	    		    errorMessage = "Session Not Created.";
					WriteUSStringXML outputStrXmlObj = new WriteUSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}
				else if(successMsg.contains("Document(s) Doesn't Exist in ECM to Update.")){
					
					status = "1";
		        	errorCode = "US10";
		        	errorMessage = "Document(s) Doesn't Exist in ECM to Update.";
					WriteUSStringXML outputStrXmlObj = new WriteUSStringXML();
					outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
								errorCode, errorMessage);
				}
				else if(!successMsg.contains("Error :")){
					
					status = "0";
			        errorCode = "";
			        errorMessage = "";
					//write output values to string xml					
				    WriteUSStringXML outputStrXmlObj = new WriteUSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}
				else{
					status = "1";
					errorCode = "US05";
					errorMessage = successMsg;
				    WriteUSStringXML outputStrXmlObj = new WriteUSStringXML();
				    outputStrXml = outputStrXmlObj.createXML(LOGGER, rsb, inputStrXmlObj, reqReceivedDate, status, 
							errorCode, errorMessage);
				}
				
			}
			else{
				status = "1";
				errorCode = "US01";
				errorMessage = "Missing Mandatory Values from Client to Update Document(s).";
				WriteUSStringXML outputStrXmlObj = new WriteUSStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
				LOGGER.debug("Missing Mandatory Values from client to Update Document(s).");
				}
			}
			else{
				status = "1";
				errorCode = "US02";
				errorMessage = outputStrXml;
				WriteUSStringXML outputStrXmlObj = new WriteUSStringXML();
				outputStrXml = outputStrXmlObj.createExceptionXML(LOGGER, rsb, reqReceivedDate, status, 
						errorCode, errorMessage);
			}
	 		
		} catch (Exception e) {
			
			LOGGER.error("Error Code (US01) : ", e.fillInStackTrace());
			LOGGER.error("LOS Update Service Request Completed with Errors.");
		}	          
	     
		 return outputStrXml;
	 }	
	

}
