/**
* ______________________________________________________________________________
*
* File: UpdateServiceClient.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 13, 2012   5:39:11 PM   2012
* Description: Update Service Client
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.client.icdoc;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.vb.ecm.services.icdoc.update.ws.UpdateServiceLocator;
import com.vb.ecm.services.icdoc.update.ws.UpdateServicePort;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 13, 2012
 * @Last Modification Time   5:39:11 PM
 * @Last Modification Year   2012 
 */
public class UpdateServiceClient
{    
    private static String user = "devuser1";
    private static String password = "devuser1";
    private static String repository = "ECM_REPO_DEV";   
    	
    public static void main(String[] args)
    {
    	        
        try
        {  
        	UpdateServiceClient updateSrvObj = new UpdateServiceClient();        	
        	Element identityElement = updateSrvObj.buildServiceContextWithIdentity(repository, user, password);       	
        	updateSrvObj.callSchemaService(identityElement);        	
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }    
    
    private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private void callSchemaService(Element identityElement)
    {
		try
		{			
			UpdateServiceLocator srvLoc = new 
					UpdateServiceLocator("http://10.6.129.174:9080/services/icdoc/UpdateService?wsdl", 
					new QName("http://ws.update.icdoc.services.ecm.vb.com/", "UpdateService"));
			
			UpdateServicePort srvPort = 
					srvLoc.getUpdateServicePort(new 
							URL("http://10.6.129.174:9080/services/icdoc/UpdateService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service	
			//First Row contains all the Attribute Names - object_type & condition attribute columns are mandatory and in same order
			//From Second row onwards attribute values - if there are 5 attribute columns are there then there should be 
			//5 attribute values in each row
					
			String docProps[][] = {
					{"object_type","r_object_id","branch_number","creator_name","number_sign"},
					{"vb_icdoc_docs","0901e24080071ea8","001","John","160-GHTD-2012-171"},
					{"vb_icdoc_docs","0901e24080071ec4","002","Eric","160-GHTD-2012-172"}							    
		        };
			
			String statusMsg = srvPort.updateDocuments(docProps);	
        	System.out.println("Status : " + statusMsg);
        	
        	//For updating multiple records -- query string should be always in lower case
    		/*String queryString = "update vb_icdoc_docs object set creator_name='Mr.Duc' where branch_number='001'";
    		statusMsg = srvPort.updateMultipleDocs(queryString);
    		System.out.println("Status : " + statusMsg);*/
			
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
    }
    
    
}
