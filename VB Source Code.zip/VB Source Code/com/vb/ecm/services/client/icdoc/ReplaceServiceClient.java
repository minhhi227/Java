/**
* ______________________________________________________________________________
*
* File: ReplaceServiceClient.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 21, 2012   7:44:35 AM   2012
* Description: Replace Service Client
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.client.icdoc;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.vb.ecm.services.icdoc.replace.ws.ReplaceServiceLocator;
import com.vb.ecm.services.icdoc.replace.ws.ReplaceServicePort;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 21, 2012
 * @Last Modification Time   7:44:35 AM
 * @Last Modification Year   2012 
 */

public class ReplaceServiceClient {	
	
	private static String user = "devuser1";
    private static String password = "devuser1";
    private static String repository = "ECM_REPO_DEV";   
    	
    public static void main(String[] args)
    {
    	        
        try
        {  
        	ReplaceServiceClient replaceSrvObj = new ReplaceServiceClient();        	
        	Element identityElement = replaceSrvObj.buildServiceContextWithIdentity(repository, user, password);       	
        	replaceSrvObj.callSchemaService(identityElement);        	
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }    
    
    private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private void callSchemaService(Element identityElement)
    {
		try
		{			
			ReplaceServiceLocator srvLoc = new 
					ReplaceServiceLocator("http://10.6.129.174:9080/services/icdoc/ReplaceService?wsdl", 
					new QName("http://ws.replace.icdoc.services.ecm.vb.com/", "ReplaceService"));
			
			ReplaceServicePort srvPort = 
					srvLoc.getReplaceServicePort(new 
							URL("http://10.6.129.174:9080/services/icdoc/ReplaceService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service		
			String docProps[][] = {										
			    };
			
			//reading file
			byte[] newDocContent = null;
			File file = new File("C:\\Data\\2780.pdf");
			FileInputStream fin = new FileInputStream(file);
			newDocContent = new byte[(int)file.length()];			
			
			fin.read(newDocContent);
			fin.close();			
			
			/*String str = srvPort.replaceDocument("0901e2408007b1e0", newDocContent, "pdf", docProps);
			System.out.println("Document Replaced and it's new Id is : " + str);*/
			
			String str = srvPort.versionDocument("0901e240800870a8", newDocContent, "pdf", docProps);
			System.out.println(str);
			
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
    }

}
