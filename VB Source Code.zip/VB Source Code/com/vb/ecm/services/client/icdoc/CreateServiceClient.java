/**
* ______________________________________________________________________________
*
* File: CreateServiceClient.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 19, 2012   5:39:11 PM   2012
* Description: Create Service Client
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/
package com.vb.ecm.services.client.icdoc;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.vb.ecm.services.icdoc.create.ws.CreateServiceLocator;
import com.vb.ecm.services.icdoc.create.ws.CreateServicePort;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 19, 2012
 * @Last Modification Time   5:39:11 PM
 * @Last Modification Year   2012 
 */
public class CreateServiceClient
{    
    private static String user = "devuser1";
    private static String password = "devuser1";
    private static String repository = "ECM_REPO_DEV";   
    	
    public static void main(String[] args)
    {
    	        
        try
        {  
        	CreateServiceClient createSrvObj = new CreateServiceClient();        	
        	Element identityElement = createSrvObj.buildServiceContextWithIdentity(repository, user, password);       	
        	createSrvObj.callSchemaService(identityElement);        	
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }    
    
    private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private void callSchemaService(Element identityElement)
    {
		try
		{			
			CreateServiceLocator srvLoc = new 
					CreateServiceLocator("http://10.6.129.174:9080/services/icdoc/CreateService?wsdl", 
					new QName("http://ws.create.icdoc.services.ecm.vb.com/", "CreateService"));
			
			CreateServicePort srvPort = 
					srvLoc.getCreateServicePort(new 
							URL("http://10.6.129.174:9080/services/icdoc/CreateService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));			
				
			//Call the service		
			//Call the service		
			String docProps[][] = {
					{"object_name","Pdf file3"},//mandatory values up to here				
					{"doc_subject", "iCDoc Document"},
					{"creator_name", "Mr.Duc"}
			    };
			
			String custProps[][] = {
					{"branch_number","160"},
					{"number_sign","160-GHTD-2012-754"},//mandatory values up to here
					{"code", "11223344"},					
					{"dep_name", "Phòng Khách hàng Cá nhân"}
			    };
			
			//reading file
			byte[] docContent = null;
			File file = new File("C:\\Data\\2780.pdf");
			FileInputStream fin = new FileInputStream(file);
			docContent = new byte[(int)file.length()];			
			
			fin.read(docContent);
			fin.close();			
			
			//valid formats like pdf(pdf files), text (txt files), msw8(ms word files), 
			//tiff(tiff images) & excel12book(office 2007 excel files)			
			String str = srvPort.createDocument(docContent, "pdf", docProps, custProps);
			System.out.println("Document Created and it's Id is : " + str);
			
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
    }
    
    
}
