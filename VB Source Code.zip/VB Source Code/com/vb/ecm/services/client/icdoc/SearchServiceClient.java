/**
* ______________________________________________________________________________
*
* File: SearchServiceClient.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 21, 2012   1:53:38 PM   2012
* Description: Search Service Client
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.client.icdoc;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.vb.ecm.services.icdoc.search.ws.SearchServiceLocator;
import com.vb.ecm.services.icdoc.search.ws.SearchServicePort;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 21, 2012
 * @Last Modification Time   1:53:38 PM
 * @Last Modification Year   2012
 */
public class SearchServiceClient {	
	
	private static String user = "devuser1";
    private static String password = "devuser1";
    private static String repository = "ECM_REPO_DEV";   
    	
    public static void main(String[] args)
    {
    	        
        try
        {  
        	SearchServiceClient searchSrvObj = new SearchServiceClient();        	
        	Element identityElement = searchSrvObj.buildServiceContextWithIdentity(repository, user, password);       	
        	searchSrvObj.callSchemaService(identityElement);            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }    
    
    private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private void callSchemaService(Element identityElement)
    {
		try
		{			
			SearchServiceLocator srvLoc = new 
					SearchServiceLocator("http://10.6.129.174:9080/services/icdoc/SearchService?wsdl", 
					new QName("http://ws.search.icdoc.services.ecm.vb.com/", "SearchService"));
			
			SearchServicePort srvPort = 
					srvLoc.getSearchServicePort(new 
							URL("http://10.6.129.174:9080/services/icdoc/SearchService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service		
			String queryString = "select * from vb_icdoc_docs where r_object_id='0901e24080071ec4'";			
			
			String[][] results = srvPort.getListOfDocsMetadata(queryString);
			
			//print output
			for (int i = 0; i < results.length; i++) {
			    for (int j = 0; j < results[0].length; j++) {
			        System.out.println("Results : " + results[i][j]);
			    }
			}
			
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
    }

}
