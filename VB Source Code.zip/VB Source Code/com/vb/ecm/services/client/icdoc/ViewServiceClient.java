/**
* ______________________________________________________________________________
*
* File: ViewServiceClient.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Sep 24, 2012   7:39:49 AM   2012
* Description: View Service Client
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.client.icdoc;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.vb.ecm.services.icdoc.view.ws.ViewServiceLocator;
import com.vb.ecm.services.icdoc.view.ws.ViewServicePort;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Sep 24, 2012
 * @Last Modification Time   7:39:49 AM
 * @Last Modification Year   2012
 */

public class ViewServiceClient {	
	  
    private static String user = "devuser1";
    private static String password = "devuser1";
    private static String repository = "ECM_REPO_DEV";    
       	
    public static void main(String[] args)
    {
    	        
        try
        {  
        	ViewServiceClient viewSrvObj = new ViewServiceClient();        	
        	Element identityElement = viewSrvObj.buildServiceContextWithIdentity(repository, user, password);       	
        	viewSrvObj.callSchemaService(identityElement);        	
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }    
    
    private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private void callSchemaService(Element identityElement)
    {
		try
		{			
			ViewServiceLocator srvLoc = new 
					ViewServiceLocator("http://10.6.129.174:9080/services/icdoc/ViewService?wsdl", 
					new QName("http://ws.view.icdoc.services.ecm.vb.com/", "ViewService"));
			
			ViewServicePort srvPort = 
					srvLoc.getViewServicePort(new 
							URL("http://10.6.129.174:9080/services/icdoc/ViewService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service					
			Object[] arrayObjects = srvPort.getDocumentContent("0901e24080071ea8");			
			
			String fileFormat = (String)arrayObjects[0];
			System.out.println("File Format is : " + fileFormat);
			
			if(!fileFormat.contains("Error :") && !fileFormat.equalsIgnoreCase("Document Doesn't Exist!!!")){
			
				byte[] fileContent = (byte[])arrayObjects[1];			
				//writing content to file
				File file = new File("C:\\Data\\ECM Doc1" + "." + fileFormat);
				FileOutputStream fop = new FileOutputStream(file);
				
				// if file doesn't exists, then create it
				if (!file.exists()) {
					file.createNewFile();
				}
				
				fop.write(fileContent);
				fop.flush();
				fop.close();
	
				System.out.println("File Downloaded Successfully from ECM.");
			}
			
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
    }

}
