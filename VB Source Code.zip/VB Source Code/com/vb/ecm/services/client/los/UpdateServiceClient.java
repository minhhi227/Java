/**
* ______________________________________________________________________________
*
* File: UpdateServiceClient.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Dec 6, 2012   5:39:11 PM   2012
* Description: Update Service Client
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.client.los;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.vb.ecm.services.los.update.ws.UpdateServiceLocator;
import com.vb.ecm.services.los.update.ws.UpdateServicePort;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Dec 6, 2012
 * @Last Modification Time   5:39:11 PM
 * @Last Modification Year   2012 
 */

public class UpdateServiceClient
{    
    private static String user = "losuser";
    private static String password = "losuser";
    private static String repository = "ECM_REPO_DEV";   
    	
    public static void main(String[] args)
    {
    	        
        try
        {  
        	UpdateServiceClient updateSrvObj = new UpdateServiceClient();        	
        	Element identityElement = updateSrvObj.buildServiceContextWithIdentity(repository, user, password);       	
        	updateSrvObj.callSchemaService(identityElement);        	
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }    
    
    private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private void callSchemaService(Element identityElement)
    {
		try
		{			
			UpdateServiceLocator srvLoc = new 
					UpdateServiceLocator("http://10.6.129.174:9080/services/los/UpdateService?wsdl", 
					new QName("http://ws.update.los.services.ecm.vb.com/", "UpdateService"));
			
			UpdateServicePort srvPort = 
					srvLoc.getUpdateServicePort(new 
							URL("http://10.6.129.174:9080/services/los/UpdateService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service	
			String inputStringXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><message><header><user_id>RM1</user_id>" +
					"<message_type>UpdateDocuments</message_type><source_app_id>LOS</source_app_id>" +
					"<request_timestamp>09-11-2012 09:07:00 AM</request_timestamp></header><body><message_request>" +
					"<Documents><Document><document_id>0901e24080074fd0</document_id><branch_number>001</branch_number>" +
					"<cust_type>Enterprise</cust_type><cust_id_number>XX12345678</cust_id_number>" +
					"<cust_id_type>01</cust_id_type><car_year_created>2012</car_year_created>" +
					"<facility_number>2005000000001</facility_number><collateral_number>20070510000290</collateral_number>" +
					"<doc_sub_type>Collateral</doc_sub_type><cust_name>John K</cust_name>" +
					"<cust_cif_number>123456</cust_cif_number></Document></Documents></message_request></body></message>";
			
			String outputStringXml = srvPort.updateDocuments(inputStringXml);
	    	System.out.println(outputStringXml);
			
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
    }
    
    
}
