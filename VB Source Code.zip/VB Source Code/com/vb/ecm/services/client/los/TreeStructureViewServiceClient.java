/**
* ______________________________________________________________________________
*
* File: TreeStructureViewServiceClient.java
*______________________________________________________________________________
*
* CreatedBy: Venkat Banala
* CreationDate: Dec 6, 2012   5:39:11 PM   2012
* Description: Tree Structure View Service Client
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/

package com.vb.ecm.services.client.los;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.vb.ecm.services.los.treestructureview.ws.TreeStructureViewServiceLocator;
import com.vb.ecm.services.los.treestructureview.ws.TreeStructureViewServicePort;

/**
 * @Last Modify Author       Venkat Banala
 * @Last Modification Date   Dec 6, 2012
 * @Last Modification Time   5:39:11 PM
 * @Last Modification Year   2012 
 */

public class TreeStructureViewServiceClient
{    
    private static String user = "losuser";
    private static String password = "losuser";
    private static String repository = "ECM_REPO_DEV";   
    	
    public static void main(String[] args)
    {
    	        
        try
        {
        	
        	TreeStructureViewServiceClient tsvSrvObj = new TreeStructureViewServiceClient();        	
        	Element identityElement = tsvSrvObj.buildServiceContextWithIdentity(repository, user, password);       	
        	tsvSrvObj.callSchemaService(identityElement);        	
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }    
    
    private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private void callSchemaService(Element identityElement)
    {
		try
		{			
			TreeStructureViewServiceLocator srvLoc = new 
					TreeStructureViewServiceLocator("http://10.6.129.174:9080/services/los/TreeStructureViewService?wsdl", 
					new QName("http://ws.treestructureview.los.services.ecm.vb.com/", "TreeStructureViewService"));
			
			TreeStructureViewServicePort srvPort = 
					srvLoc.getTreeStructureViewServicePort(new 
							URL("http://10.6.129.174:9080/services/los/TreeStructureViewService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service
			
			//Link Service input	
			String inputStringXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><message><header><user_id>RM1</user_id>" +
					"<message_type>TreeStructureView</message_type><source_app_id>LOS</source_app_id>" +
					"<request_timestamp>09-11-2012 09:07:00 AM</request_timestamp></header><body><message_request>" +
					"<cust_id_number>XX12345678</cust_id_number><cust_id_type>01</cust_id_type></message_request></body>" +
					"</message>";	
			
			String outputStringXml = srvPort.getTreeStructureView(inputStringXml);
	    	System.out.println(outputStringXml);
			
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
    }
    
    
}
