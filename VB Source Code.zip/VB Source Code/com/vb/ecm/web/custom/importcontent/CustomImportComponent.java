package com.vb.ecm.web.custom.importcontent;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfType;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.contentxfer.IServiceProcessor;
import com.documentum.web.contentxfer.impl.ImportProcessor;
import com.documentum.web.failover.TransientObjectWrapper;
import com.documentum.web.form.*;
import com.documentum.web.form.control.*;
import com.documentum.web.form.control.databound.*;
import com.documentum.web.formext.config.*;
import com.documentum.web.formext.control.docbase.*;
import com.documentum.web.formext.docbase.FormatService;
import com.documentum.web.formext.docbase.TypeUtil;
import com.documentum.web.preset.Entry;
import com.documentum.web.preset.TypeSelector;
import com.documentum.web.util.DocbaseObjectAttributeReader;
import com.documentum.web.util.XmlUtil;
import com.documentum.webcomponent.library.contenttransfer.importcontent.ImportContent;
import com.documentum.webcomponent.library.contentxfer.UploadUtil;
import java.io.File;
import java.io.InputStream;
import java.io.Reader;
import java.sql.*;
import java.util.*;

import javax.servlet.ServletRequest;
import org.apache.log4j.Logger;

public class CustomImportComponent extends ImportContent {

	private static final Logger LOGGER = Logger.getLogger(CustomImportComponent.class);

	private class CachedResultSet extends ScrollableResultSet implements Cloneable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private List m_lisData;
		private int m_iRow;
		private ResultSetMetaData m_metaData;
		private String e;

		@Override
		public Object clone() {
			CachedResultSet result;
			try {
				result = (CachedResultSet) super.clone();
				result.setCursor(-1);
			} catch (CloneNotSupportedException e) {
				throw new WrapperRuntimeException(e);
			}
			return result;
		}

		@Override
		public void setCursor(int pos) {
			int size = m_lisData.size();
			m_iRow = pos >= size ? size : pos;
		}

		@Override
		public int getResultsCount() {
			return m_lisData.size();
		}

		@Override
		public Object getObject(int columnIndex) {
			Object objItem = null;
			if (m_lisData.size() - 1 >= m_iRow) {
				Object objData = m_lisData.get(m_iRow);
				objItem = ((Object[]) objData)[columnIndex - 1];
			}
			return objItem;
		}

		@Override
		public boolean next() {
			m_iRow++;
			return m_iRow < m_lisData.size();
		}

		@Override
		public int findColumn(String columnName) {
			int retValue;
			retValue = -1;
			int len = 0;
			try {
				len = m_metaData.getColumnCount();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			int i = 0;
			do {
				if (i >= len) {
					break;
				}
				try {
					if (columnName.equals(m_metaData.getColumnName(i + 1))) {
						retValue = i;
						break;
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				i++;
			} while (true);
			if (retValue == -1) {
				throw new WrapperRuntimeException("Specified column does not exist: " + columnName);
			}
			return retValue;
		}

		@Override
		public void sort(String s, int i, int j) {
		}

		@Override
		public void close() {
		}

		private void initFromResultSet(ScrollableResultSet resultSet) {
			int rowPosition = 0;
			try {
				int columnCount = super.getMetaData().getColumnCount();
				Object objArray[];
				for (; resultSet.next(); m_lisData.add(((objArray)))) {
					rowPosition++;
					objArray = new Object[columnCount];
					for (int i = 0; i < columnCount; i++) {
						Object obj = resultSet.getObject(i + 1);
						objArray[i] = obj;
					}

				}

			} catch (SQLException e) {
				throw new WrapperRuntimeException(e);
			}
		}

		public CachedResultSet(ScrollableResultSet resultSet) {
			super(CustomImportComponent.buildColumnArray(resultSet));
			m_iRow = -1;
			m_metaData = super.getMetaData();

			m_lisData = new ArrayList(resultSet.getResultsCount());
			initFromResultSet(resultSet);
			resultSet.setCursor(-1);
		}

		@Override
		public int getHoldability() throws SQLException {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public Reader getNCharacterStream(int arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Reader getNCharacterStream(String arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public NClob getNClob(int arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public NClob getNClob(String arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String getNString(int arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String getNString(String arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		/*
		 * public Object getObject(int arg0, Map<String, Class<?>> arg1) throws
		 * SQLException { // TODO Auto-generated method stub return null; }
		 * 
		 * public Object getObject(String arg0, Map<String, Class<?>> arg1)
		 * throws SQLException { // TODO Auto-generated method stub return null;
		 * }
		 */
		@Override
		public RowId getRowId(int arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public RowId getRowId(String arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public SQLXML getSQLXML(int arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public SQLXML getSQLXML(String arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean isClosed() throws SQLException {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void updateAsciiStream(int arg0, InputStream arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateAsciiStream(String arg0, InputStream arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateAsciiStream(int arg0, InputStream arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateAsciiStream(String arg0, InputStream arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateBinaryStream(int arg0, InputStream arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateBinaryStream(String arg0, InputStream arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateBinaryStream(int arg0, InputStream arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateBinaryStream(String arg0, InputStream arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateBlob(int arg0, InputStream arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateBlob(String arg0, InputStream arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateBlob(int arg0, InputStream arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateBlob(String arg0, InputStream arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateCharacterStream(int arg0, Reader arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateCharacterStream(String arg0, Reader arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateCharacterStream(int arg0, Reader arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateCharacterStream(String arg0, Reader arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateClob(int arg0, Reader arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateClob(String arg0, Reader arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateClob(int arg0, Reader arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateClob(String arg0, Reader arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNCharacterStream(int arg0, Reader arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNCharacterStream(String arg0, Reader arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNCharacterStream(int arg0, Reader arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNCharacterStream(String arg0, Reader arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNClob(int arg0, NClob arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNClob(String arg0, NClob arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNClob(int arg0, Reader arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNClob(String arg0, Reader arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNClob(int arg0, Reader arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNClob(String arg0, Reader arg1, long arg2) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNString(int arg0, String arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateNString(String arg0, String arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateRowId(int arg0, RowId arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateRowId(String arg0, RowId arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateSQLXML(int arg0, SQLXML arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public void updateSQLXML(String arg0, SQLXML arg1) throws SQLException {
			// TODO Auto-generated method stub

		}

		@Override
		public boolean isWrapperFor(Class<?> arg0) throws SQLException {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public <T> T unwrap(Class<T> arg0) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}
	}

	private class TypedObjectDefaultValues implements ITypedObjectDefaultValues {

		@Override
		public int getValueCount(String attrName) {
			LOGGER.debug("attrName:" + attrName);
			LOGGER.debug("m_attributes:" + m_attributes);
			if (m_attributes != null) {
				List attrValue = (List) m_attributes.get(attrName);
				for (int i = 0; i <= attrValue.size(); i++)
					LOGGER.debug("attrValue:" + attrValue.get(i));
				if (attrValue == null) {
					LOGGER.debug("attrValue null");
					return 0;
				} else {
					return attrValue.size();
				}
			} else {
				return 0;
			}
		}

		@Override
		public String getRepeatingValue(String attrName, int valueIndex) {
			if (m_attributes != null) {
				List attrValue = (List) m_attributes.get(attrName);
				LOGGER.debug("attr Values:" + attrValue.get(0));
				if (attrValue == null) {
					return null;
				} else {
					LOGGER.debug("(String)attrValue.get(valueIndex)==" + (String) attrValue.get(valueIndex));
					return (String) attrValue.get(valueIndex);
				}
			} else {
				return null;
			}
		}

		private TypedObjectDefaultValues() {
		}

	}

	private static final String UNKNOWN_FORMAT = "unknown";
	protected static final String EVENT_ONSYNCTYPE = "onsynctype";
	private static final String HANDLER_ONSYNCTYPE = "onSyncType";
	private String folderId;
	private String m_filePath;
	private String m_parentPath;
	private String m_localFilePath;
	private String m_objectName;
	private String m_docbaseType;
	private boolean m_directory;
	private String m_baseDocbaseType;
	private String m_format;
	private Map m_attributes;
	private ArgumentList m_attributesArgs;
	private String transactionId;

	/*
	 * public String getObject_name() { return object_name; }
	 * 
	 * public void setObject_name(String object_name) { this.object_name =
	 * object_name; }
	 */
	public String getDoc_upload_status() {
		return doc_upload_status;
	}

	public void setDoc_upload_status(String doc_upload_status) {
		this.doc_upload_status = doc_upload_status;
	}

	public String getDoc_sub_type() {
		return doc_sub_type;
	}

	public void setDoc_sub_type(String doc_sub_type) {
		this.doc_sub_type = doc_sub_type;
	}

	public String getBranch_number() {
		return branch_number;
	}

	public void setBranch_number(String branch_number) {
		this.branch_number = branch_number;
	}

	/*
	 * public String getCust_email() { return cust_email; }
	 * 
	 * public void setCust_email(String cust_email) { this.cust_email =
	 * cust_email; }
	 */
	public String getCust_id_number() {
		return cust_id_number;
	}

	public void setCust_id_number(String cust_id_number) {
		this.cust_id_number = cust_id_number;
	}

	public String getCust_type() {
		return cust_type;
	}

	public void setCust_type(String cust_type) {
		this.cust_type = cust_type;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	/*
	 * public String getRm_name() { return rm_name; }
	 * 
	 * public void setRm_name(String rm_name) { this.rm_name = rm_name; }
	 * 
	 * public String getRm_id() { return rm_id; }
	 * 
	 * public void setRm_id(String rm_id) { this.rm_id = rm_id; }
	 */

	public String getCollateral_id() {
		return collateral_id;
	}

	public void setCollateral_id(String collateral_id) {
		this.collateral_id = collateral_id;
	}

	/*
	 * public String getTransaction_user() { return transaction_user; }
	 * 
	 * public void setTransaction_user(String transaction_user) {
	 * this.transaction_user = transaction_user; }
	 * 
	 * public String getCust_phone() { return cust_phone; }
	 * 
	 * public void setCust_phone(String cust_phone) { this.cust_phone =
	 * cust_phone; }
	 */

	public String getCust_cif_number() {
		return cust_cif_number;
	}

	public void setCust_cif_number(String cust_cif_number) {
		this.cust_cif_number = cust_cif_number;
	}

	public String getCust_id_type() {
		return cust_id_type;
	}

	public void setCust_id_type(String cust_id_type) {
		this.cust_id_type = cust_id_type;
	}

	/*
	 * public String getCar_number() { return car_number; }
	 * 
	 * public void setCar_number(String car_number) { this.car_number =
	 * car_number; }
	 */
	public String getFacility_number() {
		return facility_number;
	}

	public void setFacility_number(String facility_number) {
		this.facility_number = facility_number;
	}

	public String getR_folder_path() {
		return r_folder_path;
	}

	public void setR_folder_path(String r_folder_path) {
		this.r_folder_path = r_folder_path;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	// private String object_name;

	private String owner_name;

	private String doc_upload_status;

	private String doc_sub_type;

	private String branch_number;

	// private String cust_email;

	private String cust_id_number;

	private String cust_type;

	private String cust_name;

	// private String rm_name;

	// private String rm_id;

	private String collateral_id;

	// private String transaction_user;

	// private String cust_phone;

	private String cust_cif_number;

	private String cust_id_type;

	// private String car_number;

	private String facility_number;

	public String getUpload_by() {
		return upload_by;
	}

	public void setUpload_by(String upload_by) {
		this.upload_by = upload_by;
	}

	public String getCar_year_created() {
		return car_year_created;
	}

	public void setCar_year_created(String car_year_created) {
		this.car_year_created = car_year_created;
	}

	private String upload_by;
	private String car_year_created;

	private String r_folder_path;

	private String successMessage;
	private static final String FORMATS_RESULTSET_REQ_CACHE;
	private static final String TYPES_RESULTSET_REQ_CACHE;

	// Label lshowLabel = null;
	public CustomImportComponent() {
		m_objectName = null;
		m_directory = false;
		m_format = null;
	}

	@Override
	public void onInit(ArgumentList arg) {
		super.onInit(arg);
		LOGGER.debug("Enter into onInit of CustomImportComponent");
		LOGGER.debug("Tran ID in Custom import component:" + arg.get("trans_id"));
		// lblshowvalidation = (Label)getControl("showValidation",Label.class);
		setFolderId(arg.get("objectId"));
		setFilePath(arg.get("filenameWithPath"));		
		setTransactionId(arg.get("trans_id"));
		LOGGER.debug("Object Name:" + arg.get("object_name"));
		// setObject_name(arg.get("object_name"));

		setDoc_upload_status(arg.get("doc_upload_status"));
		setDoc_sub_type(arg.get("doc_sub_type"));
		setBranch_number(arg.get("branch_number"));
		// setCust_email(arg.get("cust_email"));
		setCust_type(arg.get("cust_type"));
		setCust_name(arg.get("cust_name"));
		// setRm_name(arg.get("rm_name"));
		// setRm_id(arg.get("rm_id"));
		setCollateral_id(arg.get("collateral_id"));
		// setCust_phone(arg.get("cust_phone"));
		setCust_cif_number(arg.get("cust_cif_number"));
		setCust_id_number(arg.get("cust_id_number"));
		setUpload_by(arg.get("upload_by"));
		setCar_year_created(arg.get("car_year_created"));
		setCust_id_type(arg.get("cust_id_type"));
		// setCar_number(arg.get("car_number"));
		setFacility_number(arg.get("facility_number"));
		setR_folder_path(arg.get("r_folder_path"));

		setParentPath(arg.get("parentPath"));
		setObjectName(arg.get("objectName"));
		setDocbaseType(arg.get("docbaseType"));
		setBaseDocbaseType(arg.get("baseDocbaseType"));
		setDirectory(Boolean.valueOf(arg.get("isDirectory")).booleanValue());
		setDefaultFormat(arg.get("format"));
		String strFormat = arg.get("format");

		if (strFormat != null && strFormat.length() > 0) {
			DocbaseIcon icon = (DocbaseIcon) getControl("obj_icon", com.documentum.web.formext.control.docbase.DocbaseIcon.class);
			if (icon != null) {
				icon.setFormat(strFormat);
				icon.setType("vb_los_docs");
			}
		}
		String defaultAttrValues = arg.get("defaultAttributesValues");
		LOGGER.debug("defaultAttrValues:" + defaultAttrValues);
		if (defaultAttrValues != null) {
			setDefaultAttributesValues(ArgumentList.decode(defaultAttrValues));
		}
		String localFilePath = arg.get("localFilePath");
		if (localFilePath != null && localFilePath.length() > 0) {
			File f = new File(localFilePath);
			if (f.exists()) {
				setLocalFilePath(f.getAbsolutePath());
			}
		}
		if (isDirectory()) {
			setComponentPage("folder");
		}
		initContext();
		initControls();
		LOGGER.debug("Exit from onInit() of CustomImportComponent");
	}

	@Override
	protected void setDefaultAttributesValues(ArgumentList attributes) {
		m_attributesArgs = attributes;
		LOGGER.debug("m_attributesArgs:" + m_attributesArgs);

		m_attributes = new HashMap(5);
		String name;
		List values;
		for (Iterator names = attributes.nameIterator(); names.hasNext(); m_attributes.put(name, values)) {
			name = (String) names.next();
			String valuesArray[] = attributes.getValues(name);
			values = Arrays.asList(valuesArray);
			LOGGER.debug("values:" + values.get(1));
		}

	}

	@Override
	protected ArgumentList getDefaultAttributesValues() {
		LOGGER.debug("m_attributesArgs:" + m_attributesArgs);
		return m_attributesArgs;
	}

	@Override
	protected void setDefaultFormat(String format) {
		m_format = format;
	}

	@Override
	protected String getDefaultFormat() {
		return m_format;
	}

	@Override
	protected boolean isPreserveFileExtension() {
		Boolean preserve = lookupBoolean("preserve-file-extension");
		if (preserve != null) {
			return preserve.booleanValue();
		} else {
			return true;
		}
	}

	@Override
	protected void initContext() {
		String type = getDocbaseType();
		if (!typeExists(type)) {
			type = isDirectory() ? getDefaultFolderType() : getDefaultDocumentType();
		}
		getContext().set("type", type);
	}

	@Override
	protected void initControls() {
		initFormatWarningLabelControl();
		initTypeListControl();
		initFormatControl();
		initFilenameLabelControl();
		initSelectedFormat();
		initDocbaseObjectControl();
	}

	@Override
	public IServiceProcessor getServiceProcessor() {
		IServiceProcessor sp = createServiceProcessor();
		if (sp instanceof ImportProcessor) {
			ImportProcessor proc = (ImportProcessor) sp;
			if (getLocalFilePath() != null) {
				proc.setServerFilePath(getLocalFilePath());
			} else {
				proc.setClientFilePath(getFilePathSelection());
			}
			proc.setDirectory(isDirectory());
			proc.setClientParentPath(getParentPathSelection());
			proc.setNewObjectFormat(getFormatSelection());
			proc.setNewObjectName(getObjectNameSelection());
			proc.setNewObjectType(getTypeSelection());
			proc.setNewObjectAttributes(getObjectAttributes());
		}
		return sp;
	}

	@Override
	protected void initFormatWarningLabelControl() {
		getFormatWarningLabelControl(true).setVisible(false);
	}

	@Override
	protected void initDocbaseObjectControl() {
		DocbaseObject docbaseObj = getDocbaseObjectControl(true);
		docbaseObj.setType(getDocbaseType());
		docbaseObj.setPrepopulateValue(new TypedObjectDefaultValues());
	}

	@Override
	protected void initFilenameLabelControl() {
		try {
			String strFilename = getObjectName();

			if (strFilename == null || strFilename.length() <= 0) {
				strFilename = UploadUtil.getFilenameFromPath(getFilePathSelection());
			}
			String strFileName = getObjectNameSelection();
			LOGGER.debug("File Name:" + strFileName);
			Label labelFileNameWithPath = getFilenameLabelControl(true);
			labelFileNameWithPath.setLabel(getFilePathSelection());
			Label checkLabel = getCheckLabelControl(true);
			LOGGER.debug("Check label in import component");
			String checkLabelStr = "Make sure that you created the following details : " + "\n" + "\n Transaction ID            :" + transactionId + "\n";
			if (strFileName != null) {
				checkLabelStr = checkLabelStr + "Object Name        :" + strFileName + "\n";
			}

			if (doc_sub_type != null) {
				checkLabelStr = checkLabelStr + "\t doc_sub_type        :" + doc_sub_type + "\n";
			}

			if (branch_number != null) {
				checkLabelStr = checkLabelStr + "branch_number        :" + branch_number + "\n";
			}

			if (cust_cif_number != null) {
				checkLabelStr = checkLabelStr + "cust_cif_number        :" + cust_cif_number + "\n";
			}

			if (cust_id_number != null) {
				checkLabelStr = checkLabelStr + "Custemer ID No        :" + cust_id_number + "\n";
			}

			/*
			 * if(rm_id!=null){ checkLabelStr
			 * =checkLabelStr+"\t rm_id        :"+rm_id+"\t"; }
			 * 
			 * if(rm_name!=null){ checkLabelStr
			 * =checkLabelStr+"\t rm_name        :"+rm_name+"\t"; }
			 */

			if (cust_name != null) {
				checkLabelStr = checkLabelStr + "cust_name        :" + cust_name + "\n";
			}
			if (cust_type != null) {
				checkLabelStr = checkLabelStr + "cust_type        :" + cust_type + "\n";
			}

			if (cust_id_type != null) {
				checkLabelStr = checkLabelStr + "cust_id_type        :" + cust_id_type + "\n";
			}
			if (cust_id_number != null) {
				checkLabelStr = checkLabelStr + "cust_id_number        :" + cust_id_number + "\n";
			}

			/*
			 * if(car_number!=null){ checkLabelStr
			 * =checkLabelStr+"\n car_number        :"+car_number+"\t\n"; }
			 */
			if (collateral_id != null) {
				checkLabelStr = checkLabelStr + "Collateral Number       :" + collateral_id + "\n";

			}

			if (car_year_created != null) {
				checkLabelStr = checkLabelStr + "CAR Year Created       :" + car_year_created + "\n";

			}

			if (upload_by != null) {
				checkLabelStr = checkLabelStr + "Created By       :" + upload_by + "\n";

			}

			if (facility_number != null) {
				checkLabelStr = checkLabelStr + "\n facility_number        :" + facility_number + "\t\n";
			}

			//checkLabel.setLabel(checkLabelStr);
			Label l = (Label) getControl("check_label1", com.documentum.web.form.control.Label.class);
			//l.setLabel(successMessage);
			
			Text obj_nameT = (Text) getControl("obj_name", com.documentum.web.form.control.Text.class);
			obj_nameT.setValue(strFileName);
			obj_nameT.setEnabled(false);
			Text doc_sub_typeT = (Text) getControl("doc_sub_type", com.documentum.web.form.control.Text.class);
			doc_sub_typeT.setValue(doc_sub_type);
			doc_sub_typeT.setEnabled(false);
			Text branch_numberT = (Text) getControl("branch_number", com.documentum.web.form.control.Text.class);
			branch_numberT.setValue(branch_number);
			branch_numberT.setEnabled(false);
			Text cust_cif_numT = (Text) getControl("cust_cif_num", com.documentum.web.form.control.Text.class);
			cust_cif_numT.setValue(cust_cif_number);
			cust_cif_numT.setEnabled(false);
			Text cust_idT = (Text) getControl("cust_id", com.documentum.web.form.control.Text.class);
			cust_idT.setValue(cust_id_number);
			cust_idT.setEnabled(false);
			Text cust_nameT = (Text) getControl("cust_name", com.documentum.web.form.control.Text.class);
			cust_nameT.setValue(cust_name);
			cust_nameT.setEnabled(false);
			Text cust_typeT = (Text) getControl("cust_type", com.documentum.web.form.control.Text.class);
			cust_typeT.setValue(cust_type);
			cust_typeT.setEnabled(false);
			Text cust_id_typeT = (Text) getControl("cust_id_type", com.documentum.web.form.control.Text.class);
			cust_id_typeT.setValue(cust_id_type);
			cust_id_typeT.setEnabled(false);
			Text cust_id_numT = (Text) getControl("cust_id_num", com.documentum.web.form.control.Text.class);
			cust_id_numT.setValue(cust_id_number);
			cust_id_numT.setEnabled(false);
			Text coll_numT = (Text) getControl("coll_num", com.documentum.web.form.control.Text.class);
			coll_numT.setValue(collateral_id);
			coll_numT.setEnabled(false);
			Text car_year_createdT = (Text) getControl("car_year_created", com.documentum.web.form.control.Text.class);
			car_year_createdT.setValue(car_year_created);
			car_year_createdT.setEnabled(false);
			Text created_byT = (Text) getControl("created_by", com.documentum.web.form.control.Text.class);
			created_byT.setValue(upload_by);
			created_byT.setEnabled(false);
			Text facility_numT = (Text) getControl("facility_num", com.documentum.web.form.control.Text.class);
			facility_numT.setValue(facility_number);
			facility_numT.setEnabled(false);
			
			Label labelLocation = (Label) getControl("location", com.documentum.web.form.control.Label.class);
			if (labelLocation != null) {
				labelLocation.setLabel(getParentPathSelection());
			}
			Label labelFilename = (Label) getControl("file", com.documentum.web.form.control.Label.class);

			if (labelFilename != null) {
				labelFilename.setLabel(UploadUtil.getFilenameFromPath(getFilePathSelection()));
			}
			Text textObjectName = getObjectNameTextControl(true);
			if (!isPreserveFileExtension() && strFilename != null) {
				int i = strFilename.lastIndexOf('.');
				if (i > 0 && i < strFilename.length()) {
					String ext = strFilename.substring(i + 1);
					if (FormatService.getInstance().extensionExists(ext)) {
						strFilename = strFilename.substring(0, i);
					}
				}
			}
			textObjectName.setValue(strFilename);
		} catch (DfException e) {
			throw new WrapperRuntimeException(e);
		}
	}

	@Override
	protected void initTypeListControl() {
		ScrollableResultSet resultSet = createTypesResultSet();
		DataDropDownList typeList = getTypeListControl(true);
		typeList.getDataProvider().setScrollableResultSet(resultSet);
		typeList.setValue(getDocbaseType());
	}

	@Override
	protected void initFormatControl() {
		if (isDirectory()) {
			getFormatListControl(true).setVisible(false);
		} else {
			ScrollableResultSet resultSet = createFormatsResultSet();
			DataDropDownList formatList = getFormatListControl(true);
			formatList.getDataProvider().setScrollableResultSet(resultSet);
			formatList.setValue("unknown");
		}
	}

	@Override
	protected ScrollableResultSet createFormatsResultSet() {
		CachedResultSet resultSet;
		ServletRequest req = getPageContext().getRequest();
		TransientObjectWrapper tw = (TransientObjectWrapper) req.getAttribute(FORMATS_RESULTSET_REQ_CACHE);
		if (tw != null && (resultSet = (CachedResultSet) tw.get()) != null) {
			resultSet = (CachedResultSet) resultSet.clone();
		} else {
			ScrollableResultSet rs = null;
			try {
				rs = FormatService.getInstance().getResultSet(new String[] { "name", "description" }, false);
			} catch (DfException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			rs.sort("description", 0, 1);
			resultSet = new CachedResultSet(rs);
			tw = new TransientObjectWrapper(resultSet);
			req.setAttribute(FORMATS_RESULTSET_REQ_CACHE, tw);
		}
		return resultSet;

	}

	@Override
	protected ScrollableResultSet createTypesResultSet() {
		ScrollableResultSet resultSet = null;
		String baseObjectType = getBaseDocbaseType();
		String excludedSuperTypes[] = { "dm_folder", "dmc_rm_formal_record" };
		String excludedFolderSuperTypes[] = { "dmc_rm_formal_rec_cabinet", "dmc_rm_formal_rec_folder" };
		if (baseObjectType != null && baseObjectType.length() > 0) {
			if (isDirectory()) {
				try {
					resultSet = getTypes("folder_filter", baseObjectType, excludedFolderSuperTypes);
				} catch (DfException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					resultSet = getTypes("document_filter", baseObjectType, excludedSuperTypes);
				} catch (DfException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else if (isDirectory()) {
			try {
				resultSet = getTypes("folder_filter", "dm_folder", excludedFolderSuperTypes);
			} catch (DfException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			try {
				resultSet = getTypes("document_filter", getDocumentBaseType(), excludedSuperTypes);
			} catch (DfException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return resultSet;

	}

	private ScrollableResultSet getTypes(String filterElementName, String supertype, String notSupertypes[]) throws DfException {
		CachedResultSet resultSet = null;
		StringBuffer buf = new StringBuffer(255);
		buf.append(supertype);
		if (notSupertypes != null) {
			if (notSupertypes.length != 0) {
				buf.append(",");
			}
			int i = 0;
			do {
				if (i >= notSupertypes.length) {
					break;
				}
				buf.append(notSupertypes[i++]);
				if (i != notSupertypes.length) {
					buf.append(",");
				}
			} while (true);
		}
		String typeKey = buf.toString();
		ServletRequest req = getPageContext().getRequest();
		TransientObjectWrapper tw = (TransientObjectWrapper) req.getAttribute(TYPES_RESULTSET_REQ_CACHE);
		Map typesCache;
		if (tw != null && (typesCache = (Map) tw.get()) != null) {
			resultSet = (CachedResultSet) typesCache.get(typeKey);
		} else {
			typesCache = new HashMap();
			tw = new TransientObjectWrapper(typesCache);
			req.setAttribute(TYPES_RESULTSET_REQ_CACHE, tw);
		}
		if (resultSet == null) {
			TableResultSet tmpResultSet = new TableResultSet(new String[] { "type_name", "description", "label_text" });
			TypeSelector typeSelector = new TypeSelector(supertype, notSupertypes, getConfigBasePath(), filterElementName, "type_filter", getContext());
			List typeItemList = TypeUtil.getTypeList(supertype, notSupertypes);
			if (typeItemList.size() < 1) {
				typeItemList = TypeUtil.getTypeList(supertype, notSupertypes, "en");
			}
			List entries = new ArrayList();
			com.documentum.web.formext.docbase.TypeUtil.TypeItem typeItem;
			for (Iterator i$ = typeItemList.iterator(); i$.hasNext(); entries.add(new Entry(typeItem.getName(), typeItem.getDescription()))) {
				typeItem = (com.documentum.web.formext.docbase.TypeUtil.TypeItem) i$.next();
			}

			typeSelector.setDefaultList(entries);
			List typeLists = typeSelector.getSelection();
			String typeName = null;
			String description;
			String labelText;
			for (Iterator i$ = typeLists.iterator(); i$.hasNext(); tmpResultSet.add(new String[] { typeName, description, labelText })) {
				Entry entry = (Entry) i$.next();
				typeName = entry.getName();
				description = entry.getDescription();
				labelText = (new StringBuilder()).append(description).append(" (").append(typeName).append(')').toString();
			}

			if (typeLists.size() == 1) {
				setDocbaseType(typeName);
			}
			tmpResultSet.sort("description", 0, 1);
			resultSet = new CachedResultSet(tmpResultSet);
			typesCache.put(typeKey, resultSet);
		} else {
			resultSet = (CachedResultSet) resultSet.clone();
		}
		return resultSet;
	}

	@Override
	public void onRender() {
		DataDropDownList list = getTypeListControl(false);

		if (list != null) {
			list.getDataProvider().setDfSession(getDfSession());
		}
		list = getFormatListControl(false);
		if (list != null) {
			list.getDataProvider().setDfSession(getDfSession());
		}
		super.onRender();
	}

	@Override
	public void onRenderEnd() {
		super.onRenderEnd();
		DataDropDownList list = getTypeListControl(false);
		if (list != null) {
			list.setMutable(true);
			list.clearOptions();
		}
		list = getFormatListControl(false);
		if (list != null) {
			list.setMutable(true);
			list.clearOptions();
		}
	}

	@Override
	public String[] getEventNames() {
		return Util.concatarray(super.getEventNames(), new String[] { "onsynctype" });
	}

	@Override
	public String getEventHandlerMethod(String strEvent) {
		String strMethod = null;
		if (strEvent.equals("onsynctype")) {
			strMethod = "onSyncType";
		} else {
			strMethod = super.getEventHandlerMethod(strEvent);
		}
		return strMethod;
	}

	@Override
	public Control getEventHandler(String strEvent) {
		Control handler = null;
		if (strEvent.equals("onsynctype")) {
			handler = this;
		} else {
			handler = super.getEventHandler(strEvent);
		}
		return handler;
	}

	@Override
	public void onSyncType(Control control, ArgumentList arg) {
		boolean bFound;
		String strInitialValue;
		label0: {
			bFound = false;
			String strValue = arg.get("newType");
			strInitialValue = arg.get("initType");
			DocbaseObject docbaseObj = getDocbaseObjectControl(false);
			ScrollableResultSet typesResultset = createTypesResultSet();
			if (typesResultset == null || typesResultset.getResultsCount() <= 0) {
				break label0;
			}
			typesResultset.setCursor(-1);
			int nTypeNameColumn = typesResultset.findColumn("type_name");
			String strType;
			do {
				if (!typesResultset.next()) {
					break label0;
				}
				strType = (String) typesResultset.getObject(nTypeNameColumn + 1);
			} while (!strType.equals(strValue));
			bFound = true;
			if (docbaseObj != null) {
				docbaseObj.setType(strValue);
			}
		}
		if (!bFound) {
			DataDropDownList list = getTypeListControl(false);
			if (list == null) {
				list = getTypeListControl(true);
			}
			list.setValue(strInitialValue);
			LOGGER.debug("strInitialValue:" + list.getName());
		}
	}

	@Override
	public void onSelectType(DropDownList list, ArgumentList arg) {
		ArgumentList eventArgs = new ArgumentList();
		eventArgs.add("type", list.getValue());
		eventArgs.add("objectName", getObjectNameTextControl(false).getValue());
		eventArgs.add("format", getFormatListControl(false).getValue());
		Form form = getForm();
		form.fireEvent("onchangeobjecttype", eventArgs);
		DocbaseObject docbaseObj = getDocbaseObjectControl(false);
		if (docbaseObj != null) {
			docbaseObj.setType(list.getValue());
			getContext().set("type", list.getValue());
		}
	}

	@Override
	public boolean onCommitChanges() {
		return getIsValid();
	}

	@Override
	protected String getFolderId() {
		return folderId;
	}

	@Override
	protected String getFilePathSelection() {
		LOGGER.debug("m_filePath:" + m_filePath);

		return m_filePath;

	}

	protected String getTransactionId() {
		LOGGER.debug("transactionId:" + transactionId);

		return transactionId;

	}

	/*
	 * public void setStrLocationComments(String strLocationComments) {
	 * this.strLocationComments = strLocationComments; }
	 */

	@Override
	protected String getObjectNameSelection() {
		Text textObjectName = getObjectNameTextControl(true);
		String strObjectName = textObjectName.getValue();
		LOGGER.debug("strObjectName:" + strObjectName);
		return strObjectName;
	}

	@Override
	protected String getFormatSelection() {
		String strFormat;
		if (!isDirectory()) {
			strFormat = getFormatListControl(true).getValue();
		} else {
			strFormat = null;
		}
		return strFormat;
	}

	@Override
	protected String getTypeSelection() {
		String strType = getTypeListControl(true).getValue();
		return strType;
	}

	@Override
	protected Map getObjectAttributes() {
		Map userFilledValues = null;
		IDfType type;
		try {
			type = getDfSession().getType(getTypeSelection());

			DocbaseObjectAttributeReader reader = new DocbaseObjectAttributeReader(type);
			visitDepthFirst(reader);
			userFilledValues = reader.getProperties();
			if (m_attributes != null) {
				Set entries = m_attributes.entrySet();
				Iterator iterator = entries.iterator();
				do {
					if (!iterator.hasNext()) {
						break;
					}
					java.util.Map.Entry entry = (java.util.Map.Entry) iterator.next();
					String attributeName = (String) entry.getKey();

					if (!userFilledValues.containsKey(attributeName)) {
						int attrIndex = type.findTypeAttrIndex(attributeName);
						if (attrIndex >= 0) {
							IDfAttr attr = type.getTypeAttr(attrIndex);
							if (attr.isRepeating()) {
								userFilledValues.put(attributeName, entry.getValue());
								for (int i = 0; i <= userFilledValues.size(); i++)
									LOGGER.debug("userFilledValues:" + userFilledValues.get(attributeName));
							} else {
								List valueAsList = (List) entry.getValue();
								userFilledValues.put(attributeName, valueAsList.get(0));
								for (int i = 0; i <= userFilledValues.size(); i++)
									LOGGER.debug("userFilledValues:" + userFilledValues.get(attributeName));
							}
						}
					}

				} while (true);
			}
		} catch (Exception e) {

		}

		// return userFilledValues;

		return userFilledValues;

	}

	static boolean isXmlParseable(String strFilenameWithPath, IDfSession session) throws RuntimeException {
		return XmlUtil.isXmlExtension(strFilenameWithPath == null ? "" : strFilenameWithPath, session);
	}

	@Override
	protected void initSelectedFormat() {
		try {
			String format = getDefaultFormat();
			if (format == null) {
				format = guessFormatFromFileExtension();
			}
			DataDropDownList list = getFormatListControl(true);
			list.setValue(format);
			String strSelectedFormat = getFormatListControl(true).getValue();
			if (strSelectedFormat != null && strSelectedFormat.equals("unknown")) {
				getFormatWarningLabelControl(true).setVisible(true);
			}
		} catch (DfException e) {
			throw new WrapperRuntimeException(e);
		}
	}

	private String guessFormatFromFileExtension() throws DfException {
		String strFileExtension = UploadUtil.extractExtension(getFilePathSelection());
		LOGGER.debug("strFileExtension:" + strFileExtension);
		if (!strFileExtension.equals("xls")) {
			Button b1 = (Button) getControl("ok", Button.class);
			b1.setVisible(false);
			b1.setEnabled(false);
			// lblshowvalidation.setLabel("Upload only XLS files");
		}
		if (strFileExtension != null) {
			String format = FormatService.getInstance().guessFormatFromFileExtension(strFileExtension);
			if (format != null) {
				return format;
			}
		}
		return "unknown";
	}

	@Override
	protected void setFolderId(String folderId) {
		this.folderId = folderId;
	}

	@Override
	protected void setFilePath(String filePath) {
		m_filePath = filePath;
	}

	protected void setTransactionId(String transId) {
		transactionId = transId;
	}

	@Override
	public String getLocalFilePath() {
		return m_localFilePath;
	}

	@Override
	public void setLocalFilePath(String path) {
		m_localFilePath = path;
	}

	@Override
	protected String getDocbaseType() {
		if (m_docbaseType != null && m_docbaseType.length() > 0) {
			return m_docbaseType;
		} else {
			return isDirectory() ? getDefaultFolderType() : getDefaultDocumentType();
		}
	}

	@Override
	protected String getBaseDocbaseType() {
		return m_baseDocbaseType;
	}

	private String getDefaultFolderType() {
		String defaultType = lookupString("folder-docbase-type");
		if (typeExists(defaultType)) {
			return defaultType;
		} else {
			return "dm_folder";
		}
	}

	private String getDocumentBaseType() {
		String documentBaseType = lookupString("document-docbase-base-type");
		if (typeExists(documentBaseType)) {
			return documentBaseType;
		} else {
			return "vb_los_docs";
		}
	}

	private String getDefaultDocumentType() {
		String defaultType;
		label0: {
			defaultType = lookupString("document-docbase-type");
			String fileFormat = null;
			try {
				fileFormat = guessFormatFromFileExtension();
			} catch (DfException e) {
			}
			if (fileFormat == null) {
				break label0;
			}
			IConfigElement iConfigElement = lookupElement("docbase-type-mappings");
			if (iConfigElement == null) {
				break label0;
			}
			Iterator docbaseTypesIterator = iConfigElement.getChildElements();
			String configFormat;
			String docbaseType;
			do {
				if (!docbaseTypesIterator.hasNext()) {
					break label0;
				}
				ConfigElement typeElement = (ConfigElement) docbaseTypesIterator.next();
				configFormat = typeElement.getChildValue("format");
				docbaseType = typeElement.getChildValue("type");
			} while (configFormat == null || !configFormat.equalsIgnoreCase(fileFormat) || docbaseType == null);
			defaultType = docbaseType;
		}
		if (typeExists(defaultType)) {
			return defaultType;
		} else {
			return "vb_los_docs";
		}
	}

	@Override
	public String getParentPathSelection() {
		return m_parentPath;
	}

	@Override
	public String getObjectName() {
		return m_objectName;
	}

	@Override
	public void setParentPath(String parentPath) {
		m_parentPath = parentPath;
		LOGGER.debug("m_parentPath==" + m_parentPath);
	}

	@Override
	public void setObjectName(String objectName) {
		m_objectName = objectName;
		LOGGER.debug("m_objectName==" + m_objectName);

	}

	@Override
	protected void setDocbaseType(String docbaseType) {
		m_docbaseType = docbaseType;
	}

	@Override
	protected void setBaseDocbaseType(String baseDocbaseType) {
		m_baseDocbaseType = baseDocbaseType;
	}

	@Override
	public boolean isDirectory() {
		if (m_docbaseType != null && typeExists(m_docbaseType) && TypeUtil.isSubtypeOf(m_docbaseType, "dm_folder")) {
			return true;
		}
		if (getBaseDocbaseType() != null && typeExists(getBaseDocbaseType()) && TypeUtil.isSubtypeOf(getBaseDocbaseType(), "dm_folder")) {
			return true;
		} else {
			return m_directory;
		}
	}

	@Override
	public void setDirectory(boolean directory) {
		m_directory = directory;
	}

	private boolean typeExists(String type) {
		if (type == null || type.length() == 0) {
			return false;
		}
		IDfType dftype;
		try {
			dftype = getDfSession().getType(type);
			// LOGGER.debug("dftype==" + dftype);
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	@Override
	protected DataDropDownList getTypeListControl(boolean create) {
		return (DataDropDownList) getControl0("objectTypeList", create, com.documentum.web.form.control.databound.DataDropDownList.class);
	}

	@Override
	protected DataDropDownList getFormatListControl(boolean create) {
		return (DataDropDownList) getControl0("formatList", create, com.documentum.web.form.control.databound.DataDropDownList.class);
	}

	@Override
	protected Label getFormatWarningLabelControl(boolean create) {
		return (Label) getControl0("unknownFormatWarningLabel", create, com.documentum.web.form.control.Label.class);
	}

	@Override
	protected Label getFilenameLabelControl(boolean create) {
		return (Label) getControl0("filename", create, com.documentum.web.form.control.Label.class);
	}

	protected Label getCheckLabelControl(boolean create) {
		return (Label) getControl0("check_label", create, com.documentum.web.form.control.Label.class);
	}

	@Override
	protected DocbaseObject getDocbaseObjectControl(boolean create) {
		return (DocbaseObject) getControl0("docbaseObj", create, com.documentum.web.formext.control.docbase.DocbaseObject.class);
	}

	@Override
	protected Text getObjectNameTextControl(boolean create) {
		return (Text) getControl0("attribute_object_name", create, com.documentum.web.form.control.Text.class);
	}

	private Control getControl0(String name, boolean create, Class cl) {
		return create ? getControl(name, cl) : getControl(name);
	}

	private static String[] buildColumnArray(ResultSet resultSet) {
		String retArr[] = null;
		try {
			if (resultSet == null) {
				throw new WrapperRuntimeException(new NullPointerException());
			}
			ResultSetMetaData metaData = resultSet.getMetaData();
			int size = metaData.getColumnCount();
			retArr = new String[size];
			for (int i = 0; i < size; i++) {
				retArr[i] = metaData.getColumnName(i + 1);
			}
		} catch (Exception e) {

		}
		return retArr;
	}

	static {
		FORMATS_RESULTSET_REQ_CACHE = (com.documentum.webcomponent.library.contenttransfer.importcontent.ImportContent.class).getName() + ".formatsResultSetCache";
		TYPES_RESULTSET_REQ_CACHE = (com.documentum.webcomponent.library.contenttransfer.importcontent.ImportContent.class).getName() + ".typesResultSetCache";
	}

}
