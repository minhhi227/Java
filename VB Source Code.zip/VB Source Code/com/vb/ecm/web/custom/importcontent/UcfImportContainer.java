package com.vb.ecm.web.custom.importcontent;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.fileselector.FileSelector;
import com.documentum.web.form.control.fileselector.IFile;

import java.util.*;
import org.apache.commons.collections.set.ListOrderedSet;
import org.apache.log4j.Logger;

// Referenced classes of package com.documentum.webcomponent.library.contenttransfer.importcontent:
//            ImportContentContainer

public class UcfImportContainer extends CustomImportContentContainer {
	private static final Logger LOGGER = Logger.getLogger(UcfImportContainer.class);

	public UcfImportContainer() {
		LOGGER.debug("Enter into UcfImportContainer");
	}

	@Override
	protected Collection getUploadedFilesFromRequest() {
		LOGGER.debug("Enter into getUploadedFilesFromRequest() method of UcfImportContainer");
		Set files = ListOrderedSet.decorate(new HashSet());
		FileSelector fselector = getFileselectorControl(false);
		if (fselector != null) {
			IFile ifiles[] = fselector.getSelectedFiles();
			if (ifiles != null) {
				for (int i = 0; i < ifiles.length; i++) {
					IFile ifile = ifiles[i];
					if (ifile != null) {
						addFile(files, ifile, null);
					}
				}

			}
		}
		return files;
	}

	private void addFile(Set files, IFile file, IFile parent) {
		LOGGER.debug("Enter into addFile() method of UcfImportContainer");
		CustomImportContentContainer.ImportFile importFile = new CustomImportContentContainer.ImportFile(null, file.getPath(), null, parent == null ? null : parent.getPath(),
				file.isDirectory());
		files.add(importFile);
		IFile children[] = file.listFiles();
		if (children != null) {
			for (int i = 0; i < children.length; i++) {
				addFile(files, children[i], file);
			}

		}
	}

	protected FileSelector getFileselectorControl(boolean create) {
		LOGGER.debug("Enter into getFileselectorControl() method of UcfImportContainer");
		return (FileSelector) (create ? getControl("fileselector", com.documentum.web.form.control.fileselector.FileSelector.class) : getControl("fileselector"));
	}

	@Override
	public void onCancel1(Control button, ArgumentList args)

	{
		LOGGER.debug("Enter into onCancel1() method of UcfImportContainer");
		setComponentJump("success", getContext());

	}
}
