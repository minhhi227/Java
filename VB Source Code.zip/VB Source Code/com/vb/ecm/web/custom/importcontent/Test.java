package com.vb.ecm.web.custom.importcontent;

import com.documentum.web.formext.session.TrustedAuthenticatorUtils;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="http://hq-ecmapp-dev.hq.icbv.com:8080/webtop/custom/pages/import/" +
				"redirect.jsp?objectId=0901e240800a2e15&__dmfRequestId=__client2%7E%7E2" +
				"&__dmfClientId=1353294055706&__dmfJumpType=jump&__dmfTzoff=-420";

		for (String s1:s.split("=")){
			if(s1.startsWith("09")){
		System.out.println("bbb="+s1);
		if(s1.contains("&")){
		
		String s2[]=s1.split("&");
		System.out.println("trans_id=="+s2[0]);
		}else{
			System.out.println("trans_id in else==="+s1);
		}
			}
		if(s1.startsWith("http")){
			System.out.println("s1"+s1);
		}
		//System.out.println(s1);
		//System.out.println(s1);
		}
		System.out.println("ccc="+ TrustedAuthenticatorUtils.decrypt("b4ceccb486a4a2a89699"));
		
	}
	
}
