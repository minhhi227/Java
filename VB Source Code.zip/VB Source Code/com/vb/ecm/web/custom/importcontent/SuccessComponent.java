package com.vb.ecm.web.custom.importcontent;


import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;


public class SuccessComponent extends Component
{
private ArgumentList transId;

    public SuccessComponent()
    {
    }

    @Override
	public void onInit(ArgumentList args)
    {
    	
     
    	super.onInit(args);
    }
}

