package com.vb.ecm.web.custom.barcode;

public class TestBarcodeGenerationBean {
	
	private  String barcodev,barcodev1;
	private String firstBranch, firstDepartment, firstCustID, firstCustIDType, firstDocType, firstDocID;
	private String secondBranch, secondDepartment, secondCustID, secondCustIDType, secondDocType, secondDocID;

	public TestBarcodeGenerationBean() {
	}
	
	public String getBarcodev() {
		return barcodev;
	}

	public void setBarcodev(String barcodev) {
		this.barcodev = barcodev;
	}
	
	public  String getBarcodev1() {
		return barcodev1;
	}

	public  void setBarcodev1(String barcodev1) {
		this.barcodev1 = barcodev1;
	}

	public String getFirstBranch() {
		return firstBranch;
	}

	public void setFirstBranch(String firstBranch) {
		this.firstBranch = firstBranch;
	}

	public String getFirstDepartment() {
		return firstDepartment;
	}

	public void setFirstDepartment(String firstDepartment) {
		this.firstDepartment = firstDepartment;
	}

	public String getFirstCustID() {
		return firstCustID;
	}

	public void setFirstCustID(String firstCustID) {
		this.firstCustID = firstCustID;
	}

	public String getFirstCustIDType() {
		return firstCustIDType;
	}

	public void setFirstCustIDType(String firstCustIDType) {
		this.firstCustIDType = firstCustIDType;
	}

	public String getFirstDocType() {
		return firstDocType;
	}

	public void setFirstDocType(String firstDocType) {
		this.firstDocType = firstDocType;
	}

	public String getFirstDocID() {
		return firstDocID;
	}

	public void setFirstDocID(String firstDocID) {
		this.firstDocID = firstDocID;
	}

	public String getSecondBranch() {
		return secondBranch;
	}

	public void setSecondBranch(String secondBranch) {
		this.secondBranch = secondBranch;
	}

	public String getSecondDepartment() {
		return secondDepartment;
	}

	public void setSecondDepartment(String secondDepartment) {
		this.secondDepartment = secondDepartment;
	}

	public String getSecondCustID() {
		return secondCustID;
	}

	public void setSecondCustID(String secondCustID) {
		this.secondCustID = secondCustID;
	}

	public String getSecondCustIDType() {
		return secondCustIDType;
	}

	public void setSecondCustIDType(String secondCustIDType) {
		this.secondCustIDType = secondCustIDType;
	}

	public String getSecondDocType() {
		return secondDocType;
	}

	public void setSecondDocType(String secondDocType) {
		this.secondDocType = secondDocType;
	}

	public String getSecondDocID() {
		return secondDocID;
	}

	public void setSecondDocID(String secondDocID) {
		this.secondDocID = secondDocID;
	}
	

}
