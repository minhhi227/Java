package com.vb.ecm.web.custom.barcode;

import org.apache.log4j.Logger;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.component.DialogContainer;
import com.vb.ecm.web.custom.barcode.GenerateBarcodePages;

@SuppressWarnings("serial")
public class GenerateBarcodePagesContainer extends DialogContainer {
	GenerateBarcodePages objBarcodePags = null;
	private static final Logger LOGGER = Logger.getLogger(GenerateBarcodePagesContainer.class);
	public void onExit() {

		super.onExit();
	}

	public void onInit(ArgumentList arg0) {
		LOGGER.debug("Enter into onInit()");
		super.onInit(arg0);
		arg0.get("objectId");
		LOGGER.debug("argsq container" + arg0.get("objectId"));
	}
	public boolean onCommitChanges()
	   {
	       LOGGER.debug("Inside onCommitChanges container");
		   Component component = getContainedComponent();
	       return component.onCommitChanges();
	   }
	public void onOk(Control arg0, ArgumentList arg1) {
		try {
			if(canCommitChanges() && onCommitChanges() && getTopForm().getCallerForm() != null)
		       {
		           setComponentReturn();
		       }
		}
		catch(Exception e){
			LOGGER.error("Exception in onOk() :" + e);
			e.printStackTrace();
		}
	}

}
