package com.vb.ecm.web.custom.barcode;

public class GenerateBarcodePagesConstants {

	public static final String REPORT_STORING_LOCATION = "/Barcode Pages";
	public static final String BARCODE_DELIMITER = ";";
}
