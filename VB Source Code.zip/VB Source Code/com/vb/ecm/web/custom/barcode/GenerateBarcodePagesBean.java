package com.vb.ecm.web.custom.barcode;

public class GenerateBarcodePagesBean {

	// Branch Related
	private String barcodev;
	private String barcodev2;
	private String barcodev3;
	private String barcodev4;
	private String barcodev5;
	private String snv1;
	public String getBarcodev2() {
		return barcodev2;
	}
	public void setBarcodev2(String barcodev2) {
		this.barcodev2 = barcodev2;
	}
	public String getBarcodev3() {
		return barcodev3;
	}
	public void setBarcodev3(String barcodev3) {
		this.barcodev3 = barcodev3;
	}
	public String getBarcodev4() {
		return barcodev4;
	}
	public void setBarcodev4(String barcodev4) {
		this.barcodev4 = barcodev4;
	}
	public String getBarcodev5() {
		return barcodev5;
	}
	public void setBarcodev5(String barcodev5) {
		this.barcodev5 = barcodev5;
	}
	public String getSnv1() {
		return snv1;
	}
	public void setSnv1(String snv1) {
		this.snv1 = snv1;
	}
	public String getSnv2() {
		return snv2;
	}
	public void setSnv2(String snv2) {
		this.snv2 = snv2;
	}
	public String getSnv3() {
		return snv3;
	}
	public void setSnv3(String snv3) {
		this.snv3 = snv3;
	}
	public String getSnv4() {
		return snv4;
	}
	public void setSnv4(String snv4) {
		this.snv4 = snv4;
	}
	public String getSnv5() {
		return snv5;
	}
	public void setSnv5(String snv5) {
		this.snv5 = snv5;
	}
	private String snv2;
	private String snv3;
	private String snv4;
	private String snv5;
    private String vietinbanklogo;
    
	public String getBarcodev() {
		return barcodev;
	}
	public void setBarcodev(String barcodev) {
		this.barcodev = barcodev;
	}
	public String getVietinbanklogo() {
		return vietinbanklogo;
	}
	public void setVietinbanklogo(String vietinbanklogo) {
		this.vietinbanklogo = vietinbanklogo;
	}

	

}
