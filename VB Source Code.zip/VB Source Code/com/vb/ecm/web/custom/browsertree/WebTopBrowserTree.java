package com.vb.ecm.web.custom.browsertree;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.TreeNode;
import java.util.Iterator;

public class WebTopBrowserTree extends com.documentum.webtop.control.WebTopBrowserTree {

	private static final long serialVersionUID = 1L;
	
	public WebTopBrowserTree() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public void onInit(ArgumentList argumentlist)
    {
        super.onInit(argumentlist);
        Iterator iterator = getAllNodes();
        if(null != iterator)
        {
            Object obj;
            for(obj = null; iterator.hasNext(); obj = iterator.next()) { }
            if(null != obj)
            {
                ((TreeNode)obj).setVisible(false);
            }
        }
    }

}
