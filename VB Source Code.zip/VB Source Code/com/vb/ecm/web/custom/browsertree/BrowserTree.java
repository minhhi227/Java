package com.vb.ecm.web.custom.browsertree;

import com.documentum.web.common.ArgumentList;
import com.vb.ecm.web.custom.browsertree.WebTopBrowserTree;

public class BrowserTree extends com.documentum.webtop.webcomponent.browsertree.BrowserTree{

	public BrowserTree() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	 public void onInit(ArgumentList argumentlist)
	    {
	        WebTopBrowserTree webtopbrowsertree = (WebTopBrowserTree)getControl("docbrowser", com.vb.ecm.web.custom.browsertree.WebTopBrowserTree.class);
	        super.onInit(argumentlist);
	    }

}
