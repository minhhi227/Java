package com.vb.ecm.web.custom.browsertree;

public class WebTopBrowserTreeTag  extends com.documentum.webtop.control.WebTopBrowserTreeTag {

	public WebTopBrowserTreeTag() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	 protected Class getControlClass()
	    {
	        return com.vb.ecm.web.custom.browsertree.WebTopBrowserTree.class;
	    }

}
