package com.vb.ecm.web.custom.workflow;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Checkbox;
import com.documentum.web.form.control.Hidden;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.component.Component;
import org.apache.log4j.Logger;

public class StatusReport extends Component {
	// Button details =null;
	IDfCollection collection = null;
	Checkbox name = null;
	Datagrid userGrid = null;
	Button openButton = null;
	private static final Logger LOGGER = Logger.getLogger(StatusReport.class);

	public void onInit(ArgumentList arg) {
		openButton = (Button) getControl("openButton", com.documentum.web.form.control.Button.class);
		openButton.setEnabled(false);
		userGrid = ((Datagrid) getControl("usergrid", Datagrid.class));
	}

	public void onRender() {
		super.onRender();
		try {

			userGrid = ((Datagrid) getControl("usergrid", Datagrid.class));
			userGrid.getDataProvider().setDfSession(getDfSession());
			String squery = "select distinct(ui.dept_name),ui.leave_subject,ui.owner_name,ui.r_creation_date,"
					+ "wi.r_runtime_state,wi.r_creation_date as app_date,act.object_name,pi.r_component_id,"
					+ "pi.r_note_id from dm_activity act ,dmi_workitem wi ,dmi_queue_item qi,dmi_package pi," + "vb_it_leave_form ui where act.r_object_id = wi.r_act_def_id and "
					+ "wi.r_object_id=qi.item_id and qi.router_id = wi.r_workflow_id and" + " (wi.r_runtime_state='0'or wi.r_runtime_state='1') "
					+ "and pi.r_workflow_id=wi.r_workflow_id and ui.owner_name =USER and any pi.r_component_id=ui.r_object_id " + " order by ui.r_creation_date desc ENABLE (ROW_BASED)";
			userGrid.getDataProvider().setQuery(squery);
			userGrid.getDataProvider().refresh();
		} catch (Exception e) {
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * Method Name : getUserValues Description : This method displays the user
	 * information in the datagrid control based on fromDate,toDate and
	 * classification values. Creation Date : 16 June 2009
	 * 
	 * @author : Mahesh
	 * @param control
	 *            : control information
	 * @param arg
	 *            : argument list
	 */
	public void getDetails(Control control, ArgumentList objList) throws DfException {
		// String username=SessionManagerHttpBinding.getUsername();
		// details.setEnabled(true);
		Hidden hidden = (Hidden) getControl("hidden", Hidden.class);
		LOGGER.debug("selected checkbox value " + hidden.getValue());
		// String objectIds=hidden.getValue();
		name = (Checkbox) getControl("namecb", Checkbox.class);
		LOGGER.debug("name" + name);
		// Datagrid dgCtrl = ((Datagrid) getControl("userGrid",
		// Datagrid.class));
		ArgumentList arg = new ArgumentList();
		LOGGER.debug("arg:" + arg);
		arg.add("objectId", hidden.getValue());
		setComponentNested("viewxforms", arg, getContext(), getReturnListener());
		hidden.setValue("");
	}

}
