package com.vb.ecm.web.custom.workflow;

import org.apache.log4j.Logger;
import com.documentum.services.xforms.IFormService;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.form.control.DateInput;
import com.documentum.web.form.control.Hidden;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.web.form.Control;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;

public class LeaveDetails extends Component {

	private static final Logger LOGGER = Logger.getLogger(LeaveDetails.class);

	Label objShowText = null;
	DataDropDownList applicationList = null;
	String FORM_TEMPLATE_NAME = null;
	// String FORM_INSTANCE_PATH = "/FormInstance";
	String FORM_INSTANCE_PATH = "/Temp";
	String formInstanceName = null;
	IDfSession session = null;
	Datagrid datagrid = null;
	DataDropDownList deptList = null;
	Datagrid userGrid = null;

	private String user;

	public void onInit(ArgumentList arg) {
		try {
			
			/*String userQuery = "select distinct user_name from dm_user where user_name=USER";
			IDfQuery query = new DfQuery();
			query.setDQL(userQuery);
			IDfCollection collection = query.execute(getDfSession(), 0);
			while(collection.next()){
				 user=collection.getString("user_name");
				 
			}
			System.out.println("user==="+user);
			FORM_INSTANCE_PATH="/"+user;*/
			datagrid = (Datagrid) getControl("leavegrid", Datagrid.class);
			datagrid.getDataProvider().setDfSession(getDfSession());
			String sdgLeave = "select  object_name,r_object_id from dm_xfm_form where definition_state=2 and object_name='IT_LEAVE_FROM'";
			datagrid.getDataProvider().setQuery(sdgLeave);
			datagrid.getDataProvider().refresh();
			userGrid = ((Datagrid) getControl("usergrid", Datagrid.class));

			deptList = (DataDropDownList) getControl("applcnList", DataDropDownList.class);
			String queryBusinessName = "select distinct dept_name from vb_it_leave_form  where owner_name =USER order by dept_name";
			deptList.getDataProvider().setDfSession(getDfSession());
			deptList.getDataProvider().setQuery(queryBusinessName);

			String applcnName = deptList.getValue();

			userGrid = ((Datagrid) getControl("usergrid", Datagrid.class));
			userGrid.getDataProvider().setDfSession(getDfSession());
			String squery = "select  r_object_id,dept_name,r_creation_date,owner_name,leave_subject " + "from vb_it_leave_form  where owner_name=USER and dept_name!=' '" + "";

			userGrid.getDataProvider().setQuery(squery);
			userGrid.getDataProvider().refresh();
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in Catch Block");
			LOGGER.error(e.fillInStackTrace());

		}
	}
	

	public void onRender() {
		super.onRender();
		
		
		
	}
	@Override
	public void onExit() {
		// TODO Auto-generated method stub
		/*IDfSysObject emptyLeaveObject;
		try {
			emptyLeaveObject = (IDfSysObject) session.getObjectByQualification("vb_it_leave_form where  owner_name=USER and dept_name=' '");
		System.out.println("formObject IDDDD==="+emptyLeaveObject.getObjectId());
		if(emptyLeaveObject!=null)
			emptyLeaveObject.destroy();
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	
		super.onExit();
	}

	public void onSelectUnit(Control control, ArgumentList arg) {
		// IDfSession session = null;

		try {
			// session=
			// sessionManager.getSession(httpBinding.getCurrentDocbase());
			String deptName = deptList.getValue();
			System.out.println("unit Name in on selectapp" + deptName);
			userGrid = ((Datagrid) getControl("usergrid", Datagrid.class));
			userGrid.getDataProvider().setDfSession(getDfSession());
			String squery = "select  r_object_id,dept_name,r_creation_date,owner_name,leave_subject " + "from vb_it_leave_form  where owner_name=USER " + " and dept_name='"
					+ deptName + "' and r_object_type='vb_it_leave_form'";
			System.out.println("1");
			userGrid.getDataProvider().setQuery(squery);
			System.out.println("2");
			deptList.getDataProvider().refresh();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in Catch Block");
			LOGGER.error(e.fillInStackTrace());

		}

	}

	public void getUserValues(Control control, ArgumentList arg) {
		// IDfSession session = null;

		try {
			// session=
			// sessionManager.getSession(httpBinding.getCurrentDocbase());

			deptList = (DataDropDownList) getControl("applcnList", DataDropDownList.class);

			String applcnName = deptList.getValue();
			userGrid = ((Datagrid) getControl("usergrid", Datagrid.class));
			userGrid.getDataProvider().setDfSession(getDfSession());
			String squery = "select r_object_id,dept_name,owner_name,leave_subject,r_creation_date " + "from vb_it_leave_form where owner_name=USER and dept_name!=' '"
					+ "   order by r_creation_date";
			userGrid.getDataProvider().setQuery(squery);
			userGrid.getDataProvider().refresh();
			System.out.println("User values refreshed ");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in Catch Block");
			LOGGER.error(e.fillInStackTrace());

		}

	}

	public void getDetails(Control control, ArgumentList objList) throws DfException {
		Hidden hidden = (Hidden) getControl("hidden", Hidden.class);
		System.out.println("selected checkbox value " + hidden.getValue());
		ArgumentList arg = new ArgumentList();
		System.out.println("arg:" + arg);
		arg.add("objectId", hidden.getValue());
		setComponentNested("viewxforms", arg, getContext(), getReturnListener());
		hidden.setValue("");
	}

	public void reopen(Control control, ArgumentList objList) throws DfException {
		// IDfSession session = null;

		try {
			// session=
			// sessionManager.getSession(httpBinding.getCurrentDocbase());
			Hidden hidden = (Hidden) getControl("hidden", Hidden.class);

			ArgumentList arg = new ArgumentList();
			arg.add("objectId", hidden.getValue());
			setComponentNested("editxforms", arg, getContext(), getReturnListener());
			hidden.setValue("");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in Catch Block");
			LOGGER.error(e.fillInStackTrace());

		}

	}

	public void showdoc(Control objControl, ArgumentList objList) throws Exception {

		// setComponentJump("newxforms",objList,this.getContext());
		System.out.println("context=" + this.getContext());

		System.out.println("objectId" + objList.get("objectId"));
		System.out.println("id" + objList);
		IDfId forminstID = createFormInstance(getDfSession(), objList.get("objectId"));
		ArgumentList arg = new ArgumentList();
		System.out.println("arg:" + arg);
		arg.add("objectId", forminstID.toString());
		System.out.println("arg:" + arg);
		setComponentNested("editxforms", arg, getContext(), getReturnListener());
		System.out.println("view component launched:");
	}

	protected IDfId createFormInstance(IDfSession session, String formtemplateId) {
		IDfId forminstid = null;
		try {
			IDfClientX clientx = new DfClientX();
			System.out.println("clientx:" + clientx);
			IDfClient client = clientx.getLocalClient();
			System.out.println("client:" + client);
			System.out.println("session:" + session);
			IFormService oIXFormsService = (IFormService) client.newService((com.documentum.services.xforms.IFormService.class).getName(), session.getSessionManager());
			System.out.println("oIXFormsService:" + oIXFormsService);
			IDfSysObject formTempObj = (IDfSysObject) session.getObject(new DfId(formtemplateId));
			System.out.println("formTempObj:" + formTempObj);
			IDfSysObject formTempObject = (IDfSysObject) session.getObjectByQualification("dm_xfm_form where object_name='" + formTempObj.getObjectName() + "'");
			System.out.println("formTempObject:" + formTempObject);
			String formTempID = formTempObject.getString("r_object_id");
			DfLogger.debug(this, "Form Template ID: " + formTempID, null, null);
			//if(formTempObject.getString(""))
			forminstid = oIXFormsService.createFormInstance(new DfId(formTempID), formTempObj.getObjectName(), FORM_INSTANCE_PATH, session.getDocbaseName());
			System.out.println("forminstid:" + forminstid);
			DfLogger.debug(this, "form instance created " + forminstid, null, null);
			/*
			 * ArgumentList arg = new ArgumentList(); System.out.println("arg:"+arg);
			 * arg.add("objectId", forminstid.toString());
			 * System.out.println("arg:"+arg); setComponentJump("editxforms", arg,
			 * getContext());
			 */
			// setComponentReturn();
			

			System.out.println("last session:" + session);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in Catch Block");
			LOGGER.error(e.fillInStackTrace());

			DfLogger.error(this, "error while creating form instance:" + e, null, null);
		}
		return forminstid;
	}

}