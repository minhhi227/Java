/**
 * ---------------------------------------
 * AUTHOR
 * Create by : minhtt@vietinbank.vn
 * Create date: 22/05/2014
 * Description: Delete all document (dm_document  type) that have name like 'ECM Document - %'
 * ---------------------------------------
 * HOW TO INSTALL
 * - On Content server: 
 *   + Copy vbDeleteEmptyDoc.jar file to c:\Documentum\dba\java_methods\
 * - In Documentum Admin (DA) page:
 *   + Create method
 *     . Name: vb_DeleteEmptyDoc
 *     . Method type: java
 *     . Verb: com.vb.ecm.server.jobs.DeleteEmptyDoc
 *     . Run as installation owner
 *     . Use method server
 *   + Create job
 *     . Name: vb_DeleteEmptyDoc
 *     . Method name: vb_DeleteEmptyDoc
 * ---------------------------------------
 * ARGUMENT
 * - DQL command to find job_id: select * from dm_job where object_name like 'vb%'
 * - Job argument:
 *   + -user_name ecmdmadmin
 *   + -docbase_name ECM_REPO_UAT1
 *   + -method_trace_level 0 
 *   + -job_id 0802852080190279 
 *   + -delete_period 7
 * ---------------------------------------
 * HOW TO CONTROL
 * - Job report: c:\Documentum\dba\log\00028520\sysadmin\vb_DeleteEmptyDocDoc.txt
 * - Java method log: c:\Documentum\jboss5.1.0\server\DctmServer_MethodServer\log\server.log  
 */
package com.vb.ecm.server.jobs;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.methodserver.DfMethodArgumentManager;
import com.documentum.fc.methodserver.IDfMethod;
import com.documentum.operations.IDfDeleteOperation;
import com.documentum.server.impl.method.common.SessionManagerManager;
import com.documentum.server.impl.method.report.IReportWriter;
import com.documentum.server.impl.method.report.ReportFactory;
import com.sun.jmx.snmp.Timestamp;

public class DeleteEmptyDoc implements IDfMethod {
	private String msDocBaseName = null; // "REPO_TEST.REPO_TEST";
	private String msUserName = null; // "Administrator";
	private String msJobID = null;
	private String msDeletePeriod = null;
	private int miMethodTraceLevel = 0;

	private IDfSession moSession = null;
	private static IReportWriter reportWriter = null;
	private static final String APP_NAME = DeleteEmptyDoc.class.getName()
			+ " Version 1.0.0.9";

	@Override
	public int execute(Map pmapArgs, PrintWriter poWriter) throws Exception {
		System.out.println(APP_NAME);

		Iterator it = pmapArgs.keySet().iterator();
		while (it.hasNext()) {
			String key = (String) it.next();
			String values[] = (String[]) pmapArgs.get(key);
			log(key + " --> " + values[0]);
			if (key != null && key.length() != 0 && values != null
					&& values.length >= 1) {
				if (key.equalsIgnoreCase("docbase_name")) {
					msDocBaseName = values[0];
				} else if (key.equalsIgnoreCase("user_name")) {
					msUserName = values[0];
				} else if (key.equalsIgnoreCase("job_id")) {
					msJobID = values[0];
				} else if (key.equalsIgnoreCase("method_trace_level")) {
					miMethodTraceLevel = Integer.parseInt(values[0]);
				} else if (key.equalsIgnoreCase("delete_period")) {
					msDeletePeriod = values[0];
				}
			}
		}

		ReportFactory rf = new ReportFactory();
		IDfId loJobId = new DfId(msJobID);
		reportWriter = rf.getReport(msDocBaseName, msUserName, "",
				miMethodTraceLevel, loJobId, poWriter);

		log("------------------------------------");
		log("Start " + APP_NAME);
		log("------------------------------------");

		if (msDeletePeriod == null) {
			msDeletePeriod = "7";
			log("delete_period not specify, use default value: 7");
		}

		moSession = SessionManagerManager.getSession(msDocBaseName, msUserName,
				null, null);

		// Version 1.0.0.6
		// ExecuteDQL(moSession,
		// "delete dm_document object where object_name like 'ECM Document - %' and datediff(day,r_creation_date,date(today))>="
		// + msDeletePeriod);

		// Version 1.0.0.7
		IDfCollection loList2Delete = ListAllEmptyDoc(moSession);
		deleteEmptyDoc(moSession, loList2Delete);

		log("------------------------------------");
		log("Finish " + APP_NAME);
		log("------------------------------------");

		reportWriter.closeOut(true);
		if (reportWriter != null) {
			reportWriter.close();
		}
		return 0;
	}

	private IDfCollection ListAllEmptyDoc(IDfSession poSession) {
		String lsQuery = "select object_name, r_object_id from dm_document where object_name like 'ECM Document - %' and datediff(day,r_creation_date,date(today))>="
				+ msDeletePeriod;
		DfQuery loQuery = new DfQuery();
		loQuery.setDQL(lsQuery);
		try {
			log("Executing DQL: " + lsQuery);
			IDfCollection loResult = loQuery.execute(poSession,
					IDfQuery.DF_EXEC_QUERY);
			return loResult;
		} catch (DfException e) {
			log(e.toString());
		}
		return null;
	}

	private void deleteEmptyDoc(IDfSession poSession, IDfCollection poDeleteList) {
		try {
			while (poDeleteList.next()) {
				String lsDocName = poDeleteList.getString("object_name");
				String lsDocID = poDeleteList.getString("r_object_id");
				log(String.format("About to delete '%s' with ID '%s'",
						lsDocName, lsDocID));
				IDfSysObject loSysObject = (IDfSysObject) poSession
						.getObject(new DfId(lsDocID));
				if(loSysObject.isCheckedOut())
					loSysObject.cancelCheckout();
				loSysObject.destroyAllVersions();
			}
		} catch (DfException e) {
			log(e.toString());
		}
	}

	private void ExecuteDQL(IDfSession poSession, String psDQL) {
		try {
			log("Executing DQL: " + psDQL);
			IDfQuery query = new DfQuery();
			query.setDQL(psDQL);
			query.execute(poSession, IDfQuery.DF_EXEC_QUERY);

		} catch (DfException e) {
			log(e.toString());
		}
	}

	private void log(String psMsg) {
		String lsTimeStamp = (new Timestamp(System.currentTimeMillis()))
				.toString();
		String lsLog = String.format("[%s] %s", lsTimeStamp, psMsg);
		if (reportWriter != null)
			reportWriter.emitLineToReport(lsLog);
		System.out.println(lsLog);
	}

	public static void main(String args[]) throws Exception {
		System.out.println("Enter into main()");
		DeleteEmptyDoc uqp = new DeleteEmptyDoc();
		uqp.execute(DfMethodArgumentManager.getArgumentsFromCommandLine(args),
				new PrintWriter(System.out));
		System.out.println("Exit from main()");
	}
}