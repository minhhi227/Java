/**
 * ______________________________________________________________________________
 *
 * File: MoveCustomerDocs.java
 *______________________________________________________________________________
 *
 * CreatedBy: Verinon
 * CreationDate: Nov 6, 2012   10:36:43 AM   2012
 * Description: This Job read input job parameter based on that list of customer folder move to  destination folder
 *                    Parameter are mandatory, and these parameter should be valid parameters(exist in ECM)
 * 
 *______________________________________________________________________________
 *
 * Copyright: (c) Vietinbank, all rights reserved 
 *______________________________________________________________________________
 *
 *
 *	
	--On Repository	
		Create java method from da 'movecustomerdocsjob' method verb: com.vb.ecm.server.jobs.UpdateUsersFromLOS
        Create job from da 'MoveCustomerDocs'
    
    
    --Description: This Job read input job parameter based on that list of customer folder move to  destination folder
                     Parameter are mandatory, and these parameter should be valid parameters(exist in ECM)
                     
    --Job Name: MoveCustomerDocs
      Job Method name: movecustomerdocsjob
    					
    --job args: -destinationFolderPath /Branch 160/icDoc Docs         ------- Where to Move docs
                -sourceFolderIDs 160-GHTD-2012-642,160-GHTD-2012-643  ------- What Customer Docs
                -- Log location
                
    --job logs: Content Server Machine: E:\Documentum\jboss5.1.0\server\DctmServer_MethodServer\logs\customjobs.log
    					E:\Documentum\jboss5.1.0\server\DctmServer_MethodServer\log\server.log  
 */
package com.vb.ecm.server.jobs;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.methodserver.DfMethodArgumentManager;
import com.documentum.fc.methodserver.IDfMethod;
import com.documentum.server.impl.method.common.SessionManagerManager;
import com.documentum.server.impl.method.report.IReportWriter;
import com.documentum.server.impl.method.report.ReportFactory;

public class MoveCustomerDocs implements IDfMethod {

	private static final Logger LOGGER = DfLogger.getLogger(MoveCustomerDocs.class);

	private static IReportWriter reportWriter;
	private IDfSession session = null;
	private String docbaseName = null, userName = null, loginTicket = null, id = null;
	private int methodTraceLevel = 0;
	private ResourceBundle rsb = null;
	private String sourceFolderIDs = "";
	private String destinationFolderPath = null;

	@SuppressWarnings("unchecked")
	public int execute(Map args, PrintWriter writer) throws Exception {

		try {
			Iterator it = args.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				String values[] = (String[]) args.get(key);
				if (key != null && key.length() != 0 && values != null && values.length >= 1) {
					if (key.equalsIgnoreCase("docbase_name")) {
						docbaseName = values[0];
						LOGGER.debug("Docbase Name :" + docbaseName);
					} else if (key.equalsIgnoreCase("user_name")) {
						userName = values[0];
						LOGGER.debug("User Name is:" + userName);
					} else if (key.equalsIgnoreCase("ticket")) {
						loginTicket = values[0];
						LOGGER.debug("loginTicket :" + loginTicket);
					} else if (key.equalsIgnoreCase("job_id")) {
						id = values[0];
					} else if (key.equalsIgnoreCase("method_trace_level")) {
						methodTraceLevel = Integer.parseInt(values[0]);
						LOGGER.debug("Trace Level :" + methodTraceLevel);
					}
				}
			}

			ReportFactory rf = new ReportFactory();
			IDfId jobId = new DfId(id);
			boolean moveDocs = false;
			reportWriter = rf.getReport(docbaseName, userName, "", methodTraceLevel, jobId, writer);
			reportWriter.emitLineToReport("-------------------------------------------------");
			reportWriter.emitLineToReport("---- Update Users From LOS to ECM Job Started ---");
			DfMethodArgumentManager argsObj = new DfMethodArgumentManager(args);
			//sourceFolderIDs = argsObj.getString("sourceFolderIDs");
			// file read
			FileInputStream fstream = new FileInputStream("C:/Documentum/config/sourceFolderIDs.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine = null;
			while ((strLine = br.readLine()) != null) {
				sourceFolderIDs = sourceFolderIDs + strLine;
			}

			destinationFolderPath = argsObj.getString("destinationFolderPath");
			reportWriter.emitLineToReport("sourceFolderIDs:- " + sourceFolderIDs );
			reportWriter.emitLineToReport("destinationPath:-" + destinationFolderPath);
			session = SessionManagerManager.getSession(docbaseName, userName, null, null);
			reportWriter.emitLineToReport("Session Created Successfully for User:" + userName + " with" + session);
			rsb = ResourceBundle.getBundle("com.vb.ecm.server.jobs.updateusersconfig");
			/*
			 * calling moveDocsToApprovedFolder() method to collection of users
			 * from register table
			 */
			if (isDestinationPathExist(destinationFolderPath)) {
				if (isSourceFolderExist(sourceFolderIDs)) {
					if (isMovingFolderNotExistOnDest(destinationFolderPath, sourceFolderIDs)) {
						// ready to move docs from souce to destination with all
						// source objects and it's child
						moveDocs = moveDocuments(destinationFolderPath, sourceFolderIDs);
						if (moveDocs == true) {
							updateDocuments(destinationFolderPath);
						} else {

						}
					} else {
						reportWriter.emitLineToReport("--JOB Stopped due to sourceFolderID's already exist on destination, please check the report");
					}
				} else {
					reportWriter.emitLineToReport("--JOB Stopped due to sourceFolderID's does not exist in repo, please check the report");
				}
			} else {
				reportWriter.emitLineToReport("--JOB Stopped due destination folder Path does not exist in repo, please check the report");
			}

			reportWriter.emitLineToReport("----Move Customer Docs Job Ended -----");
			reportWriter.emitLineToReport("-------------------------------------------------");

			// closing print writer
			reportWriter.closeOut(true);

		} catch (Exception e) {
			LOGGER.error("Error in Execute Method : ", e.fillInStackTrace());
			e.printStackTrace();
			reportWriter.emitLineToReport("Error in Execute Method : e.printStackTrace()");
			reportWriter.emitLineToReport(e.getMessage());
			reportWriter.closeOut(true);
		} finally {
			if (reportWriter != null) {
				reportWriter.close();
			}
			if (session != null) {
				SessionManagerManager.release(session);
			}
		}
		return 0;
	}

	/**
	 * Method Name : getLOSUsersFromLOSDB Description : This method will execute
	 * query on registered table and return collection object.
	 * 
	 * @param
	 * @throws DfException
	 **/
	private boolean isDestinationPathExist(String destFolderPath) throws DfException {
		// TODO Auto-generated method stub
		boolean isDestFolPathExist = false;
		IDfFolder destFolderObj = (IDfFolder) session.getObjectByPath(destFolderPath);
		if (destFolderObj != null) {
			reportWriter.emitLineToReport("SUCCESS PreCondition Destination Folder Path exist " + destFolderPath);
			isDestFolPathExist = true;
		} else {
			reportWriter.emitLineToReport("FAILED PreCondition Destination Folder Path Not exist " + destFolderPath);
			isDestFolPathExist = false;
		}
		return isDestFolPathExist;
	}

	/**
	 * Method Name : getLOSUsersFromLOSDB Description : This method will execute
	 * query on registered table and return collection object.
	 * 
	 * @param
	 * @throws DfException
	 **/
	private boolean isSourceFolderExist(String sourFolderID) throws DfException {
		// TODO Auto-generated method stub
		boolean isDestFolIDExist = false;
		IDfFolder sourFolderObj = null;
		int failed = 0;
		String[] folderIds = sourFolderID.split(",");
		for (int i = 0; i < folderIds.length; i++) {
			sourFolderObj = (IDfFolder) session.getObjectByQualification("vb_folder where object_name='" + folderIds[i] + "'");
			if (sourFolderObj != null) {
				reportWriter.emitLineToReport("SUCCESS PreCondition, Customer Folder Exist" + folderIds[i]);
			} else {
				reportWriter.emitLineToReport("FAILED PreCondition, Customer Folder Not Exist !!!" + folderIds[i]);
				failed = failed + 1;
			}
		}
		if (failed == 0) {
			isDestFolIDExist = true;
		} else {
			isDestFolIDExist = false;
		}
		return isDestFolIDExist;
	}

	/**
	 * Method Name : getLOSUsersFromLOSDB Description : This method will execute
	 * query on registered table and return collection object.
	 * 
	 * @param
	 * @throws DfException
	 **/
	private boolean isMovingFolderNotExistOnDest(String destFolderPath, String sourFolderID) throws DfException {
		// TODO Auto-generated method stub
		boolean isFolderNotExist = false;
		IDfFolder destFolderObj = null;
		int failed = 0;
		String[] folderIds = sourFolderID.split(",");
		for (int i = 0; i < folderIds.length; i++) {
			destFolderObj = (IDfFolder) session.getObjectByPath(destFolderPath + "/" + folderIds[i]);
			if (destFolderObj == null) {
				reportWriter.emitLineToReport("SUCCESS PreCondition, Destination Folder Not Exist " + destFolderPath + "/" + folderIds[i]);
			} else {
				reportWriter.emitLineToReport("FAILED PreCondition, Destination Folder already Exist !!! " + destFolderPath + "/" + folderIds[i]);
				failed = failed + 1;
			}
		}
		if (failed == 0) {
			isFolderNotExist = true;
		} else {
			isFolderNotExist = false;
		}
		return isFolderNotExist;
	}

	/**
	 * Method Name :
	 * 
	 * 
	 * @param
	 * @throws DfException
	 **/
	private boolean moveDocuments(String destFolderPath, String sourFolderID) throws DfException {
		// TODO Auto-generated method stub
		boolean moveDone = false;
		IDfQuery moveDocsQuery = null;
		IDfCollection moveDocsColl = null;
		String moveDocsQueryS = null;
		String[] folderIds = sourFolderID.split(",");
		// update dm_folder objects move to '/Branch 160/icDoc Docs' where
		// r_object_id='0b01e240800a6fff'
		for (int i = 0; i < folderIds.length; i++) {
			moveDocsQueryS = "update vb_folder(all) objects move to '" + destFolderPath + "' where object_name ='" + folderIds[i] + "'";
			LOGGER.debug("moveDocsQueryS:-" + moveDocsQueryS);
			moveDocsQuery = new DfQuery();
			moveDocsQuery.setDQL(moveDocsQueryS);
			LOGGER.debug("getLoginUserName:-" + session.getLoginUserName());
			
			moveDocsColl = moveDocsQuery.execute(session, IDfQuery.DF_EXEC_QUERY);
			while (moveDocsColl.next()) {
				int numObjectsUpdated = moveDocsColl.getInt("objects_updated");
				if (numObjectsUpdated == 0) {
					moveDone = false;
					reportWriter.emitLineToReport("FAIL TO MOVE DOCS " + folderIds[i]);
				} else {
					moveDone = true;
					reportWriter.emitLineToReport("SUCCESSFULLY DOCUMENTS ARE MOVED " + folderIds[i]);
				}
			}
		}
		return moveDone;
	}

	/**
	 * Method Name :
	 * 
	 * 
	 * @param
	 * @throws DfException
	 **/
	private boolean updateDocuments(String destPath) throws DfException {
		// TODO Auto-generated method stub
		boolean updateDocsDone = false;
		IDfQuery updateDocsQuery = null;
		IDfCollection updateDocsColl = null;
		String updateDocsQueryS = null;
		String branchId = destPath.substring(8, 11);
		String isIcDoc = destPath.substring(12, 22);
		String docType = null;
		if (isIcDoc.equalsIgnoreCase("icDoc Docs")) {
			docType = "vb_icdoc_docs";
		} else {
			docType = "vb_los_docs";
		}
		updateDocsQueryS = "UPDATE " + docType + " OBJECTS SET  branch_number= '" + branchId + "' where FOLDER('" + destPath + "',descend)";
		LOGGER.debug("updateDocsQueryS:-" + updateDocsQueryS);
		updateDocsQuery = new DfQuery();
		updateDocsQuery.setDQL(updateDocsQueryS);
		updateDocsColl = updateDocsQuery.execute(session, IDfQuery.DF_EXEC_QUERY);
		while (updateDocsColl.next()) {
			int numObjectsUpdated = updateDocsColl.getInt("objects_updated");
			if (numObjectsUpdated == 0) {
				updateDocsDone = false;
				reportWriter.emitLineToReport("FAIL TO UPDATE DOCS " + destPath);
			} else {
				updateDocsDone = true;
				reportWriter.emitLineToReport("SUCCESSFULLY DOCUMENTS ARE UPDATED " + destPath);
			}
		}
		return updateDocsDone;
	}
}
