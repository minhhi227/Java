package com.vb.ecm.los.simulator;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewDocument extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;    
    
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{  
    	ResourceBundle rsb = null;
    	PrintWriter out = null; 
    	String[] docIds = null;

	try	{		
		//resource bundle
		rsb = ResourceBundle.getBundle("com.vb.ecm.los.simulator.LOSSimulatorConfig");		
		
		out = response.getWriter();
		response.setContentType("text/html");		
		       	
		docIds = request.getParameterValues("document_id");		
		
		if (docIds != null && docIds.length == 1) {			
			
			 
			 String url = "http://"+ rsb.getString("ECM_APPLICATION_NAME") +"/drl/objectId/" + docIds[0] +
					 "/parameter0/"+ rsb.getString("BOCS_SERVER_NAME") +"/";
			 
			 //add time stamp			 
			 SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmm");
			 String inputDate = sdf.format(new Date());			 
			 url = url + "parameter1/" + inputDate + "/parameter2/";
			 
			 String hashValue = MD5(inputDate);			 
			 url = url + hashValue;
			 System.out.println("URL to view document : " + url);
			 
			 response.sendRedirect(url);
		}
		else if(docIds != null && docIds.length>1){
			
			request.setAttribute("success_msg", "Please select only One Document to View.");
			request.getRequestDispatcher("/Main.jsp").forward(request, response);
		}
		else{
			
			request.setAttribute("success_msg", "Please select Document to View.");
			request.getRequestDispatcher("/Main.jsp").forward(request, response);
		}
                
        out.close();        	
	}
	catch(Exception e)
	{
		out.println(e.toString());}
	}    
 
    private String MD5(String text) throws Exception  { 
        MessageDigest md;        
        byte[] md5hash=null;
        
		try {
			md = MessageDigest.getInstance("MD5");
			md5hash = new byte[32];
			md.update(text.getBytes("iso-8859-1"), 0, text.length());
			md5hash = md.digest();
			
		} catch (Exception e) {			
			e.printStackTrace();
		}
        return convertToHex(md5hash);
    }
    
    private String convertToHex(byte[] data) { 
        StringBuffer buf = new StringBuffer();
        
        try {
			for (int i = 0; i < data.length; i++) { 
			    int halfbyte = (data[i] >>> 4) & 0x0F;
			    int two_halfs = 0;
			    do { 
			        if ((0 <= halfbyte) && (halfbyte <= 9)) 
			            buf.append((char) ('0' + halfbyte));
			        else 
			            buf.append((char) ('a' + (halfbyte - 10)));
			        halfbyte = data[i] & 0x0F;
			    } while(two_halfs++ < 1);
			}
			
		} catch (Exception e) {			
			e.printStackTrace();
		} 
        return buf.toString();
    } 
	

}

