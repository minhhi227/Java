package com.vb.ecm.los.simulator;

import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class WriteSBTISStringXML {

	/** 
	 * Method Description: This method is used to write the input data to a String XML
	 * 			   		   in a specific format as requested by the client.
	 * 	                    
	 * @return String	 : returns output as input String XML.
	 */
	public String createXML(String documentId, String requestDate) {
		 
		String returnXMLString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n";			
       
        DocumentBuilderFactory documentBuilderFactory;
        DocumentBuilder documentBuilder;
        Document document;
        try { 
            documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.newDocument();	            
           
            Element messageElement = document.createElement("message");
            document.appendChild(messageElement);            
  
            Element headerElement = document.createElement("header");
            messageElement.appendChild(headerElement);
 
                Element headerItems;
                 
                headerItems = document.createElement("user_id");                
                headerItems.appendChild(document.createTextNode("losaccount")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("message_type");
                headerItems.appendChild(document.createTextNode("SearchByTransactionId")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("source_app_id");
                headerItems.appendChild(document.createTextNode("LOS"));
                headerElement.appendChild(headerItems);              
                
                headerItems = document.createElement("request_timestamp");                
                headerItems.appendChild(document.createTextNode(requestDate));
                headerElement.appendChild(headerItems);                
                
                Element body = document.createElement("body");
                messageElement.appendChild(body);
                
                Element message_request = document.createElement("message_request");
                body.appendChild(message_request);
                
                Element search_filters = document.createElement("SearchFilters");
                message_request.appendChild(search_filters);
                
                Element docProps;
                
                docProps = document.createElement("trans_id");                
                docProps.appendChild(document.createTextNode(documentId));               
                search_filters.appendChild(docProps);
           
            TransformerFactory transformerFactory = TransformerFactory.newInstance();            
            Transformer transformer = transformerFactory.newTransformer();           
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");            
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");            
            
            StringWriter sw = new StringWriter();           
        	StreamResult result = new StreamResult(sw);  
        	            
            DOMSource source = new DOMSource(document);            
            
            transformer.transform(source, result);           
            returnXMLString = returnXMLString + sw.toString();
 
        } catch (Exception e) {
        	e.fillInStackTrace();
        } 
        return returnXMLString;
    }	
	

}
