package com.vb.ecm.los.simulator;

import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class WriteCSStringXML {

	/** 
	 * Method Description: This method is used to write the input data to a String XML
	 * 			   		   in a specific format as requested by the client.
	 * 	                    
	 * @return String	 : returns output as input String XML.
	 */
	public String createXML(HttpServletRequest request, String requestDate) {
		 
		String returnXMLString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n";			
       
        DocumentBuilderFactory documentBuilderFactory;
        DocumentBuilder documentBuilder;
        Document document;
        try { 
            documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.newDocument();	            
           
            Element messageElement = document.createElement("message");
            document.appendChild(messageElement);            
  
            Element headerElement = document.createElement("header");
            messageElement.appendChild(headerElement);
 
                Element headerItems;
                 
                headerItems = document.createElement("user_id");                
                headerItems.appendChild(document.createTextNode(request.getParameter("upload_by"))); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("message_type");
                headerItems.appendChild(document.createTextNode("CreateDocument")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("source_app_id");
                headerItems.appendChild(document.createTextNode("LOS"));
                headerElement.appendChild(headerItems);              
                
                headerItems = document.createElement("request_timestamp");                
                headerItems.appendChild(document.createTextNode(requestDate));
                headerElement.appendChild(headerItems);                
                
                Element body = document.createElement("body");
                messageElement.appendChild(body);
                
                Element message_request = document.createElement("message_request");
                body.appendChild(message_request);
                
                Element document_properties = document.createElement("Document");
                message_request.appendChild(document_properties);
                
                Element docProps;
                
                docProps = document.createElement("branch_number");                
                docProps.appendChild(document.createTextNode(request.getParameter("branch_number")));               
                document_properties.appendChild(docProps);
                
                docProps = document.createElement("cust_type");                
                docProps.appendChild(document.createTextNode(request.getParameter("cust_type")));               
                document_properties.appendChild(docProps);
                
                docProps = document.createElement("cust_id_number");                
                docProps.appendChild(document.createTextNode(request.getParameter("cust_id_number")));               
                document_properties.appendChild(docProps);
                
                docProps = document.createElement("cust_id_type");                
                String[] cust_id_type = (request.getParameter("cust_id_type")).split("-");                
                docProps.appendChild(document.createTextNode(cust_id_type[0].trim()));               
                document_properties.appendChild(docProps);
                
                docProps = document.createElement("doc_sub_type");                 
                docProps.appendChild(document.createTextNode(request.getParameter("doc_sub_type")));               
                document_properties.appendChild(docProps);
                
                docProps = document.createElement("car_year_created");
                String car_year_created = request.getParameter("car_year_created");                
                if(car_year_created!=null){
                	docProps.appendChild(document.createTextNode(car_year_created));               
                    document_properties.appendChild(docProps);
                }
                else{
                	docProps.appendChild(document.createTextNode(""));               
                    document_properties.appendChild(docProps);
                }                
                
                docProps = document.createElement("facility_number");
                String facility_number = request.getParameter("facility_number");                
                if(facility_number!=null){
                	docProps.appendChild(document.createTextNode(facility_number));               
                    document_properties.appendChild(docProps);
                }
                else{
                	docProps.appendChild(document.createTextNode(""));               
                    document_properties.appendChild(docProps);
                }
                                
                docProps = document.createElement("collateral_number");
                String collateral_number = request.getParameter("collateral_number");                
                if(collateral_number!=null){
                	docProps.appendChild(document.createTextNode(collateral_number));               
                    document_properties.appendChild(docProps);
                }
                else{
                	docProps.appendChild(document.createTextNode(""));               
                    document_properties.appendChild(docProps);
                }         
                
                docProps = document.createElement("cust_name");
                String cust_name = request.getParameter("cust_name");                
                if(cust_name!=null){
                	docProps.appendChild(document.createTextNode(cust_name));               
                    document_properties.appendChild(docProps);
                }
                else{
                	docProps.appendChild(document.createTextNode(""));               
                    document_properties.appendChild(docProps);
                }
                                
                docProps = document.createElement("cust_cif_number"); 
                String cust_cif_number = request.getParameter("cust_cif_number");                
                if(cust_cif_number!=null){
                	docProps.appendChild(document.createTextNode(cust_cif_number));               
                    document_properties.appendChild(docProps);
                }
                else{
                	docProps.appendChild(document.createTextNode(""));               
                    document_properties.appendChild(docProps);
                }
                                
                docProps = document.createElement("upload_by");                
                docProps.appendChild(document.createTextNode(request.getParameter("upload_by")));               
                document_properties.appendChild(docProps);                
           
            TransformerFactory transformerFactory = TransformerFactory.newInstance();            
            Transformer transformer = transformerFactory.newTransformer();           
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");            
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");            
            
            StringWriter sw = new StringWriter();           
        	StreamResult result = new StreamResult(sw);  
        	            
            DOMSource source = new DOMSource(document);            
            
            transformer.transform(source, result);           
            returnXMLString = returnXMLString + sw.toString();
 
        } catch (Exception e) {
        	e.fillInStackTrace();
        } 
        return returnXMLString;
    }

}
