package com.vb.ecm.los.simulator;

import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class WriteDSStringXML {

	/** 
	 * Method Description: This method is used to write the input data to a String XML
	 * 			   		   in a specific format as requested by the client.
	 * 	                    
	 * @return String	 : returns output as input String XML.
	 */
	public String createXML(HttpServletRequest request, String[] docIds, String requestDate) {
		 
		String returnXMLString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n";			
       
        DocumentBuilderFactory documentBuilderFactory;
        DocumentBuilder documentBuilder;
        Document document;
        try { 
            documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.newDocument();	            
           
            Element messageElement = document.createElement("message");
            document.appendChild(messageElement);            
  
            Element headerElement = document.createElement("header");
            messageElement.appendChild(headerElement);
 
                Element headerItems;
                 
                headerItems = document.createElement("user_id");                
                headerItems.appendChild(document.createTextNode("losaccount")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("message_type");
                headerItems.appendChild(document.createTextNode("DeleteDocuments")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("source_app_id");
                headerItems.appendChild(document.createTextNode("LOS"));
                headerElement.appendChild(headerItems);              
                
                headerItems = document.createElement("request_timestamp");                
                headerItems.appendChild(document.createTextNode(requestDate));
                headerElement.appendChild(headerItems);                
                
                Element body = document.createElement("body");
                messageElement.appendChild(body);
                
                Element message_request = document.createElement("message_request");
                body.appendChild(message_request);
                
                Element document_details = document.createElement("Documents");
                message_request.appendChild(document_details);
                
                for (int i=0; i<docIds.length; i++) {
                
	                Element doc = document.createElement("Document");
	                document_details.appendChild(doc);
	                
	                Element docProps;
	                
	                docProps = document.createElement("document_id");                
	                docProps.appendChild(document.createTextNode(docIds[i]));               
	                doc.appendChild(docProps);
	                
	                docProps = document.createElement("branch_number");                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);
	                
	                docProps = document.createElement("cust_type");                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);
	                
	                docProps = document.createElement("cust_id_number");                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);
	                
	                docProps = document.createElement("cust_id_type");	                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);              
	                                
	                docProps = document.createElement("car_year_created");                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);
	                
	                docProps = document.createElement("facility_number");                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);
	                
	                docProps = document.createElement("collateral_number");                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);
	                
	                docProps = document.createElement("doc_sub_type");                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);
	                
	                docProps = document.createElement("cust_name");                 
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);              
	                                
	                docProps = document.createElement("cust_cif_number");                
	                docProps.appendChild(document.createTextNode(""));               
	                doc.appendChild(docProps);                
                }
           
            TransformerFactory transformerFactory = TransformerFactory.newInstance();            
            Transformer transformer = transformerFactory.newTransformer();           
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");            
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");            
            
            StringWriter sw = new StringWriter();           
        	StreamResult result = new StreamResult(sw);  
        	            
            DOMSource source = new DOMSource(document);            
            
            transformer.transform(source, result);           
            returnXMLString = returnXMLString + sw.toString();
 
        } catch (Exception e) {
        	e.fillInStackTrace();
        } 
        return returnXMLString;
    }

}
