package com.vb.ecm.los.simulator;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.vb.ecm.services.los.searchbymetadata.ws.SearchByMetadataServiceLocator;
import com.vb.ecm.services.los.searchbymetadata.ws.SearchByMetadataServicePort;

public class RetrieveServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    private PrintWriter out = null;   
    private String status = null;
    private String errorCode = null;
    private String errorMsg = null;   
    
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
    	ResourceBundle rsb = null;	
    	String requestDate = null;
    	ArrayList<String> searchResults = new ArrayList<String>();

	try	{
		//resource bundle
		rsb = ResourceBundle.getBundle("com.vb.ecm.los.simulator.LOSSimulatorConfig");
		
		//request date			
		SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
	    requestDate = sdf.format(new Date());
		
		out = response.getWriter();
		response.setContentType("text/html");
		     	
    	Element identityElement = buildServiceContextWithIdentity(rsb.getString("REPO_NAME"), 
    			rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));
    	
    	searchResults = callSchemaService(identityElement, request, requestDate, rsb); 
    	
    	if(searchResults.size() > 0){
    		
    		request.setAttribute("searchdata", searchResults);
    		request.getRequestDispatcher("/retrieve.jsp").forward(request, response);
    		
    	}else{    	
    	
    		request.setAttribute("update_msg", errorCode + " : " + errorMsg);
    		request.getRequestDispatcher("/retrieve.jsp").forward(request, response);
    	}
                
        out.close();        	
	}
	catch(Exception e)
	{
		out.println(e.toString());}
	}
	
	private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
	        throws ParserConfigurationException {
	
	   // CREATE parser for creating DOM objects, root document
	   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	   Document doc = dbf.newDocumentBuilder().newDocument();
	
	   // CREATE <ServiceContext> and child <Identities> element for authentication
	   String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
	   Element serviceContextElement = doc.createElement("ServiceContext");
	   serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
	   Element identities = doc.createElement("Identities");
	   identities.setAttribute("userName", user);
	   identities.setAttribute("password", pass);
	   identities.setAttribute("repositoryName", docbase);
	   identities.setAttribute("xsi:type", "RepositoryIdentity");
	   serviceContextElement.appendChild(identities);
	
	   return serviceContextElement;
	}
	
	private ArrayList<String> callSchemaService(Element identityElement, HttpServletRequest request, 
				String requestDate, ResourceBundle rsb)
    {
		String inputStringXml = null;
		String outputStringXml = null;
		ArrayList<String> searchResults = new ArrayList<String>();
		
		try
		{			
			SearchByMetadataServiceLocator srvLoc = new 
					SearchByMetadataServiceLocator(rsb.getString("LOS_WEBSERVICES_URL") + "/SearchByMetadataService?wsdl", 
					new QName("http://ws.searchbymetadata.los.services.ecm.vb.com/", "SearchByMetadataService"));
			
			SearchByMetadataServicePort srvPort = 
					srvLoc.getSearchByMetadataServicePort(new 
							URL(rsb.getString("LOS_WEBSERVICES_URL") + "/SearchByMetadataService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the Search By Metadata service
			
			//process input data			
			WriteSBMSStringXML obj = new WriteSBMSStringXML();
			inputStringXml = obj.createXML(request, requestDate);			
			//System.out.println("Search By Metadata Service Input Data ::  " + inputStringXml);
			
			outputStringXml = srvPort.searchByMetadata(inputStringXml);	
			//System.out.println("Search By Metadata Service Output Data ::  " + outputStringXml);
			
			//process output data
			searchResults = processOutputData(outputStringXml);
						
		}
	catch (Exception e)
	{
		out.println(e.toString());
	}
		
		return searchResults;
    }
	
	/** 
	 * Method Description: This method is used to process the output data.                 
	 * 
	 * 
	 */
	private ArrayList<String> processOutputData(String outputStringXml){
		
		ArrayList<String> results = new ArrayList<String>(); 
		
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(outputStringXml));	    
			Document doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize(); 
			
			//header element
			NodeList nList = doc.getElementsByTagName("header");		
	 
			   Node nNode = nList.item(0);
			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) nNode;		      
			      
			      status = getTagValue("status", eElement);			      
			      errorCode = getTagValue("ErrorCode", eElement);			            		
			      errorMsg = getTagValue("ErrorMessage", eElement);			      
			   }
			   
			   if(status.equalsIgnoreCase("0")){
			
					//DocumentProperties element
					NodeList docList = doc.getElementsByTagName("Document");
			 
					for (int temp = 0; temp < docList.getLength(); temp++) {
						 
						   Node node = docList.item(temp);
						   if (node.getNodeType() == Node.ELEMENT_NODE) {
			 
					      Element eElement = (Element) node;		      
					      
					      results.add(getTagValue("document_id", eElement));
					      results.add(getTagValue("document_name", eElement));
					      results.add(getTagValue("url_link", eElement));
					      results.add(getTagValue("creation_date", eElement));
					      results.add(getTagValue("upload_by", eElement));
					      results.add(getTagValue("doc_sub_type", eElement));
					   }
					}
			   }			
			   
		} catch (Exception e) {
			out.println(e.toString());
		} 
		
		return results;
	}
	
	private String getTagValue(String sTag, Element eElement) {
		  
		String tagValue = null;
		
		try {
			NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
 
			    Node nValue = (Node) nlList.item(0); 
			    
			    if(nValue!=null){
			    	tagValue = nValue.getNodeValue();
			    }
			    else{
			    	tagValue = "";
			    }
			    
		} catch (Exception e) {
			
			out.println(e.toString());
		}
	 
		return tagValue;
	  }

}
