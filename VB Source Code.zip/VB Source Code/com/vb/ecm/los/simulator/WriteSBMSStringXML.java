package com.vb.ecm.los.simulator;

import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class WriteSBMSStringXML {

	/** 
	 * Method Description: This method is used to write the input data to a String XML
	 * 			   		   in a specific format as requested by the client.
	 * 	                    
	 * @return String	 : returns output as input String XML.
	 */
	public String createXML(HttpServletRequest request, String requestDate) {
		 
		String returnXMLString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n";			
       
        DocumentBuilderFactory documentBuilderFactory;
        DocumentBuilder documentBuilder;
        Document document;
        try { 
            documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.newDocument();	            
           
            Element messageElement = document.createElement("message");
            document.appendChild(messageElement);            
  
            Element headerElement = document.createElement("header");
            messageElement.appendChild(headerElement);
 
                Element headerItems;
                 
                headerItems = document.createElement("user_id");                
                headerItems.appendChild(document.createTextNode("losaccount")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("message_type");
                headerItems.appendChild(document.createTextNode("SearchByMetadata")); 
                headerElement.appendChild(headerItems);
                
                headerItems = document.createElement("source_app_id");
                headerItems.appendChild(document.createTextNode("LOS"));
                headerElement.appendChild(headerItems);              
                
                headerItems = document.createElement("request_timestamp");                
                headerItems.appendChild(document.createTextNode(requestDate));
                headerElement.appendChild(headerItems);                
                
                Element body = document.createElement("body");
                messageElement.appendChild(body);
                
                Element message_request = document.createElement("message_request");
                body.appendChild(message_request);
                
                Element search_filters = document.createElement("SearchFilters");
                message_request.appendChild(search_filters);
                
                Element docProps;
                
                docProps = document.createElement("branch_number");
                String branch_number = request.getParameter("branch_number"); 
                if(branch_number!=null){
                	docProps.appendChild(document.createTextNode(branch_number));               
                	search_filters.appendChild(docProps);
                }else{
	                docProps.appendChild(document.createTextNode(""));               
	                search_filters.appendChild(docProps);
                }                
                
                docProps = document.createElement("cust_type");  
                String cust_type = request.getParameter("cust_type"); 
                if(cust_type!=null){
	                docProps.appendChild(document.createTextNode(cust_type));               
	                search_filters.appendChild(docProps);
                }else{
                	docProps.appendChild(document.createTextNode(""));               
	                search_filters.appendChild(docProps);
                }
                
                docProps = document.createElement("cust_id_number"); 
                String cust_id_number = request.getParameter("cust_id_number"); 
                if(cust_id_number!=null){
	                docProps.appendChild(document.createTextNode(cust_id_number));               
	                search_filters.appendChild(docProps);
                }else{
                	docProps.appendChild(document.createTextNode(""));               
                    search_filters.appendChild(docProps);
                }
                
                docProps = document.createElement("cust_id_type");
                String cust_id_type = request.getParameter("cust_id_type"); 
                if(cust_id_type!=null){
                	String[] custIdType = cust_id_type.split("-");
	                docProps.appendChild(document.createTextNode(custIdType[0].trim()));               
	                search_filters.appendChild(docProps);  
                }else{
                	docProps.appendChild(document.createTextNode(""));               
                    search_filters.appendChild(docProps);  
                }
                                
                docProps = document.createElement("car_year_created");
                String car_year_created = request.getParameter("car_year_created"); 
                if(car_year_created!=null){
	                docProps.appendChild(document.createTextNode(car_year_created));               
	                search_filters.appendChild(docProps);
                }else{
                	docProps.appendChild(document.createTextNode(""));               
                    search_filters.appendChild(docProps);
                }
                
                docProps = document.createElement("facility_number"); 
                String facility_number = request.getParameter("facility_number"); 
                if(facility_number!=null){
	                docProps.appendChild(document.createTextNode(facility_number));               
	                search_filters.appendChild(docProps);
                }else{
                	docProps.appendChild(document.createTextNode(""));               
                    search_filters.appendChild(docProps);
                }
                
                docProps = document.createElement("collateral_number");
                String collateral_number = request.getParameter("collateral_number"); 
                if(collateral_number!=null){
	                docProps.appendChild(document.createTextNode(collateral_number));               
	                search_filters.appendChild(docProps);
                }else{
                	docProps.appendChild(document.createTextNode(""));               
                    search_filters.appendChild(docProps);
                }
                
                docProps = document.createElement("doc_sub_type"); 
                String doc_sub_type = request.getParameter("doc_sub_type"); 
                if(doc_sub_type!=null){
	                docProps.appendChild(document.createTextNode(doc_sub_type));               
	                search_filters.appendChild(docProps);
                }else{
                	docProps.appendChild(document.createTextNode(""));               
                    search_filters.appendChild(docProps);
                }
                
                docProps = document.createElement("cust_cif_number"); 
                String cust_cif_number = request.getParameter("cust_cif_number"); 
                if(cust_cif_number!=null){
	                 docProps.appendChild(document.createTextNode(cust_cif_number));               
	                 search_filters.appendChild(docProps);
                }else{
                	 docProps.appendChild(document.createTextNode(""));               
                     search_filters.appendChild(docProps);
                }
                
                docProps = document.createElement("cust_name"); 
                String cust_name = request.getParameter("cust_name"); 
                if(cust_name!=null){
	                docProps.appendChild(document.createTextNode(cust_name));               
	                search_filters.appendChild(docProps);  
                }else{
                	docProps.appendChild(document.createTextNode(""));               
                    search_filters.appendChild(docProps); 
                }
                                
                docProps = document.createElement("upload_by"); 
                String upload_by = request.getParameter("upload_by"); 
                if(upload_by!=null){
	                docProps.appendChild(document.createTextNode(upload_by));               
	                search_filters.appendChild(docProps); 
                }else{
                	docProps.appendChild(document.createTextNode(""));               
                    search_filters.appendChild(docProps); 
                }
           
            TransformerFactory transformerFactory = TransformerFactory.newInstance();            
            Transformer transformer = transformerFactory.newTransformer();           
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");            
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");            
            
            StringWriter sw = new StringWriter();           
        	StreamResult result = new StreamResult(sw);  
        	            
            DOMSource source = new DOMSource(document);            
            
            transformer.transform(source, result);           
            returnXMLString = returnXMLString + sw.toString();
 
        } catch (Exception e) {
        	e.fillInStackTrace();
        } 
        return returnXMLString;
    }

}
