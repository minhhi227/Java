package com.vb.ecm.los.simulator;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UnlinkRecords extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	
   
    public static String[] docIds = null;

	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
		{
		PrintWriter out = null;
		
		try	{
			
			out = response.getWriter();
			response.setContentType("text/html");
	
			docIds = request.getParameterValues("document_id");
			
			if(docIds!=null){
				request.getRequestDispatcher("/unlink.jsp").forward(request, response);
			}
			else{
				request.setAttribute("success_msg", "Please select Document(s) to Unlink.");
				request.getRequestDispatcher("/Main.jsp").forward(request, response);
			}    	
        	
	        out.close();        	
	}
	catch(Exception e)
	{
		out.println(e.toString());}
	}
    
	
}
