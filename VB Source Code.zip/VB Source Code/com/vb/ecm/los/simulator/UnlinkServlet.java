package com.vb.ecm.los.simulator;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.vb.ecm.services.los.delete.ws.DeleteServiceLocator;
import com.vb.ecm.services.los.delete.ws.DeleteServicePort;

public class UnlinkServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    private PrintWriter out = null;    
    private String status = null;
    private String errorCode = null;
    private String errorMsg = null;
    
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
    	ResourceBundle rsb = null;
    	String requestDate = null;
    	String successMsg = null;

	try	{
		//resource bundle
		rsb = ResourceBundle.getBundle("com.vb.ecm.los.simulator.LOSSimulatorConfig");
		
		//request date			
		SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
	    requestDate = sdf.format(new Date());
		
		out = response.getWriter();
		response.setContentType("text/html");
		      	
    	Element identityElement = buildServiceContextWithIdentity(rsb.getString("REPO_NAME"), 
    			rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));
    	
    	successMsg = callSchemaService(identityElement, request, requestDate, rsb); 
    	
    	if(successMsg!=null){
    	
	    	request.setAttribute("success_msg", successMsg);    	
	        request.getRequestDispatcher("/Main.jsp").forward(request, response);
    	}
                
        out.close();        	
	}
	catch(Exception e)
	{
		out.println(e.toString());}
	}
	
	private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
	        throws ParserConfigurationException {
	
	   // CREATE parser for creating DOM objects, root document
	   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	   Document doc = dbf.newDocumentBuilder().newDocument();
	
	   // CREATE <ServiceContext> and child <Identities> element for authentication
	   String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
	   Element serviceContextElement = doc.createElement("ServiceContext");
	   serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
	   Element identities = doc.createElement("Identities");
	   identities.setAttribute("userName", user);
	   identities.setAttribute("password", pass);
	   identities.setAttribute("repositoryName", docbase);
	   identities.setAttribute("xsi:type", "RepositoryIdentity");
	   serviceContextElement.appendChild(identities);
	
	   return serviceContextElement;
	}
	
	private String callSchemaService(Element identityElement, HttpServletRequest request, 
				String requestDate, ResourceBundle rsb)
    {
		String statusMsg = null;
		String inputStringXml = null;
		String outputStringXml = null;
		String[] docIds = null;
		
		try
		{			
			DeleteServiceLocator srvLoc = new 
					DeleteServiceLocator(rsb.getString("LOS_WEBSERVICES_URL") + "/DeleteService?wsdl", 
					new QName("http://ws.delete.los.services.ecm.vb.com/", "DeleteService"));
			
			DeleteServicePort srvPort = 
					srvLoc.getDeleteServicePort(new 
							URL(rsb.getString("LOS_WEBSERVICES_URL") + "/DeleteService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service	
			
			//get document ids first and store it an array			
			docIds = UnlinkRecords.docIds;
			if (docIds != null && docIds.length != 0) {				
			
			//process input data			
			WriteULSStringXML obj = new WriteULSStringXML();
			inputStringXml = obj.createXML(request, requestDate, docIds);			
			//System.out.println("Unlink Service Input Data ::  " + inputStringXml);
			
			outputStringXml = srvPort.deleteDocuments(inputStringXml);
			//System.out.println("Unlink Service Output Data ::  " + outputStringXml);
			
			//process output data
			processOutputData(outputStringXml);
			
				if(status.equalsIgnoreCase("0")){
					
					statusMsg = "Document(s) Unlinked Successfully.";
					
				}else{
					statusMsg = errorCode + " : " + errorMsg;
				}
			
			}else{
				statusMsg = "Please select Document(s) to Unlink.";
			}
		}
		catch (Exception e)
		{
			statusMsg = e.getMessage();
			out.println(e.toString());
		}		
		return statusMsg;
    }
	
	/** 
	 * Method Description: This method is used to process the output data.                 
	 * 
	 * 
	 */
	private void processOutputData(String inputStringXml){
		
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(inputStringXml));	    
			Document doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize(); 
			
			//header element
			NodeList nList = doc.getElementsByTagName("header");		
	 
			   Node nNode = nList.item(0);
			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) nNode;		      
			      
			      status = getTagValue("status", eElement);			      
			      errorCode = getTagValue("ErrorCode", eElement);			            		
			      errorMsg = getTagValue("ErrorMessage", eElement);			      
			   }			
			   
		} catch (Exception e) {
			out.println(e.toString());
		} 
	}
	
	private String getTagValue(String sTag, Element eElement) {
		  
		String tagValue = null;
		
		try {
			NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
 
			    Node nValue = (Node) nlList.item(0); 
			    
			    if(nValue!=null){
			    	tagValue = nValue.getNodeValue();
			    }
			    else{
			    	tagValue = "";
			    }
			    
		} catch (Exception e) {
			
			out.println(e.toString());
		}
	 
		return tagValue;
	  }
	

}

