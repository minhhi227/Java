package com.vb.ecm.los.simulator;

import java.io.PrintWriter;
import java.io.StringReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.vb.ecm.services.los.create.ws.CreateServiceLocator;
import com.vb.ecm.services.los.create.ws.CreateServicePort;

public class CreateServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    private PrintWriter out = null;    
    private String status = null;
    private String errorCode = null;
    private String errorMsg = null;
    private String trans_id = null;

	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException 
		{		
		ResourceBundle rsb = null;
		String requestDate = null;
		
		try	{			
			//resource bundle
			rsb = ResourceBundle.getBundle("com.vb.ecm.los.simulator.LOSSimulatorConfig");			
			
			//request date			
			SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    requestDate = sdf.format(new Date());			    
			
			out = response.getWriter();
			response.setContentType("text/html");	
			       	
        	Element identityElement = buildServiceContextWithIdentity(rsb.getString("REPO_NAME"), 
        			rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));
        	
        	String successMsg = callSchemaService(identityElement, request, rsb, requestDate);
        	
        	if(successMsg!=null){
        		
        		request.setAttribute("success_msg", successMsg); 
        		request.getRequestDispatcher("/Main.jsp").forward(request, response);  
        	}
        	
	        out.close();        	
	}
	catch(Exception e)
	{
		out.println(e.toString());}
	}
	
	private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private String callSchemaService(Element identityElement, HttpServletRequest request, ResourceBundle rsb, String requestDate)
    {		
		String inputStringXml = null;
		String outputStringXml = null;
		String successMsg = null;
		
		try
		{			
			CreateServiceLocator srvLoc = new 
					CreateServiceLocator(rsb.getString("LOS_WEBSERVICES_URL") + "/CreateService?wsdl", 
					new QName("http://ws.create.los.services.ecm.vb.com/", "CreateService"));
			
			CreateServicePort srvPort = 
					srvLoc.getCreateServicePort(new 
							URL(rsb.getString("LOS_WEBSERVICES_URL") + "/CreateService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service
			
			//process input data			
			WriteCSStringXML obj = new WriteCSStringXML();
			inputStringXml = obj.createXML(request, requestDate);			
			//System.out.println("Create Service Input Data ::  " + inputStringXml);	
			
			outputStringXml = srvPort.createContentlessDocument(inputStringXml);
			//System.out.println("Create Service Output Data ::  " + outputStringXml);
			
			//process output data
			processOutputData(outputStringXml);
			
			if(status.equalsIgnoreCase("0") && trans_id!=null){
				
				//inserting record into access database table
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");				
	            Connection con = DriverManager.getConnection("jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};" +
	            		"Dbq= "+ rsb.getString("DB_FILE_PATH"));	            
	            Statement st=con.createStatement();	            
	            st.executeUpdate("insert into " + rsb.getString("TABLE_NAME") + " values('"+ trans_id +"','','','','')");	
	            
	            successMsg = "Document Created Successfully.";
	            
	            st.close();	            
	            con.close();
			}
			else{
				successMsg = errorCode + " : " + errorMsg;
			}
		}
		catch (Exception e)
		{
			successMsg = e.getMessage();
			out.println(e.toString());
		}
		
		return successMsg;
    }	
	
	/** 
	 * Method Description: This method is used to process the output data.                 
	 * 
	 * 
	 */
	private void processOutputData(String inputStringXml){
		
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(inputStringXml));	    
			Document doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize(); 
			
			//header element
			NodeList nList = doc.getElementsByTagName("header");		
	 
			   Node nNode = nList.item(0);
			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) nNode;		      
			      
			      status = getTagValue("status", eElement);			      
			      errorCode = getTagValue("ErrorCode", eElement);			            		
			      errorMsg = getTagValue("ErrorMessage", eElement);			      
			   }			
			
			//DocumentProperties element
			NodeList docList = doc.getElementsByTagName("message_response");
	 
			   Node node = docList.item(0);
			   if (node.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) node;		      
			      
			      trans_id = getTagValue("trans_id", eElement);			      
			   }
			
			   
		} catch (Exception e) {
			out.println(e.toString());
		} 
	}
	
	private String getTagValue(String sTag, Element eElement) {
		  
		String tagValue = null;
		
		try {
			NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
 
			    Node nValue = (Node) nlList.item(0); 
			    
			    if(nValue!=null){
			    	tagValue = nValue.getNodeValue();
			    }
			    else{
			    	tagValue = "";
			    }
			    
		} catch (Exception e) {
			
			out.println(e.toString());
		}
	 
		return tagValue;
	  }
	
 
}

