package com.vb.ecm.los.simulator;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.vb.ecm.services.los.searchbytransid.ws.SearchByTransIdServiceLocator;
import com.vb.ecm.services.los.searchbytransid.ws.SearchByTransIdServicePort;

public class SearchByTransIdServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private PrintWriter out = null;
    private String status = null;
    private String errorCode = null;
    private String errorMsg = null;
    
    private ArrayList<String> docId = new ArrayList<String>();
    private ArrayList<String> docName = new ArrayList<String>();
    private ArrayList<String> urlLink = new ArrayList<String>();
    private ArrayList<String> creationDate = new ArrayList<String>();
    private ArrayList<String> uploadBy = new ArrayList<String>();
        
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 
		ResourceBundle rsb = null;
		String requestDate = null;
		String document_id = null;		
		
		try {
			//resource bundle
			rsb = ResourceBundle.getBundle("com.vb.ecm.los.simulator.LOSSimulatorConfig");
			
			//request date			
			SimpleDateFormat sdf = new SimpleDateFormat(rsb.getString("DATE_FORMAT"));
		    requestDate = sdf.format(new Date());
			
			out = response.getWriter();
			response.setContentType("text/html");
			
			document_id = request.getParameter("doc_id");			
			     	
			Element identityElement = buildServiceContextWithIdentity(rsb.getString("REPO_NAME"), 
        			rsb.getString("USER_NAME"), rsb.getString("USER_PASSWORD"));
			
			callSchemaService(identityElement, document_id, requestDate, rsb);
			
			if(docId.size() > 0){
				
				//delete record from ms access database
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");	            
	            Connection con = DriverManager.getConnection("jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};" +
	            		"Dbq=" + rsb.getString("DB_FILE_PATH"));
	            Statement st=con.createStatement();
	            String query = "delete from " + rsb.getString("TABLE_NAME") + " where [Document Id] = '"+ document_id +"'";	                      
	            st.executeUpdate(query);
				st.close();
				con.close();
				
				//inserting record into access database table
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");	           
	            Connection con1 = DriverManager.getConnection("jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};" +
	            		"Dbq=" + rsb.getString("DB_FILE_PATH"));
	            Statement st1 = con1.createStatement();
	            
	            for(int i=0; i<docId.size(); i++){
				    
			    st1.execute("insert into " + rsb.getString("TABLE_NAME") + " values('"+ docId.get(i) +"','"+ 
			    		docName.get(i) +"','"+ urlLink.get(i) +"','"+ creationDate.get(i) +"','"+ 
			    		uploadBy.get(i) +"')");			    
			         			    
	            }
			    
			    st1.close();
				con1.close();
				
				//close array lists
				docId.clear();
				docName.clear();
				urlLink.clear();
				creationDate.clear();
				uploadBy.clear();				
				
				request.setAttribute("success_msg", "Record(s) Inserted Successfully.");				 
				request.getRequestDispatcher("/Main.jsp").forward(request, response);     
				 
			}
			else if(status.equalsIgnoreCase("2")){
				
				request.setAttribute("success_msg", "Document(s) still not yet Uploaded.");
				request.getRequestDispatcher("/Main.jsp").forward(request, response); 
			}
			else{	
				
				request.setAttribute("success_msg", errorCode + " : " + errorMsg);
				request.getRequestDispatcher("/Main.jsp").forward(request, response);    
			}
			   
			out.close();
			
		} catch (Exception e) {			
			out.println(e.toString());
		}
	}
	
	private Element buildServiceContextWithIdentity(String docbase,String user,String pass)
            throws ParserConfigurationException {
   
       // CREATE parser for creating DOM objects, root document
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
       Document doc = dbf.newDocumentBuilder().newDocument();
   
       // CREATE <ServiceContext> and child <Identities> element for authentication
       String CONTEXT_NS = "http://context.core.datamodel.fs.documentum.emc.com/"; 
       Element serviceContextElement = doc.createElement("ServiceContext");
       serviceContextElement.setAttribute("xmlns",CONTEXT_NS);
       Element identities = doc.createElement("Identities");
       identities.setAttribute("userName", user);
       identities.setAttribute("password", pass);
       identities.setAttribute("repositoryName", docbase);
       identities.setAttribute("xsi:type", "RepositoryIdentity");
       serviceContextElement.appendChild(identities);
   
       return serviceContextElement;
  }    
    
	private void callSchemaService(Element identityElement, String document_id, 
				String requestDate, ResourceBundle rsb)
    {
		String inputStringXml = null;
		String outputStringXml = null;		
		
		try
		{			
			SearchByTransIdServiceLocator srvLoc = new 
					SearchByTransIdServiceLocator(rsb.getString("LOS_WEBSERVICES_URL") + "/SearchByTransIdService?wsdl", 
					new QName("http://ws.searchbytransid.los.services.ecm.vb.com/", "SearchByTransIdService"));
			
			SearchByTransIdServicePort srvPort = 
					srvLoc.getSearchByTransIdServicePort(new 
							URL(rsb.getString("LOS_WEBSERVICES_URL") + "/SearchByTransIdService?wsdl"));			
			
			Stub ostub = (Stub) srvPort;
			ostub.setHeader(new SOAPHeaderElement(identityElement));
			
			//Call the service - Search By Transaction Id			
			
			//process input data
			WriteSBTISStringXML obj = new WriteSBTISStringXML();
			inputStringXml = obj.createXML(document_id, requestDate);			
			//System.out.println("Search By Transaction Id Service Input Data ::  " + inputStringXml);		
			
			outputStringXml = srvPort.searchByTransId(inputStringXml);
			//System.out.println("Search By Transaction Id Service Output Data ::  " + outputStringXml);
			
			//process output data
			processOutputData(outputStringXml);
			
		}
		catch (Exception e)
		{
			out.println(e.toString());
		}
		
    }
	
	/** 
	 * Method Description: This method is used to process the output data.                 
	 * 
	 * 
	 */
	private void processOutputData(String outputStringXml){
		
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(outputStringXml));	    
			Document doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize(); 
			
			//header element
			NodeList nList = doc.getElementsByTagName("header");		
	 
			   Node nNode = nList.item(0);
			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 
			      Element eElement = (Element) nNode;		      
			      
			      status = getTagValue("status", eElement);			      
			      errorCode = getTagValue("ErrorCode", eElement);			            		
			      errorMsg = getTagValue("ErrorMessage", eElement);			      
			   }
			   
			   if(status.equalsIgnoreCase("0")){
			
					//DocumentProperties element
					NodeList docList = doc.getElementsByTagName("Document");
			 
					for (int temp = 0; temp < docList.getLength(); temp++) {
						 
						   Node node = docList.item(temp);
						   if (node.getNodeType() == Node.ELEMENT_NODE) {
			 
					      Element eElement = (Element) node;		      
					      
					      docId.add(getTagValue("document_id", eElement));
					      docName.add(getTagValue("document_name", eElement));
					      urlLink.add(getTagValue("url_link", eElement));
					      creationDate.add(getTagValue("creation_date", eElement));
					      uploadBy.add(getTagValue("upload_by", eElement));					      
					   }
					}
			   }			
			   
		} catch (Exception e) {
			out.println(e.toString());
		}		
		
	}
	
	private String getTagValue(String sTag, Element eElement) {
		  
		String tagValue = null;
		
		try {
			NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
 
			    Node nValue = (Node) nlList.item(0); 
			    
			    if(nValue!=null){
			    	tagValue = nValue.getNodeValue();
			    }
			    else{
			    	tagValue = "";
			    }
			    
		} catch (Exception e) {
			
			out.println(e.toString());
		}
	 
		return tagValue;
	  }
	
	
}

