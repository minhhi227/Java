package com.vb.ecm.los.simulator;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UploadHardCopyDocsServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;    
    
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{  
    	ResourceBundle rsb = null;
    	PrintWriter out = null; 
    	String[] docIds = null;

	try	{		
		//resource bundle
		rsb = ResourceBundle.getBundle("com.vb.ecm.los.simulator.LOSSimulatorConfig");		
		
		out = response.getWriter();
		response.setContentType("text/html");		
		       	
		docIds = request.getParameterValues("document_id");		
		
		if (docIds != null && docIds.length == 1) {			
			
			 String url = rsb.getString("UPLOAD_HARDCOPY_DOCS_URL") + "?" + docIds[0];			 
			 response.sendRedirect(url);
		}
		else if(docIds != null && docIds.length>1){
			
			request.setAttribute("success_msg", "Please select only One Document (Transaction Id) to Upload.");
			request.getRequestDispatcher("/Main.jsp").forward(request, response);
		}
		else{
			
			request.setAttribute("success_msg", "Please select Document (Transaction Id) to Upload.");
			request.getRequestDispatcher("/Main.jsp").forward(request, response);
		}
                
        out.close();        	
	}
	catch(Exception e)
	{
		out.println(e.toString());}
	}
	

}

