/**
* ______________________________________________________________________________
*
* File: SampleMD5.java
*______________________________________________________________________________
*
* CreatedBy: Verinon
* CreationDate: Sep 15, 2012   2:16:14 PM   2012
* Description: Write your class description here like from where it is calling and
* what functions are doing
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/
package com.vb.ecm.migration.icdoc;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

/**
 * @Last Midify Author       Verinon
 * @Last Midification Date   Sep 15, 2012
 * @Last Midification Time   2:16:14 PM
 * @Last Midification Year   2012
 * @What to do next          TODO
 */
public class ICDocEncryption {

	private static final Logger LOGGER = Logger.getLogger(ICDocEncryption.class);
	
	 private static String convertToHex(byte[] data) { 
	        StringBuffer buf = new StringBuffer();
	        for (int i = 0; i < data.length; i++) { 
	            int halfbyte = (data[i] >>> 4) & 0x0F;
	            int two_halfs = 0;
	            do { 
	                if ((0 <= halfbyte) && (halfbyte <= 9)) 
	                    buf.append((char) ('0' + halfbyte));
	                else 
	                    buf.append((char) ('a' + (halfbyte - 10)));
	                halfbyte = data[i] & 0x0F;
	            } while(two_halfs++ < 1);
	        } 
	        return buf.toString();
	    } 
	 
	    public static String MD5(String text) 
	    throws NoSuchAlgorithmException, UnsupportedEncodingException  { 
	        MessageDigest md;
	        md = MessageDigest.getInstance("MD5");
	        byte[] md5hash = new byte[32];
	        md.update(text.getBytes("iso-8859-1"), 0, text.length());
	        md5hash = md.digest();
	        return convertToHex(md5hash);
	    } 
	    
	    public static void main(String args[]) {
	    	ICDocEncryption md5 = new ICDocEncryption();
	    	try {
				String convertedS = md5.MD5("2011");
				LOGGER.debug("ICDocEncryption  :: main :: convertedS:"+convertedS);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				LOGGER.error("ICDocEncryption  :: main :: EC001"+e);			
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				LOGGER.error("ICDocEncryption  :: main :: EC002"+e);
			}
	    }


}
