/**
* ______________________________________________________________________________
*
* File: MigrationReports.java
*______________________________________________________________________________
*
* CreatedBy: Verinon
* CreationDate: Sep 15, 2012   8:56:41 PM   2012
* Description: Write your class description here like from where it is calling and
* what functions are doing
*______________________________________________________________________________
*
* Copyright: (c) Vietinbank, all rights reserved 
*______________________________________________________________________________
*
*/
package com.vb.ecm.migration.icdoc;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import org.apache.log4j.Logger;

/**
 * @Last Midify Author       Verinon
 * @Last Midification Date   Sep 15, 2012
 * @Last Midification Time   8:56:41 PM
 * @Last Midification Year   2012
 * @What to do next          TODO
 */
public class MigrationReports extends JFrame implements ActionListener{
	
	AccessDatabase ad = new AccessDatabase();
	private static final Logger LOGGER = Logger.getLogger(MigrationReports.class);
	JScrollPane jScrollPane;
	JTextField failedDocsTF, successDocsTF, totalDocsTF, failedFolTF, successFolTF, totalFolTF;
	JLabel failedDocsL, successDocsL, totalDocsL, failedFolL, successFolL, totalFolL;
	String[] columnNames = {"Document_Code","Number_Sign","Object_Id","Export_Date","Export_Status"};
	String[][] columnData = {};
	Object[] dataObjects = {};
	Object[] folderObjects = {};
	JLabel line1Label, logoLabel;
	JButton failedDocsButton, ExpDocsButton, allDocsButton, backButton ;
	int successDataCount, failureDataCount, totalDataCount;
	int totalFolders, totalSuccFolders, totalFailFolders;
	

	/**
	 * 
	 */
	public MigrationReports() {
		// TODO Auto-generated constructor stub		
		//setLayout(new GridBagLayout());
		setResizable(false);
		JPanel resultPanel = new JPanel(new GridBagLayout());
		JPanel logoPanel = new JPanel(new GridBagLayout());
		JPanel buttonPanel = new JPanel(new GridBagLayout());
		
		resultPanel.setBackground(new Color(204, 204, 255));
		logoPanel.setBackground(new Color(204, 204, 255));
		buttonPanel.setBackground(new Color(204, 204, 255));
			
		GridBagConstraints c = new GridBagConstraints();
		GridBagConstraints bc = new GridBagConstraints();
		GridBagConstraints tfc = new GridBagConstraints();
		
		try {			
			dataObjects = ad.getAccessDBData();
			columnData = (String[][])dataObjects[0];
			successDataCount = Integer.parseInt(dataObjects[1].toString());
			failureDataCount =  Integer.parseInt(dataObjects[2].toString());
			totalDataCount =  Integer.parseInt(dataObjects[3].toString());
			
			folderObjects = ad.getAccessDBFolder();
			totalFolders = Integer.parseInt(folderObjects[0].toString());
			totalSuccFolders =  Integer.parseInt(folderObjects[1].toString());
			totalFailFolders =  Integer.parseInt(folderObjects[2].toString());
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			LOGGER.error("MigrationReports  :: MigrationReports :: MR001"+e);
			e.printStackTrace();
		}
		
		JTable resultTable = new JTable(columnData,columnNames)	{
			 
			public Component prepareRenderer(TableCellRenderer r, int data, int columnNames) {
				Component comp = super.prepareRenderer(r, data, columnNames);
				if(data % 2 == 0 ) {
					comp.setBackground(Color.white);
				} else {
					comp.setBackground(new Color(230, 230, 255));
				}				
				if(isCellSelected(data, columnNames))
					comp.setBackground(Color.green);
				return comp;
			}
		};
		resultTable.setPreferredScrollableViewportSize(new Dimension(760,450));
		resultTable.setFillsViewportHeight(true);
		JTableHeader header = resultTable.getTableHeader();
		header.setBackground(Color.yellow);
		resultTable.setAutoCreateRowSorter(true);
		JScrollPane resultScroolPane = new JScrollPane(resultTable);
				
		ImageIcon ic1 = new ImageIcon(StartMigration.CURRENTDIRECTORY+"\\jars\\VietinBankLogo1.jpg");
		JLabel imageLabel1 = new JLabel(ic1);
		
		logoLabel = new JLabel();
		logoLabel.setForeground(new Color(001, 001, 001));
		logoLabel.setFont(new Font("Dialog", Font.BOLD, 13));
		logoLabel.setText("  icDoc Migration Reports");

		failedDocsL = new JLabel();
		failedDocsL.setText("TDF");	
		failedDocsTF = new JTextField("failedDocs");
		failedDocsTF.setBackground(new Color(205, 92, 92));
		failedDocsTF.setFont(new Font("Dialog", Font.BOLD, 15));
		failedDocsTF.setText(Integer.toString(failureDataCount));
		failedDocsTF.setEditable(false);
		
		successDocsL = new JLabel();
		//successDocsL.setText("Total No Of Docs Success");	
		successDocsL.setText("TDS");	
		successDocsTF = new JTextField("successDocs");
		successDocsTF.setBackground(new Color(152,251,152));
		successDocsTF.setFont(new Font("Dialog", Font.BOLD, 15));
		successDocsTF.setText(Integer.toString(successDataCount));
		successDocsTF.setEditable(false);
		
		totalDocsL = new JLabel();
		totalDocsL.setText("TD");
		totalDocsTF = new JTextField("totalDocs");	
		totalDocsTF.setFont(new Font("Dialog", Font.BOLD, 15));
		totalDocsTF.setText(Integer.toString(totalDataCount));
		totalDocsTF.setEditable(false);
		
		failedFolL = new JLabel();
		failedFolL.setText("TFF");	
		failedFolTF = new JTextField("failedDocs");
		failedFolTF.setBackground(new Color(205, 92, 92));
		failedFolTF.setFont(new Font("Dialog", Font.BOLD, 15));
		failedFolTF.setText(Integer.toString(totalFailFolders));
		failedFolTF.setEditable(false);
		
		successFolL = new JLabel();
		//successDocsL.setText("Total No Of Docs Success");	
		successFolL.setText("TFS");	
		successFolTF = new JTextField("successDocs");
		successFolTF.setBackground(new Color(152,251,152));
		successFolTF.setFont(new Font("Dialog", Font.BOLD, 15));
		successFolTF.setText(Integer.toString(totalSuccFolders));
		successFolTF.setEditable(false);
		
		totalFolL = new JLabel();
		totalFolL.setText("TF");
		totalFolTF = new JTextField("totalDocs");	
		totalFolTF.setFont(new Font("Dialog", Font.BOLD, 15));
		totalFolTF.setText(Integer.toString(totalFolders));
		totalFolTF.setEditable(false);
		
		backButton = new JButton("Back");
		backButton.setText("Back");
		backButton.setBounds(140, 380, 140, 20);
		backButton.addActionListener(this);
		
		getContentPane().add(resultPanel, BorderLayout.PAGE_START);
		resultPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		resultPanel.setSize(600, 500);
		c.gridx = 0;
		c.gridy = 0;
		logoPanel.add(imageLabel1,c);
		c.gridx = 1;
		c.gridy = 0;
		logoPanel.add(logoLabel,c);
		c.gridx = 0;
		c.gridy = 0;
		c.gridheight = 200;
		c.gridwidth = 200;
		resultPanel.add(resultScroolPane, c);
		bc.ipadx = 2;
		bc.ipady = 0;
		bc.insets = new Insets(0, 10, 2, 20);
		tfc.ipadx = 40;
		tfc.ipady = 0;
		tfc.insets = new Insets(0, 0, 2, 20);
		buttonPanel.add(totalDocsL,bc);	
		buttonPanel.add(totalDocsTF,tfc);
		buttonPanel.add(successDocsL,bc);
		buttonPanel.add(successDocsTF,tfc);
		buttonPanel.add(failedDocsL,bc);
		buttonPanel.add(failedDocsTF,tfc);
		buttonPanel.add(totalFolL,bc);	
		buttonPanel.add(totalFolTF,tfc);
		buttonPanel.add(successFolL,bc);
		buttonPanel.add(successFolTF,tfc);
		buttonPanel.add(failedFolL,bc);
		buttonPanel.add(failedFolTF,tfc);
		buttonPanel.add(backButton,bc);
		
		add(logoPanel, BorderLayout.BEFORE_FIRST_LINE);
		add(resultPanel, BorderLayout.CENTER);
		add(buttonPanel, BorderLayout.PAGE_END);
	}
	
	public void actionPerformed(ActionEvent ae) {
		LOGGER.debug("MigrationReports  :: actionPerformed :: "+ae);
		String str = (String) ae.getActionCommand();
		if(str.equalsIgnoreCase("Back")) {
			dispose();
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LOGGER.debug("MigrationReports  :: main :: Enter Method");
		MigrationReports mr = new MigrationReports();
		mr.setSize(800, 600);
		mr.setTitle("Migration Reports");
		mr.setVisible(true);
		LOGGER.debug("MigrationReports  :: main :: Exit Method");

	}

}
